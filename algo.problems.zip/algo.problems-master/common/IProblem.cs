namespace algo.problems.common
{
    public interface IProblem
    {
        public void Run();
    }
}