﻿namespace ProductImageService.Tests.Scenarios
{
    public class TestId
    {
        private static int _idCounter = 1;

        private readonly int _id = _idCounter++;

        public static implicit operator int(TestId testId) => testId._id;
    }
}
