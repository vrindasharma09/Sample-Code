﻿using ProductImageService.WebDamApi.Dtos;
using System;

namespace ProductImageService.Tests.Scenarios
{
    public class TestAsset
    {
        public TestId Id = new TestId();
        public string Name;
        public string Description;
        public DateTime DateModifiedUtc = new DateTime(1970, 10, 1);
        public string Status = "Active";

        public Asset ToAsset() => new Asset()
        {
            Id = Id,
            Name = Name,
            Description = Description,
            DateModifiedUnix = ((DateTimeOffset)DateModifiedUtc).ToUnixTimeSeconds(),
            Status = Status
        };
    }

}
