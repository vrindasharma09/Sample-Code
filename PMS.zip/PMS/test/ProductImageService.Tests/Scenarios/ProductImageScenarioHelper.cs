﻿using System.Collections.Generic;

namespace ProductImageService.Tests.Scenarios
{
    public class ProductImageScenarioHelper
    {
        public WebDamSourceScenario DefaultWebDamSourceScenario()
        {
            TestAssetFolder topLevelAssetFolder =
            new TestAssetFolder()
            {
                Name = "Products",
                Assets = new List<TestAsset>(),
                Children = new List<TestAssetFolder>()
                {
                    new TestAssetFolder()
                    {
                        Name = "Product 1",
                        Assets = new List<TestAsset>()
                        {
                            new TestAsset()
                            {
                                Name = "Asset directly below Product 1",
                                Description = ""
                            }
                        },
                        Children = new List<TestAssetFolder>()
                        {
                            new TestAssetFolder()
                            {
                                Name = "Brochures",
                                Assets = new List<TestAsset>()
                                {
                                    new TestAsset()
                                    {
                                        Name = "Asset 1 in brochures sub folder",
                                        Description = "3495347"
                                    },
                                    new TestAsset()
                                    {
                                        Name = "Asset 2 in brochures sub folder",
                                        Description = "492634"
                                    }
                                }
                            },
                            new TestAssetFolder()
                            {
                                Name = "Other Media",
                                Assets = new List<TestAsset>()
                                {
                                    new TestAsset()
                                    {
                                        Name = "Asset 1 in Other Media sub folder",
                                        Description = "3423453425"
                                    },
                                    new TestAsset()
                                    {
                                        Name = "Asset 2 in Other Media sub folder",
                                        Description = "45745457547"
                                    }
                                }
                            }
                        }
                    },

                    new TestAssetFolder()
                    {
                        Name = "Product 2",
                        Assets = new List<TestAsset>()
                        {
                            new TestAsset()
                            {
                                Name = "Asset directly below Product 2",
                                Description = "9213621"
                            }

                        },
                        Children = new List<TestAssetFolder>()
                        {
                            new TestAssetFolder() { Name = "Parts",
                                Assets = new List<TestAsset>()
                                {
                                    new TestAsset()
                                    {
                                        Name = "Valid parts asset 1",
                                        Description = "0111111"
                                    },
                                    new TestAsset()
                                    {
                                        Name = "Valid parts asset 2",
                                        Description = "0222222"
                                    },
                                    new TestAsset()
                                    {
                                        Name = "Asset in parts folder, w/o description",
                                        Description = ""
                                    },
                                    new TestAsset()
                                    {
                                        Name = "Asset in parts folder, w description, but inactive",
                                        Description = "Test",
                                        Status = "Inactive"
                                    },
                                    new TestAsset()
                                    {
                                        Name = "Asset in parts folder, w/o description, inactive",
                                        Description = "",
                                        Status = "Inactive"
                                    }

                                }
                            }
                        }
                    }

                }
            };

            return new WebDamSourceScenario(topLevelAssetFolder, "Default Scenario");

        }
    }
}
