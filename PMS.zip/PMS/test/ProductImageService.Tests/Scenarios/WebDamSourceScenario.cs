﻿namespace ProductImageService.Tests.Scenarios
{
    public class WebDamSourceScenario
    {
        public readonly TestAssetFolder TopFolder;

        public readonly string Name;

        public WebDamSourceScenario(TestAssetFolder topFolder, string name = "Unnamed Scenario")
        {
            TopFolder = topFolder;
            Name = name;
        }
    }
}