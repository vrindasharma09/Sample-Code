﻿using ProductImageService.WebDamApi.Dtos;
using System.Collections.Generic;
using System.Linq;

namespace ProductImageService.Tests.Scenarios
{

    public class TestAssetFolder
    {
        public readonly TestId Id = new TestId();
        public string Name;

        public List<TestAssetFolder> Children = new List<TestAssetFolder>();
        public List<TestAsset> Assets = new List<TestAsset>();

        public FolderInformation ToFolderInformation()
        {
            return new FolderInformation()
            {
                Id = Id,
                Name = Name,
                Folders = Children.Select(
                    c => new Folder()
                    {
                        Id = c.Id,
                        Name = c.Name
                    }).ToList()
            };
        }

        private IEnumerable<TestAssetFolder> SubTree()
        {
            return new[] { this }.Concat(Children.SelectMany(child => child.SubTree()));
        }

        public TestAssetFolder FindFolderById(int folderId)
        {
            return SubTree().FirstOrDefault(f => f.Id == folderId);
        }

        public TestAssetFolder FindFolderByName(string name)
        {
            return SubTree().FirstOrDefault(f => f.Name.Equals(name));
        }

    }
}
