﻿using ProductImageService.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProductImageService.Tests.Helpers
{
    public interface IProductImageIndex
    {
        Task AddOrUpdateAssetForEntry(BrandFolderAssetDetails assetDetails);

        Task<IEnumerable<IndexEntry>> GetAllEntries();

        Task<IEnumerable<IndexEntry>> GetEntriesModifiedSinceLastDownload();

        Task RecordLastAssetDownload(string assetName, DateTime lastDownloadedTimeUtc);
    }
}
