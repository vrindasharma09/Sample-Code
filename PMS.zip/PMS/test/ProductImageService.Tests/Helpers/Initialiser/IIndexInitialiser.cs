﻿using System.Threading.Tasks;

namespace ProductImageService.Tests.Helpers.Initialiser
{
    public interface IIndexInitialiser
    {
        Task InitialiseIndexFromFolderRecursively(IProductImageIndex productImageIndex, int assetFolderId);
    }
}
