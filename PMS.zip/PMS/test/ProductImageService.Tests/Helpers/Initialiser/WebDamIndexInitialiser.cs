﻿using ProductImageService.AssetCrawler.Crawler;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProductImageService.Tests.Helpers.Initialiser
{
    public class WebDamIndexInitialiser : IIndexInitialiser
    {
        private const int AssetMaxCount = 5000;
        private int _assetCount;

        private IProductImageIndex _productImageIndex;
        private readonly WebDamAssetCrawler _webDamAssetCrawler;

        private readonly Stack<int> _folderStack = new Stack<int>();

        public WebDamIndexInitialiser(WebDamAssetCrawler webDamAssetCrawler)
        {
            _webDamAssetCrawler = webDamAssetCrawler;
        }

        public async Task InitialiseIndexFromFolderRecursively(IProductImageIndex productImageIndex, int assetFolderId)
        {
            _productImageIndex = productImageIndex;

            //_webDamAssetCrawler.AssetSubFolderEncountered += HandleAssetSubfolderEncountered;
            //_webDamAssetCrawler.SkuAssetEncountered += HandleSkuAssetEncountered;

            _folderStack.Push(assetFolderId);
            await ProcessFolderStack();
        }

        private async Task ProcessFolderStack()
        {
            while (_folderStack.Count > 0 && _assetCount < AssetMaxCount)
            {
                int nextFolderId = _folderStack.Pop();
                await _webDamAssetCrawler.CrawlOneFolder(nextFolderId);
            }
        }

        //private void HandleAssetSubfolderEncountered(object sender, AssetSubFolderEncounteredEventArgs eventArgs)
        //{
        //    Console.WriteLine($"Encountered sub folder {eventArgs.FolderName}, ({eventArgs.FolderId})");
        //    _folderStack.Push(eventArgs.FolderId);
        //}

        //private void HandleSkuAssetEncountered(object sender, SkuAssetEncounteredEventArgs eventArgs)
        //{
        //    Console.WriteLine($"Encountered SKU asset {eventArgs.BamAssetDetails.ProductName}, ({eventArgs.BamAssetDetails.AssetId})");
        //    _productImageIndex.AddOrUpdateAssetForEntry(eventArgs.BamAssetDetails);
        //    _assetCount++;
        //    Console.WriteLine($"Asset count {_assetCount}");
        //}

    }
}