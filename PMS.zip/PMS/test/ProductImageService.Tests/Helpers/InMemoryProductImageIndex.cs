﻿using ProductImageService.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductImageService.Tests.Helpers
{
    public class InMemoryProductImageIndex : IProductImageIndex
    {
        private readonly List<IndexEntry> _entries = new List<IndexEntry>();

        public Task AddOrUpdateAssetForEntry(BrandFolderAssetDetails assetDetails)
        {
            IndexEntry indexEntry = FindIndexEntry(assetDetails.ProductName) ?? IndexEntry.CreateFromAsset(assetDetails);
            _entries.Add(indexEntry);
            return Task.CompletedTask;
        }

        public Task<IEnumerable<IndexEntry>> GetAllEntries() => Task.FromResult<IEnumerable<IndexEntry>>(_entries);

        public Task<IEnumerable<IndexEntry>> GetEntriesModifiedSinceLastDownload()
        {
            var matchingEntries = _entries.Where(ie => ie.LastDownloadedUtc < ie.BrandFolderLastModifiedUtc);
            return Task.FromResult(matchingEntries);
        }

        public Task RecordLastAssetDownload(string name, DateTime lastDownloadedTimeUtc)
        {
            IndexEntry indexEntry = FindIndexEntry(name);
            if (indexEntry != null)
            {
                indexEntry.LastDownloadedUtc = lastDownloadedTimeUtc;
            }
            return Task.CompletedTask;
        }

        private IndexEntry FindIndexEntry(string name)
        {
            return _entries.FirstOrDefault(ie => ie.RowKey == name);
        }

    }
}
