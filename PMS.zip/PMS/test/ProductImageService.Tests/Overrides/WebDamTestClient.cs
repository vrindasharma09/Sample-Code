﻿using ProductImageService.Tests.Scenarios;
using ProductImageService.WebDamApi;
using ProductImageService.WebDamApi.Dtos;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ProductImageService.Tests.Overrides
{
    public class WebDamTestClient : IWebDamApi
    {
        private readonly TestAssetFolder _topFolder;

        public WebDamTestClient(TestAssetFolder topFolder)
        {
            _topFolder = topFolder;
        }

        public Task<FolderInformation> GetFolderInformationAsync(int folderId)
            => Task.FromResult(_topFolder.FindFolderById(folderId).ToFolderInformation());

        public Task<IEnumerable<Asset>> GetActiveAssetsForFolderAsync(FolderInformation folder)
        {
            TestAssetFolder testFolder = _topFolder.FindFolderById(folder.Id);
            var assets = testFolder.Assets.Where(a => a.Status.ToLower().Equals("active")).Select(ta => ta.ToAsset());
            return Task.FromResult(assets);
        }

        public Task<byte[]> DownloadImageAsset(int? assetId) => throw new NotImplementedException("Functionality is not implemented");

        public Task<Stream> DownloadImageAssetAsStream(int? assetId) => throw new NotImplementedException("Functionality is not implemented");
        public Task<FolderAssets> GetActiveAssetsForFolderAsync(int folderId, int offset, int assetListMaxLimit = 100)
        {
            TestAssetFolder testFolder = _topFolder.FindFolderById(folderId);
            var assets = testFolder.Assets.Where(a => a.Status.ToLower().Equals("active")).Select(ta => ta.ToAsset());
            return Task.FromResult(new FolderAssets() { Items = assets.ToList() });
        }

        public Task<AssetVersion> GetAssetVersion(int assetId, int version)
        {
            throw new NotImplementedException();
        }

        public Task<Asset[]> GetAssets(string ids) => throw new NotImplementedException();

        public Task<Notifications> GetNotifications(int limit, int offset) => throw new NotImplementedException();
    }
}
