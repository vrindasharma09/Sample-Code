﻿using ProductImageService.Tests.Scenarios;
using ProductImageService.WebDamApi;
using ProductImageService.WebDamApi.Dtos;
using System.IO;
using System.Threading.Tasks;

namespace ProductImageService.Tests.ProductImageIndexTest
{
    public class GivenAnEmptyProductImageIndex
    {
        private readonly ProductImageScenarioHelper _scenarioHelper = new ProductImageScenarioHelper();

        /*[Fact]
        public async Task WhenValidAssetsExist_ShouldPopulate()
        {
            WebDamSourceScenario scenario = _scenarioHelper.DefaultWebDamSourceScenario();
            //IWebDamClient webDamTestClient = new WebDamTestClient(scenario.TopFolder);

            IWebDamApi testWebDamApi = new TestWebDamApi();
            WebDamAssetCrawler assetCrawler = new WebDamAssetCrawler(testWebDamApi, Logger.None);
            WebDamIndexInitialiser webDamIndexInitialiser = new WebDamIndexInitialiser(assetCrawler);
            IProductImageIndex productImageIndex = new InMemoryProductImageIndex();

            await webDamIndexInitialiser.InitialiseIndexFromFolderRecursively(productImageIndex, scenario.TopFolder.Id);

            List<IndexEntry> allIndexEntries = (await productImageIndex.GetAllEntries()).ToList();

            Assert.Equal(2, allIndexEntries.Count);
        }*/
    }

    public class TestWebDamApi : IWebDamApi
    {
        public Task<FolderInformation> GetFolderInformationAsync(int folderId)
        {
            throw new System.NotImplementedException();
        }

        public Task<Stream> DownloadImageAssetAsStream(int? assetId)
        {
            throw new System.NotImplementedException();
        }

        public Task<FolderAssets> GetActiveAssetsForFolderAsync(int folderId, int offset, int assetListMaxLimit = 100)
        {
            throw new System.NotImplementedException();
        }

        public Task<AssetVersion> GetAssetVersion(int assetId, int version)
        {
            throw new System.NotImplementedException();
        }

        public Task<Asset[]> GetAssets(string ids) => throw new System.NotImplementedException();

        public Task<Notifications> GetNotifications(int limit, int offset)
        {
            throw new System.NotImplementedException();
        }
    }
}