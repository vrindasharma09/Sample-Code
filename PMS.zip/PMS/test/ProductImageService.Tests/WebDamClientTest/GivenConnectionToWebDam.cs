﻿namespace ProductImageService.Tests.WebDamClientTest
{
    public class GivenConnectionToWebDam
    {
        //private readonly ProductImageScenarioHelper _scenarioHelper = new ProductImageScenarioHelper();

        //[Fact]
        //public async Task WhenFolderExists_ShouldFindFolderById()
        //{
        //    WebDamSourceScenario scenario = _scenarioHelper.DefaultWebDamSourceScenario();

        //    IWebDamClient webDamTestClient = new WebDamTestClient(scenario.TopFolder);

        //    FolderInformation fi = await webDamTestClient.GetFolderInformationAsync(scenario.TopFolder.Id);
        //    Assert.Equal("Products", fi.Name);
        //}

        //[Fact]
        //public async Task WhenFolderExists_ShouldFindFolderByName()
        //{
        //    WebDamSourceScenario scenario = _scenarioHelper.DefaultWebDamSourceScenario();

        //    IWebDamClient webDamTestClient = new WebDamTestClient(scenario.TopFolder);

        //    TestAssetFolder partsFolder = scenario.TopFolder.FindFolderByName("Parts");

        //    FolderInformation partsFi = await webDamTestClient.GetFolderInformationAsync(partsFolder.Id);
        //    Assert.Equal("Parts", partsFi.Name);
        //    Assert.Empty(partsFi.Folders);

        //    TestAssetFolder secondProductFolder = scenario.TopFolder.FindFolderByName("Product 1");

        //    FolderInformation secondProductFi = await webDamTestClient.GetFolderInformationAsync(secondProductFolder.Id);
        //    Assert.Equal("Product 1", secondProductFi.Name);
        //    Assert.Equal(2, secondProductFi.Folders.Count);
        //}

        //[Fact]
        //public async Task WhenAssetsExist_ShouldBeRetrieved()
        //{
        //    WebDamSourceScenario scenario = _scenarioHelper.DefaultWebDamSourceScenario();

        //    IWebDamClient webDamTestClient = new WebDamTestClient(scenario.TopFolder);

        //    TestAssetFolder partsTestFolder = scenario.TopFolder.FindFolderByName("Parts");

        //    FolderInformation partsFi = await webDamTestClient.GetFolderInformationAsync(partsTestFolder.Id);

        //    List<Asset> assets = (await webDamTestClient.GetActiveAssetsForFolderAsync(partsFi)).ToList();

        //    int numberOfActiveAssetsToFind = partsTestFolder.Assets.Where(a => a.Status.ToLower().Equals("active")).ToList().Count;
        //    Assert.Equal(numberOfActiveAssetsToFind, assets.Count);
        //}
    }
}
