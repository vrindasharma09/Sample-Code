﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ImageMagick;
using Microsoft.Extensions.Configuration;
using ProductImageService.AssetCrawler.Crawler;
using ProductImageService.Common;
using ProductImageService.Index;
using ProductImageService.Index.CosmosDb;
using ProductImageService.Index.Initialiser;
using ProductImageService.WebDamApi;
using ProductImageService.WebDamApi.Dtos;

namespace ProductImageService.Cli
{
    internal class Program
    {
        private static readonly WebDamConfiguration WebDamConfiguration = GetWebDamConfiguration();
        private static CosmosDbConfiguration CosmosDbConfiguration = GetCosmosDbConfiguration();
        private static readonly int ProductsTopFolderId = int.Parse(GetConfigValue("ProductsTopFolderId"));

        private static async Task Main(string[] args)
        {
            //await GetAssetsFromFolder();
            //await TestDownloadViaWebDamClient();
            //await TestWebDamAndCosmosDbIndex();
            //await TestWebDamAndMemoryIndex();
            //await TestCosmosDbIndexDateUpdate();
            //await TestCosmosDbDuplicateDeletion();
            ImageProcessingTest.Execute();

            Console.WriteLine("-- End of Execution - Press a Key --");
            Console.ReadKey();
        }

        private static async Task TestDownloadViaWebDamClient()
        {
            WebDamClient client = new WebDamClient(WebDamConfiguration);
            using (Stream s = await client.DownloadImageAssetAsStream(7793504))
            //14601973
            {
                using (var fileStream = File.Create("C:\\temp\\test.jpeg"))
                {
                    s.Seek(0, SeekOrigin.Begin);
                    s.CopyTo(fileStream);
                }
            }
        }

        private static async Task GetAssetsFromFolder()
        {
            WebDamClient client = new WebDamClient(WebDamConfiguration);
            var fi = await client.GetFolderInformationAsync(271813);

            List<Asset> assets = (await client.GetActiveAssetsForFolderAsync(fi)).ToList();

        }

        private static async Task TestWebDamAndMemoryIndex()
        {
            WebDamClient client = new WebDamClient(WebDamConfiguration);

            IProductImageIndex productImageIndex = new InMemoryProductImageIndex();
            IWebDamAssetCrawler assetCrawler = new WebDamAssetCrawler(client);
            IIndexInitialiser indexInitialiser = new WebDamIndexInitialiser(assetCrawler);
            await indexInitialiser.InitialiseIndexFromFolderRecursively(productImageIndex, ProductsTopFolderId);
        }

        /*
        private static async Task TestCosmosDbDuplicateDeletion()
        {
            CosmosDbProductImageIndex productImageIndex = new CosmosDbProductImageIndex(CosmosDbConfiguration);
            IEnumerable<CosmosDbIndexEntry> differentEntriesWithSameName = await productImageIndex.GetDifferentEntriesWithSameAssetName(80351377, "945090");
            await productImageIndex.DeleteEntries(differentEntriesWithSameName);

        }*/

        private static async Task TestCosmosDbIndexDateUpdate()
        {
            IProductImageIndex productImageIndex = new CosmosDbProductImageIndex(CosmosDbConfiguration);
            await productImageIndex.RecordLastAssetDownload("945051", DateTime.UtcNow);
        }

        private static async Task TestWebDamAndCosmosDbIndex()
        {
            WebDamClient client = new WebDamClient(WebDamConfiguration);

            IProductImageIndex productImageIndex = new CosmosDbProductImageIndex(CosmosDbConfiguration);
            IWebDamAssetCrawler assetCrawler = new WebDamAssetCrawler(client);
            IIndexInitialiser indexInitialiser = new WebDamIndexInitialiser(assetCrawler);
            await indexInitialiser.InitialiseIndexFromFolderRecursively(productImageIndex, ProductsTopFolderId);
        }


        private static async Task TestCosmosDb()
        {
            IProductImageIndex productImageIndex = new CosmosDbProductImageIndex(CosmosDbConfiguration);

            BamAssetDetails assetDetails = new BamAssetDetails
            {
                ProductName = "Some Sku",
                AssetId = 1,
                LastModifiedUtc = DateTime.UtcNow
            };

            await productImageIndex.AddOrUpdateAssetForEntry(assetDetails);

            List<CosmosDbImageServiceEntry> entries = (await productImageIndex.GetAllEntries()).ToList();
        }

        private static async Task TestWebDamDownload()
        {
            WebDamClient client = new WebDamClient(WebDamConfiguration);

            byte[] imageBytes = await client.DownloadImageAsset(8100804);

            using (MagickImage image = new MagickImage(imageBytes))
            {
                MagickGeometry size = new MagickGeometry(1024, 1024) { Greater = true };
                image.Resize(size);
                image.Quality = 100;
                image.Format = MagickFormat.Jpeg;
                image.Write("C:\\temp\\test.jpg");
            }
        }

        private static WebDamConfiguration GetWebDamConfiguration()
        {
            return GetConfiguration().GetSection("WebDamConfiguration").Get<WebDamConfiguration>();
        }

        private static CosmosDbConfiguration GetCosmosDbConfiguration()
        {
            return GetConfiguration().GetSection("CosmosDbConfiguration").Get<CosmosDbConfiguration>();
        }

        private static string GetConfigValue(string key)
        {
            return GetConfiguration().GetValue<string>(key);
        }

        private static IConfigurationRoot GetConfiguration()
        {
            var builder = new ConfigurationBuilder()
                          .SetBasePath(Directory.GetCurrentDirectory())
                          .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

            var dotNetCoreEnv = Environment.GetEnvironmentVariable("NETCORE_ENVIRONMENT");

            bool isDevelopment = (dotNetCoreEnv ?? "development").ToLower().Equals("development");
            if (isDevelopment)
            {
                builder.AddUserSecrets<Program>();
            }

            return builder.Build();
        }

    }
}
