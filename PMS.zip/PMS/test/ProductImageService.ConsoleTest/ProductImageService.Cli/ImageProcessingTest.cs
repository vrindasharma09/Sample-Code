﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using ImageMagick;
using ProductImageService.Execution;
using ProductImageService.Execution.Helpers.ImageProcessing;
using ProductImageService.Execution.Models.ImageProcessing;

namespace ProductImageService.Cli
{
    public class ImageProcessingTest
    {
        public static void Execute()
        {
            var scenarios = GetScenarios();
            while (scenarios.Count > 0)
            {
                Execute(scenarios.Pop(), scenarios.Count + 1);
            }
        }

        private static Stack<TransformInstructions> GetScenarios()
        {
            const int widthSm = 400;
            const int heightSm = 400;

            const int width = 800;
            const int height = 600;

            const int widthLg = 4000;
            const int heightLg = 3000;
            string backgroundColor = "#6EB079";

            Stack<TransformInstructions> scenarios = new Stack<TransformInstructions>();

            // Pad
            scenarios.Push(new TransformInstructions(width, height));

            // Crop
            scenarios.Push(new TransformInstructions(widthSm, heightSm, TransformMode.Crop));

            // Crop with different gravity
            scenarios.Push(new TransformInstructions(widthSm, heightSm, TransformMode.Crop) { CropGravity = CropGravity.East })
            ;

            // CropPad with different gravity
            scenarios.Push(new TransformInstructions(widthSm, heightSm, TransformMode.CropPad)
            {
                CropPaddingInPixel = 30,
                CropGravity = CropGravity.East
            });

            // CropPad
            scenarios.Push(new TransformInstructions(widthSm, heightSm, TransformMode.CropPad) { CropPaddingInPixel = 30 });

            // Pad - scale to large
            scenarios.Push(new TransformInstructions(widthLg, heightLg));

            // Pad without scaling
            scenarios.Push(new TransformInstructions(widthLg, heightLg, TransformMode.Pad, false));
            
            // Pad with different background color
            scenarios.Push(new TransformInstructions(width, height, TransformMode.Pad, true, backgroundColor));

            // CropPad with different background color
            scenarios.Push(new TransformInstructions(widthSm, heightSm, TransformMode.CropPad)
            {
                CropPaddingInPixel = 30,
                CropGravity = CropGravity.East,
                BackgroundColorHexCode = backgroundColor
            });

            // CropPad with different gravity & background color
            scenarios.Push(new TransformInstructions(widthSm, heightSm, TransformMode.CropPad)
            {
                CropPaddingInPixel = 30,
                CropGravity = CropGravity.East,
                BackgroundColorHexCode = backgroundColor
            });

            // Different image format
            scenarios.Push(new TransformInstructions(width, height)
            {
                ImageFormat = MagickFormat.Png
            });

            // Invalid CropPad Instruction (i.e. padding is greater that total width provided)
            scenarios.Push(new TransformInstructions(600, 600, TransformMode.CropPad)
            {
                CropPaddingInPixel = 400
            });

            // Invalid Crop Instruction (i.e. width & height is required for cropping)
            scenarios.Push(new TransformInstructions(600, 0, TransformMode.Crop));

            

            return scenarios;
        }

        private static void Execute(TransformInstructions instructions, int index = -1)
        {
            if (instructions.IsValid())
            {
                string rootPath = @"C:\temp\image-processing-test\";

                string inPath = rootPath + "test-1.jpeg";
                string outPath = rootPath + @"out\" + (index >= 0 ? index.ToString() + "-" : string.Empty) + instructions;
                if (File.Exists(outPath)) File.Delete(outPath);

                using (Stream outputStream = File.Create(outPath))
                {
                    ImageProcessingHelper.Start(File.OpenRead(inPath), outputStream, instructions);
                    Byte[] title = new UTF8Encoding(true).GetBytes(outPath);
                    outputStream.Write(title, 0, title.Length);
                }
            }
            else
            {
                Console.WriteLine("not a valid instruction - " + instructions);
            }
        }
    }
}
