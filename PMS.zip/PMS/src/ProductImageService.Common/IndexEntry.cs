﻿using System;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using Microsoft.Azure.Cosmos.Table;

namespace ProductImageService.Common
{
    public class IndexEntry : TableEntity
    {
        public static IndexEntry CreateFromAsset(BrandFolderAssetDetails assetDetails)
        {
            assetDetails.ProductName = assetDetails.ProductName.ToUpper();
            return new IndexEntry
            {
                BrandFolderAssetId = assetDetails.BrandFolderAssetId,
                BrandFolderSectionId = assetDetails.BrandFolderSectionId,
                BrandFolderLastModifiedUtc = assetDetails.LastModifiedUtc,
                RowKey = WebUtility.UrlEncode(IdFromProductName(assetDetails.ProductName)),
                PartitionKey = assetDetails.BrandFolderSectionId,
                LastDownloadedUtc = new DateTime(1750, 1, 2, 23, 0, 0, 0),
                BrandFolderAttachmentId = assetDetails.Attachments.FirstOrDefault()
            };
        }

        public DateTime? LastDownloadedUtc { get; set; }

        public string BrandFolderAssetId { get; set; }

        public string BrandFolderSectionId { get; set; }

        public string BrandFolderAttachmentId { get; set; }

        public DateTime? BrandFolderLastModifiedUtc { get; set; }

        public enum LaerdalImageType
        {
            SkuImage
        }

        public string ImageType { get; set; } = LaerdalImageType.SkuImage.ToString();

        [IgnoreProperty]
        public LaerdalImageType ImageTypeEnum
        {
            get
            {
                Enum.TryParse(ImageType, out LaerdalImageType imageTypeEnumResult);
                return imageTypeEnumResult;
            }
            set => ImageType = value.ToString();
        }

        public enum DownloadStatusType
        {
            Pending,
            Completed,
            Deleted
        }

        public string DownloadStatus { get; set; } = DownloadStatusType.Pending.ToString();

        [IgnoreProperty]
        public DownloadStatusType DownloadStatusEnum
        {
            get
            {
                Enum.TryParse(DownloadStatus, out DownloadStatusType downloadEnumResult);
                return downloadEnumResult;
            }
            set => DownloadStatus = value.ToString();
        }

        private static string IdFromProductName(string productName) =>
            Regex.Replace(productName.ToUpper(), @"[\?/\\#]", "_");        
    }
}