﻿using System.Reflection;

namespace ProductImageService.Common
{
    public class EnumHelper
    {
        /// <summary>
        /// Gets the description of an enum member from the translate service. 
        /// </summary>
        /// <typeparam name="TEnum"></typeparam>
        /// <param name="value"></param>
        /// <param name="label"></param>
        /// <returns></returns>
        public static bool TryGetEnumDescription<TEnum>(TEnum value, out string label)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());
            label = "";
            System.ComponentModel.DescriptionAttribute[] attributes = (System.ComponentModel.DescriptionAttribute[])fi.GetCustomAttributes(typeof(System.ComponentModel.DescriptionAttribute), false);

            if ((attributes.Length > 0))
            {
                label = attributes[0].Description;
                return true;
            }

            return false;
        }

        public static string GetEnumDescription<TEnum>(TEnum value)
        {
            if (TryGetEnumDescription(value, out string label))
            {
                return label;
            }

            return string.Empty;
        }
    }
}
