﻿using System;

namespace ProductImageService.Common
{
    public class BrandFolderAssetDetails
    {
        public string BrandFolderAssetId { get; set; }

        public string ProductName { get; set; }

        public string BrandFolderSectionId { get; set; }

        public string[] Attachments { get; set; }

        public DateTime LastModifiedUtc { get; set; }
    }
}