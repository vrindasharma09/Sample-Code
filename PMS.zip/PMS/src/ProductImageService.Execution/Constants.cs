﻿using ImageMagick;
using ProductImageService.Execution.Models.ImageProcessing;
using System.Text.RegularExpressions;

namespace ProductImageService.Execution
{
    public static class Constants
    {
        public static readonly Regex ProductImageSpecificationRegex = new Regex(@"(sku)/([a-zA-Z0-9-]+)(\?.+)?");

        public class DefaultValues
        {
            public const string BackgroundColor = "#FFFFFF";
            public const MagickFormat ImageFormat = MagickFormat.Jpeg;
            public const CropGravity CroppingGravity = CropGravity.Center;
            public const int Width = 800;
            public const int Height = 600;
            public const int StandardWidthForBlobStorage = 1280;
            public const int NotificationCrawlLimit = 1000;
            public const int ImageQuality = 85;
        }

        public static class Functions
        {
            public const string InitiateCrawl = "InitiateCrawl";
            public const string SectionsCrawl = "SectionsCrawl";
            public const string AssetsCrawl = "AssetsCrawl";
            public const string CrawlModifiedAsset = "CrawlModifiedAsset";
            public const string IndexAssets = "IndexAssets";
            public const string DownloadOriginalAndUploadToBlob = "DownloadOriginalAndUploadToBlob";
            public const string ServeProductImage = "ServeProductImage";
        }

        public static class Queues
        {
            public const string PendingSections = "pending-sections";
            public const string PendingAssets = "pending-assets";
            public const string PendingDownloads = "pending-downloads";
            public const string AssetsToIndex = "pending-assets-index";
        }

        public static class ScheduleExpressions
        {
            public const string InitiateCrawlExp = "%InitiateCrawl.Schedule%";
            public const string CrawlModifiedAssetExp = "%CrawlModifiedAsset.Schedule%";
        }

        public static class Routes
        {
            public const string ServeProductImage = "ServeOrCreateProductImage/{*productImageSpecification}";
        }

        public static class IndexDb
        {
            public const string IndexTableName = "BrandFolderAssetsIndex";
        }

        public const string ImageDownloadHttpClient = "ImageDownloader";

        public const string CloudflarePurgingHttpClient = "CloudflarePurging";

        public static class BlobStorage
        {
            public const string SkuContainer = "sku";
        }
    }
}
