﻿using System;
using Microsoft.Azure.Storage.Blob;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Azure.Storage.RetryPolicies;

namespace ProductImageService.Execution.Helpers
{
    public static class BlobHelper
    {
        public static async Task DeleteExistingImagesForProductAsync(string productName, CloudBlobContainer container)
        {
            var blobsToDelete = new List<IListBlobItem>(0);
            var cToken = new BlobContinuationToken();
            try
            {
                do
                {
                    BlobResultSegment searchByProductName =
                        await container.ListBlobsSegmentedAsync(
                            productName,
                            true,
                            BlobListingDetails.None,
                            null,
                            cToken,
                            new BlobRequestOptions {RetryPolicy = new ExponentialRetry(TimeSpan.FromSeconds(3), 5 )},
                            null);

                    cToken = searchByProductName.ContinuationToken;

                    blobsToDelete.AddRange(searchByProductName.Results);
                } while (cToken != null);
            }
            catch (Exception e)
            {
                Log.Warning(e, "Error while deleting existing images for {ProductName}", productName);
            }

            // after search of blobs is complete, queue up deletion of tasks
            await Task.WhenAll(blobsToDelete.Cast<CloudBlob>().Select(DeleteBlobIfExists)).ConfigureAwait(false);
        }

        private static Task DeleteBlobIfExists(CloudBlob blobToDelete)
        {
            Log.Information("Deleting if blob exists - {BlobName}", blobToDelete.Name);
            return blobToDelete.DeleteIfExistsAsync();
        }
    }
}
