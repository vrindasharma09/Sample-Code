﻿using System;
using System.IO;
using ImageMagick;
using ProductImageService.Execution.Extensions;
using ProductImageService.Execution.Models.ImageProcessing;
using Serilog;

namespace ProductImageService.Execution.Helpers
{
    public static class ImageProcessingHelper
    {
        public static void Start(Stream inputStream, Stream outputStream, TransformInstructions instructions)
        {
            Log.Debug("Starting image transformation");
            var image = new MagickImage(inputStream);

            try
            {
                if (instructions.Upscale &&
                    (image.Width < instructions.WidthInPixel || image.Height < instructions.HeightInPixel))
                {
                    Upscale(image, instructions.WidthInPixel, instructions.HeightInPixel);
                }

                if (instructions.TransformMode == TransformMode.Crop)
                {
                    Crop(image, instructions.WidthInPixel, instructions.HeightInPixel, instructions.CropGravity.Map());
                }
                else if (instructions.TransformMode == TransformMode.Pad)
                {
                    Resize(image, instructions.WidthInPixel, instructions.HeightInPixel);
                    Extent(image, instructions.WidthInPixel, instructions.HeightInPixel,
                        instructions.BackgroundColorHexCode);
                }
                else if (instructions.TransformMode == TransformMode.CropPad)
                {
                    CropPad(
                        image,
                        instructions.WidthInPixel,
                        instructions.HeightInPixel,
                        instructions.BackgroundColorHexCode,
                        instructions.CropGravity.Map(),
                        instructions.CropPaddingInPixel);
                }

                image.Quality = instructions.Quality;
                image.Format = instructions.ImageFormat;
                image.Write(outputStream);

                Log.Debug("Completed image transformation");
            }
            catch (MagickCorruptImageErrorException ex)
            {
                Log.Error(ex, "Magick library failed to transform due to corrupt image");
            }
            catch (MagickException ex)
            {
                Log.Error(ex, "Magick library failed to transform image");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Failed to transform image");
            }
            finally
            {
                image.Dispose();
            }
        }

        private static void Resize(MagickImage image, int width, int height)
        {
            var geometry = new MagickGeometry(width, height) {Greater = true};
            image.Resize(geometry);
        }

        private static void Extent(MagickImage image, int width, int height, string bgColorHexCode)
        {
            var geometry = new MagickGeometry(width, height) {Greater = true};
            image.BackgroundColor = new MagickColor(bgColorHexCode);
            image.Extent(geometry, Gravity.Center);
        }

        private static void Upscale(MagickImage image, int width, int height)
        {
            image.Scale(new MagickGeometry(width, height));
        }

        private static void Crop(MagickImage image, int width, int height, Gravity gravity)
        {
            var geometry = new MagickGeometry(width, height) {IgnoreAspectRatio = true};
            image.Crop(geometry, gravity);
        }

        private static void CropPad(MagickImage image, int width, int height, string bgColorHexCode, Gravity gravity, int padding)
        {
            Crop(image, width, height, gravity);
            Resize(image, width - padding * 2, height - padding * 2);
            Extent(image, width, height, bgColorHexCode);
        }
    }
}