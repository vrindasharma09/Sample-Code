﻿using System.IO;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ProductImageService.BrandFolderApi;
using ProductImageService.Execution;
using ProductImageService.Execution.Extensions;

[assembly: FunctionsStartup(typeof(Startup))]

namespace ProductImageService.Execution
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            var services = builder.Services;

            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();

            services.AddSerilog(configuration);
            
            services.Configure<BrandFolderOptions>(configuration.GetSection("BrandFolderOptions"));
            services.Configure<CloudflareOptions>(configuration.GetSection("CloudflareOptions"));
            services.AddBrandFolderApi(configuration);
            services.AddImageDownloadHttpClientWithRetryPolicy();
        }
    }
}