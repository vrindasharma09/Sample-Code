﻿using Microsoft.Azure.Cosmos.Table;
using Microsoft.Azure.WebJobs;
using ProductImageService.Common;
using Serilog;
using System.Threading.Tasks;
using static ProductImageService.Execution.Constants.Functions;
using static ProductImageService.Execution.Constants.IndexDb;
using static ProductImageService.Execution.Constants.Queues;

namespace ProductImageService.Execution.Functions
{
    public class Index
    {
        private readonly ILogger _log;

        public Index(ILogger log)
        {
            _log = log.ForContext<Index>();
        }

        /// <summary>
        ///     Binding to a azure table storage index via attributes to add/update an index
        /// </summary>
        [FunctionName(IndexAssets)]
        public async Task IndexAssetsAsync(
            [QueueTrigger(AssetsToIndex)] IndexEntry assetToIndex,
            [Table(IndexTableName)] IAsyncCollector<IndexEntry> indexTable,
            [Table(IndexTableName, "{PartitionKey}", "{RowKey}")] IndexEntry indexEntry,
            [Table(IndexTableName)] CloudTable cloudTable)
        {
            _log.Information("Updating index with item {@IndexEntry}", assetToIndex);

            if (indexEntry != null && 
                (indexEntry.BrandFolderAssetId != assetToIndex.BrandFolderAssetId || indexEntry.BrandFolderAttachmentId != assetToIndex.BrandFolderAttachmentId))
            {
                // Re-download if associated attachment is changed
                var updateOperation = TableOperation.Delete(indexEntry);
                await cloudTable.ExecuteAsync(updateOperation);

                indexEntry = null;
            }

            if (indexEntry == null)
            {
                await indexTable.AddAsync(assetToIndex);
            }
        }
    }
}
