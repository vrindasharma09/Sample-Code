﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.Storage.Blob;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using ProductImageService.BrandFolderApi;
using ProductImageService.Common;
using ProductImageService.Execution.Helpers;
using ProductImageService.Execution.Models.ImageProcessing;
using ProductImageService.Execution.Models.Queue;
using Serilog;
using Serilog.Context;
using Serilog.Core.Enrichers;
using static ProductImageService.Execution.Constants.Functions;
using static ProductImageService.Execution.Constants.IndexDb;
using static ProductImageService.Execution.Constants.Queues;
using static ProductImageService.Execution.Constants;

namespace ProductImageService.Execution.Functions
{
    public class Download
    {
        private readonly IBrandFolderApi _brandFolderApi;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger _log;
        private static readonly TransformInstructions DefaultImageTransforms = new TransformInstructions(width: Constants.DefaultValues.StandardWidthForBlobStorage);
        private readonly CloudflareOptions _cloudflareOptions;

        public Download(IBrandFolderApi brandFolderApi, IHttpClientFactory httpClientFactory, ILogger log, IOptions<CloudflareOptions> options)
        {
            _brandFolderApi = brandFolderApi;
            _httpClientFactory = httpClientFactory;
            _log = log.ForContext<Download>();
            _cloudflareOptions = options.Value;
        }

        /// <summary>
        ///     This function will download all assets from the pending-downloads queue
        ///     and upload the original to blob storage with max width 1280 width
        /// </summary>
        [FunctionName(DownloadOriginalAndUploadToBlob)]
        public async Task DownloadOriginalAndUploadToBlobAsync(
            [QueueTrigger(PendingDownloads)] PendingDownload pendingDownload,
            [Blob(BlobStorage.SkuContainer)] CloudBlobContainer container,
            [Table(IndexTableName)] CloudTable cloudTable,
            IBinder binder)
        {
            await container.CreateIfNotExistsAsync();
            await BlobHelper.DeleteExistingImagesForProductAsync(pendingDownload.ProductName, container);

            var pathAndFileName = pendingDownload.TargetPath + "/" + pendingDownload.TargetFileName;

            var stopwatch = Stopwatch.StartNew();

            var attachment = await _brandFolderApi.GetAttachmentAsync(pendingDownload.AttachmentId);
            var downloadClient = _httpClientFactory.CreateClient(Constants.ImageDownloadHttpClient);
            using var response = await downloadClient.GetAsync(attachment.data.attributes.url);
            await using var originalImageStream = await response.Content.ReadAsStreamAsync();

            await using (var targetBlobStream =
                binder.Bind<Stream>(new BlobAttribute(pathAndFileName, FileAccess.Write)))
            {
                using (LogContext.Push(
                    new PropertyEnricher("ProductImageType", "sku"),
                    new PropertyEnricher("ProductName", pendingDownload.ProductName),
                    new PropertyEnricher("ImageTransforms", DefaultImageTransforms.ToString())))
                {
                    ImageProcessingHelper.Start(originalImageStream, targetBlobStream, DefaultImageTransforms);
                    stopwatch.Stop();
                }
            }

            _log.Information("Uploaded to blob storage {BlobPath} with {Width}px width",
                pathAndFileName,
                Constants.DefaultValues.StandardWidthForBlobStorage
            );

            _log.Debug(
                "[{TotalTimeTaken} secs], Processed pending download asset {ProductName} ({AssetId}) to blob storage.",
                stopwatch.Elapsed,
                pendingDownload.ProductName,
                pendingDownload.AssetId
            );

            _log.Information("Updating table storage for {ProductName} ({AssetId})",
                pendingDownload.ProductName, pendingDownload.AssetId);

            await UpdateEntriesOnDownloadCompletion(pendingDownload, cloudTable);
            await PurgeSkuImageUrlAsync(pendingDownload.ProductName);

            _log.Information("Updated table storage download status to completed for {ProductName} ({AssetId})",
                pendingDownload.ProductName, pendingDownload.AssetId);
        }

        private static async Task UpdateEntriesOnDownloadCompletion(PendingDownload pendingDownload,
            CloudTable cloudTable)
        {
            var updateEntries =
                await cloudTable.ExecuteAsync(
                    TableOperation.Retrieve<IndexEntry>(pendingDownload.SectionId, pendingDownload.ProductName));

            var updateEntity = (IndexEntry)updateEntries.Result;
            if (updateEntity != null)
            {
                updateEntity.DownloadStatusEnum = IndexEntry.DownloadStatusType.Completed;
                updateEntity.LastDownloadedUtc = DateTime.UtcNow;

                var updateOperation = TableOperation.InsertOrReplace(updateEntity);
                await cloudTable.ExecuteAsync(updateOperation);
            }
        }

        private async Task PurgeSkuImageUrlAsync(string sku)
        {
            try
            {
                var apiUrl = $"https://api.cloudflare.com/client/v4/zones/{_cloudflareOptions.ZoneId}/purge_cache";
                var apiToken = _cloudflareOptions.Token;
                var imageUrlPattern = !string.IsNullOrEmpty(_cloudflareOptions.ImageSkuPattern)
                    ? _cloudflareOptions.ImageSkuPattern
                    : BrandFolderApi.Constants.CloudflareConstants.DefaultImageSkuPattern;

                var purgedSkuImageUrl = $"{_cloudflareOptions.EcommerceBaseUrl.TrimEnd('/')}/{imageUrlPattern.Replace("{sku}", sku)}";

                var payload = new
                {
                    files = new[] { purgedSkuImageUrl }
                };

                var jsonPayload = JsonConvert.SerializeObject(payload);
                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

                var client = _httpClientFactory.CreateClient(Constants.CloudflarePurgingHttpClient);
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiToken}");

                var response = await client.PostAsync(apiUrl, content);
                if (response.IsSuccessStatusCode)
                {
                    _log.Information("Cache purged successfully for sku {sku}", sku);
                }
                else
                {
                    _log.Information("Cache purged Failed for sku {sku} with status {status}", sku, response.StatusCode);
                }
            }
            catch (Exception e)
            {
                _log.Information("Cache purged Failed for sku {sku} with error {@e}", sku, e);
            }
        }
    }
}