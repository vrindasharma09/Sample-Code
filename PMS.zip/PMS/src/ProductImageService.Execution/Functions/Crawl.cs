﻿using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Options;
using Microsoft.Azure.Cosmos.Table;
using ProductImageService.BrandFolderApi;
using ProductImageService.Common;
using ProductImageService.Execution.Crawler;
using ProductImageService.Execution.Models.Queue;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static ProductImageService.Execution.Constants.Functions;
using static ProductImageService.Execution.Constants.IndexDb;
using static ProductImageService.Execution.Constants.Queues;
using static ProductImageService.Execution.Constants.ScheduleExpressions;

namespace ProductImageService.Execution.Functions
{
    public class Crawl
    {
        private readonly IBrandFolderApi _brandFolderApi;
        private readonly BrandFolderOptions _brandfolderOptions;
        private readonly ILogger _log;

        public Crawl(IBrandFolderApi brandFolderApi,
            IOptions<BrandFolderOptions> brandfolderOptions, 
            ILogger log)
        {
            _brandfolderOptions = brandfolderOptions.Value;
            _brandFolderApi = brandFolderApi;
            _log = log.ForContext<Crawl>();
        }

        /// <summary>
        ///     This function will add all sections to pending section queue
        /// </summary>
        [FunctionName(InitiateCrawl)]
        public async Task InitiateCrawlAsync(
            [TimerTrigger(InitiateCrawlExp)] TimerInfo timer,
            [Queue(PendingSections)] IAsyncCollector<PendingSection> sectionsToCrawl)
        {
            _log.Information("Initiating crawl - starting from section ids {SectionIds}", _brandfolderOptions.SectionIds);

            List<string> sections = _brandfolderOptions.SectionIds.Split(new char[] { ',' }).ToList();
            foreach (string secId in sections)
            {
                await sectionsToCrawl.AddAsync(new PendingSection(secId));
            }
        }

        /// <summary>
        ///     This function will crawl all asset id's based on provide section from pending-sections queue
        /// </summary>
        [FunctionName(SectionsCrawl)]
        public async Task CrawlSectionsAsync(
            [QueueTrigger(PendingSections)] PendingSection pendingSection,
            [Queue(PendingAssets)] IAsyncCollector<PendingAsset> assetsToCrawl)
        {
            var assetCrawler = new BandFolderAssetCrawler(_brandFolderApi);
            assetCrawler.AssetEncountered += async (s, e) => await WhenAssetEncountered(e, assetsToCrawl);
            await assetCrawler.CrawlOneSectionAsync(pendingSection.SectionId);
        }

        private async Task WhenAssetEncountered(BandFolderAssetEncounteredEventArgs e,
            IAsyncCollector<PendingAsset> assetsToCrawl)
        {
            _log.Information("Asset encountered - {AssetId}", e.AssetId);
            await assetsToCrawl.AddAsync(new PendingAsset(e.AssetId, e.SectionId));
        }

        /// <summary>
        ///     This function will crawl asset details based on provide asset from pending-assets queue
        /// </summary>
        [FunctionName(AssetsCrawl)]
        public async Task CrawlAssetsAsync(
            [QueueTrigger(PendingAssets)] PendingAsset pendingAsset,
            [Queue(AssetsToIndex)] IAsyncCollector<IndexEntry> assetsToIndex)
        {
            var assetCrawler = new BandFolderAssetCrawler(_brandFolderApi);
            assetCrawler.AssetCrawlComplete += async (s, e) => await WhenAssetCrawlComplete(e, assetsToIndex);
            await assetCrawler.CrawlOneAssetAsync(pendingAsset);
        }

        private async Task WhenAssetCrawlComplete(BandFolderAssetCrawlCompleteEventArgs e,
            IAsyncCollector<IndexEntry> assetsToIndex)
        {
            _log.Information(
                "Asset encountered - {ProductName} ({BrandFolderAssetId}), last modified on {LastModifiedUtc}",
                e.BrandFolderAssetDetails.ProductName,
                e.BrandFolderAssetDetails.BrandFolderAssetId,
                e.BrandFolderAssetDetails.LastModifiedUtc);

            await assetsToIndex.AddAsync(IndexEntry.CreateFromAsset(e.BrandFolderAssetDetails));

            _log.Information("Added asset - {ProductName} ({BrandFolderAssetId}) to AssetToIndex queue",
                e.BrandFolderAssetDetails.ProductName,
                e.BrandFolderAssetDetails.BrandFolderAssetId);
        }

        /// <summary>
        ///     This function will crawl all modified asset to index documents from azure storage table and add to pending-downloads queue
        /// </summary>
        [FunctionName(CrawlModifiedAsset)]
        public async Task CrawlModifiedAssetAsync(
            [TimerTrigger(CrawlModifiedAssetExp)] TimerInfo timer,
            [Queue(PendingDownloads)] IAsyncCollector<PendingDownload> pendingDownloads,
            [Table(IndexTableName)] CloudTable cloudTable)
        {
            _log.Information("Started queueing newly modified assets for download");

            TableQuery<IndexEntry> tableQuery = new TableQuery<IndexEntry>()
                .Where(TableQuery.GenerateFilterCondition("DownloadStatus", QueryComparisons.Equal,
                    IndexEntry.DownloadStatusType.Pending.ToString()));

            var indexEntries = await cloudTable.ExecuteQuerySegmentedAsync(tableQuery, null);
            var retrievedList = indexEntries.Results.ToList();
            if (!retrievedList.Any())
            {
                _log.Debug("No modified asset found for download, all assets are up to date.");
                return;
            }

            retrievedList.Select(PendingDownload.Create)
                .ToList()
                .ForEach(async pd => { await pendingDownloads.AddAsync(pd); });

            _log.Information(
                "Added newly modified {ModifiedAssetsCount} asset(s) to pending download queue, Asset IDs - {@ModifiedAssets}",
                retrievedList.Count,
                retrievedList.Select(e => e.BrandFolderAssetId).ToList()
            );
        }
    }
}