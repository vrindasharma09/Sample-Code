﻿using ImageMagick;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.Storage.Blob;
using ProductImageService.Execution.Helpers;
using ProductImageService.Execution.Models.ImageProcessing;
using Serilog;
using Serilog.Context;
using Serilog.Core;
using Serilog.Core.Enrichers;
using System;
using System.Collections.Specialized;
using System.IO;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Http;

namespace ProductImageService.Execution.Functions
{
    public class Serve
    {
        private static ILogger _log;

        public Serve(ILogger log)
        {
            _log = log.ForContext<Serve>();
        }

        [FunctionName(Constants.Functions.ServeProductImage)]
        public async Task<IActionResult> ServeProductImageAsync(
            [HttpTrigger(
                AuthorizationLevel.Function,
                "get",
                Route = Constants.Routes.ServeProductImage
            )]
            HttpRequestMessage req,
            IBinder binder)
        {
            NameValueCollection queryStringParameters = req.RequestUri.ParseQueryString();
            TransformInstructions instructions = GetTransformInstructionsFromQueryString(queryStringParameters);

            Match piSpecMatch = Constants.ProductImageSpecificationRegex.Match(req.RequestUri.PathAndQuery);

            string productImageType = piSpecMatch.Groups[1].Value;
            string productName = piSpecMatch.Groups[2].Value;

            _log.Debug("Started processing serve request for {productImageType} ({ProductName})...", productImageType, productName);
            if (!instructions.IsValid() || !piSpecMatch.Success)
            {
                _log.Warning("Invalid transformation instructions provided for {productImageType} ({ProductName}) [{Instructions}]", productImageType, productName, instructions);
                return new BadRequestResult();
            }

            return await GetTransformedImageResult(productImageType, productName, instructions, binder);
        }

        private static TransformInstructions GetTransformInstructionsFromQueryString(NameValueCollection queryStringParameters)
        {
            TransformInstructions instructions = new TransformInstructions(width: Constants.DefaultValues.Width, height: Constants.DefaultValues.Height);

            if (int.TryParse(queryStringParameters["w"], out var width))
            {
                instructions.WidthInPixel = width;
            }
            if (int.TryParse(queryStringParameters["h"], out var height))
            {
                instructions.HeightInPixel = height;
            }

            instructions.TransformMode = GetMode(queryStringParameters["m"]);

            instructions.Upscale = true;
            if (bool.TryParse(queryStringParameters["scale"], out var upscale))
            {
                instructions.Upscale = upscale;
            }

            instructions.CropGravity = GetCropGravity(queryStringParameters["cg"]);
            if (int.TryParse(queryStringParameters["cp"], out var cropPadding))
            {
                instructions.CropPaddingInPixel = cropPadding;
            }

            if (!string.IsNullOrWhiteSpace(queryStringParameters["bg"]))
            {
                instructions.BackgroundColorHexCode = "#" + queryStringParameters["bg"];
            }

            if (int.TryParse(queryStringParameters["q"], out var imageQuality))
            {
                instructions.Quality = imageQuality;
            }

            instructions.ImageFormat = GetExtensionFromQueryString(queryStringParameters["ext"]);

            return instructions;
        }

        private static async Task<IActionResult> GetTransformedImageResult(
            string productImageType,
            string productName,
            TransformInstructions instructions,
            IBinder binder)
        {
            string resizePath = $"{productImageType}/{productName}/{productName}-{instructions}";
            using (LogContext.Push(
                new PropertyEnricher("ProductImageType", productImageType),
                new PropertyEnricher("ProductName", productName),
                new PropertyEnricher("Instruction", instructions),
                new PropertyEnricher("BlobPath", resizePath)))
            {
                CloudBlockBlob resizedImageBlob = binder.Bind<CloudBlockBlob>(new BlobAttribute(resizePath, FileAccess.ReadWrite));

                if (!await resizedImageBlob.ExistsAsync())
                {
                    // resized blob does not exist yet, create from original image blob
                    string originalPath = $"{productImageType}/{productName}/{productName}-origin.jpeg";
                    CloudBlockBlob originalImageBlob = binder.Bind<CloudBlockBlob>(new BlobAttribute(originalPath, FileAccess.Read));

                    using (LogContext.Push(new ILogEventEnricher[] { new PropertyEnricher("BlobPath", originalPath) }))
                    {
                        if (!await originalImageBlob.ExistsAsync())
                        {
                            Log.Warning("Image blob not found for {ProductImageType} ({ProductName}) [{BlobPath}]");
                            return new NotFoundResult();
                        }
                    }

                    if (!await CreateResizedBlobFromOriginal(originalImageBlob, resizedImageBlob, instructions))
                    {
                        Log.Warning("Image transformation failed for {ProductImageType} ({ProductName}) [{Instruction}]");
                        return new InternalServerErrorResult();
                    }
                }
                else
                {
                    Log.Debug("Serving {ProductImageType} image from blob storage for {ProductName} [{BlobPath}]");
                }

                Log.Debug("Completed serve request for {ProductImageType} ({ProductName})");
                return new FileStreamResult(await resizedImageBlob.OpenReadAsync(), $"image/{instructions.ImageFormat.ToString().ToLower()}");
            }
        }

        private static TransformMode GetMode(string m)
        {
            switch (m)
            {
                case "c": return TransformMode.Crop;
                case "cp": return TransformMode.CropPad;
                default: return TransformMode.Pad;
            }
        }

        private static CropGravity GetCropGravity(string g)
        {
            switch (g)
            {
                case "e": return CropGravity.East;
                case "w": return CropGravity.West;
                case "n": return CropGravity.North;
                case "s": return CropGravity.South;
                default: return Constants.DefaultValues.CroppingGravity;
            }
        }

        private static MagickFormat GetExtensionFromQueryString(string extension) => 
            Enum.TryParse(extension, true, out MagickFormat format) ? format : Constants.DefaultValues.ImageFormat;

        private static async Task<bool> CreateResizedBlobFromOriginal(CloudBlockBlob originalImageBlob, CloudBlockBlob resizedImageBlob, TransformInstructions instructions)
        {
            using (var originalBlobStream = await originalImageBlob.OpenReadAsync())
            {
                using (var resizedBlobStream = await resizedImageBlob.OpenWriteAsync())
                {
                    ImageProcessingHelper.Start(originalBlobStream, resizedBlobStream, instructions);
                }
            }
            return true;
        }
    }
}
