﻿using ProductImageService.Common;

namespace ProductImageService.Execution.Models.Queue
{
    public class PendingDownload
    {
        public string AssetId { get; set; }
        public string SectionId { get; set; }
        public string AttachmentId { get; set; }
        public string ProductName { get; set; }
        public string TargetPath { get; set; }
        public string TargetFileName { get; set; }

        public static PendingDownload Create(IndexEntry indexEntry)
        {
            var download = new PendingDownload
            {
                AssetId = indexEntry.BrandFolderAssetId,
                SectionId = indexEntry.BrandFolderSectionId,
                AttachmentId = indexEntry.BrandFolderAttachmentId,
                ProductName = indexEntry.RowKey,
            };

            switch (indexEntry.ImageTypeEnum)
            {
                case IndexEntry.LaerdalImageType.SkuImage:
                    download.TargetPath = "sku";
                    break;
                default:
                    download.TargetPath = "other";
                    break;
            }

            download.TargetPath += $"/{download.ProductName}";
            download.TargetFileName = $"{download.ProductName}-origin.jpeg";

            return download;
        }
    }
}