﻿namespace ProductImageService.Execution.Models.Queue
{
    public class PendingSection
    {
        public PendingSection(string sectionId)
        {
            SectionId = sectionId;
        }

        public string SectionId;
    }
}
