﻿namespace ProductImageService.Execution.Models.Queue
{
    public class PendingAsset
    {
        public PendingAsset(string assetId, string sectionId)
        {
            AssetId = assetId;
            SectionId = sectionId;
        }

        public string AssetId;
        public string SectionId;
    }
}
