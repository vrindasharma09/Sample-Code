﻿using ImageMagick;

namespace ProductImageService.Execution.Models.ImageProcessing
{
    public struct TransformInstructions
    {
        public TransformInstructions(
            int width = 0,
            int height = 0,
            TransformMode mode = TransformMode.Pad,
            bool upscale = true,
            string bgColor = Constants.DefaultValues.BackgroundColor,
            int imageQuality = Constants.DefaultValues.ImageQuality)
        {
            WidthInPixel = width;
            HeightInPixel = height;
            TransformMode = mode;
            Upscale = upscale;
            BackgroundColorHexCode = bgColor;
            CropPaddingInPixel = 0;
            CropGravity = Constants.DefaultValues.CroppingGravity;
            ImageFormat = Constants.DefaultValues.ImageFormat;
            Quality = imageQuality;
        }

        public bool IsValid()
        {
            if (WidthInPixel <= 0 && HeightInPixel <= 0)
            {
                return false;
            }

            if (TransformMode == TransformMode.Crop || TransformMode == TransformMode.CropPad)
            {
                if (WidthInPixel <= 0 || HeightInPixel <= 0)
                {
                    return false;
                }
            }

            if (TransformMode == TransformMode.CropPad)
            {
                if (WidthInPixel <= CropPaddingInPixel * 2 || HeightInPixel <= CropPaddingInPixel * 2)
                {
                    return false;
                }
            }

            return true;
        }

        public TransformMode TransformMode { get; set; }
        public int WidthInPixel { get; set; }
        public int HeightInPixel { get; set; }

        public bool Upscale { get; set; }
        public string BackgroundColorHexCode { get; set; }
        public int CropPaddingInPixel { get; set; }
        public int Quality { get; set; }

        public CropGravity CropGravity { get; set; }
        public MagickFormat ImageFormat { get; set; }

        public override string ToString()
        {
            string fileName = TransformMode.ToString().ToLower() + "-";

            if (WidthInPixel > 0)
            {
                fileName += "w" + WidthInPixel;
            }

            if (HeightInPixel > 0)
            {
                fileName += fileName.Contains("w") ? "-h" : "h";
                fileName += HeightInPixel;
            }

            if (TransformMode == TransformMode.Crop || TransformMode == TransformMode.CropPad)
            {
                fileName += CropGravity != Constants.DefaultValues.CroppingGravity ? "-cg" + CropGravity.ToString().ToUpperInvariant() : string.Empty;
                fileName += CropPaddingInPixel > 0 ? "-cp" + CropPaddingInPixel : string.Empty;
            }
            else
            {
                fileName += !Upscale ? "-no-upscale-" : string.Empty;
            }

            fileName += TransformMode != TransformMode.Crop && BackgroundColorHexCode != Constants.DefaultValues.BackgroundColor
                ? "-bgHash" + new MagickColor(BackgroundColorHexCode).GetHashCode()
                : string.Empty;

            fileName += Quality != Constants.DefaultValues.ImageQuality
                ? "-q" + Quality
                : string.Empty;

            return $"{fileName}.{ImageFormat.ToString().ToLower()}";
        }
    }

    public enum TransformMode
    {
        Pad,
        Crop,
        CropPad
    }
    public enum CropGravity
    {
        Center,
        East,
        West,
        North,
        South
    }
}
