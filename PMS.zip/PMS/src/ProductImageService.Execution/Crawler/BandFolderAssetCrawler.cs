﻿using ProductImageService.BrandFolderApi;
using ProductImageService.Common;
using ProductImageService.Execution.Models.Queue;
using System;
using System.Linq;
using System.Threading.Tasks;
using static ProductImageService.BrandFolderApi.Constants;

namespace ProductImageService.Execution.Crawler
{
    public class BandFolderAssetEncounteredEventArgs
    {
        public string AssetId { get; set; }
        public string SectionId { get; set; }
    }

    public class BandFolderAssetCrawlCompleteEventArgs
    {
        public BrandFolderAssetDetails BrandFolderAssetDetails { get; set; }
    }


    public class BandFolderAssetCrawler
    {
        private readonly IBrandFolderApi _brandFolderApi;
        public event EventHandler<BandFolderAssetEncounteredEventArgs> AssetEncountered;
        public event EventHandler<BandFolderAssetCrawlCompleteEventArgs> AssetCrawlComplete;

        public BandFolderAssetCrawler(IBrandFolderApi brandFolderApi)
        {
            _brandFolderApi = brandFolderApi;
        }

        public async Task CrawlOneSectionAsync(string sectionId, int page = 1)
        {
            if (AssetEncountered == null)
            {
                return;
            }

            var assets = await _brandFolderApi.GetAssetsAsync(sectionId, page);

            foreach (var data in assets.data)
            {
                var eventArgs = new BandFolderAssetEncounteredEventArgs
                {
                    AssetId = data.id,
                    SectionId = sectionId
                };

                AssetEncountered?.Invoke(this, eventArgs);
            }

            if (assets.meta.current_page < assets.meta.total_pages)
            {
                await CrawlOneSectionAsync(sectionId, assets.meta.current_page++);
            }
        }

        public async Task CrawlOneAssetAsync(PendingAsset pendingAsset)
        {
            if (AssetCrawlComplete == null)
            {
                return;
            }

            var asset = await _brandFolderApi.GetAssetAsync(pendingAsset.AssetId);
            var customFieldValues = asset.included.Where(i => i.type.Equals(CustomFieldKeys.CustomFieldValues));

            var skus = (from cf in asset.data.relationships.custom_field_values.data
                        join inc in asset.included on cf.id equals inc.id
                        where inc.type.Equals(CustomFieldKeys.CustomFieldValues) && inc.attributes.key.Equals(CustomFieldKeys.Sku)
                        select inc.attributes.value).ToList();

            void AddToAssetIndex(string skuNo)
            {
                if (!string.IsNullOrWhiteSpace(skuNo))
                {
                    var eventArgs = new BandFolderAssetCrawlCompleteEventArgs
                    {
                        BrandFolderAssetDetails = new BrandFolderAssetDetails
                        {
                            BrandFolderSectionId = pendingAsset.SectionId,
                            BrandFolderAssetId = asset.data.id,
                            ProductName = skuNo.Trim(),
                            LastModifiedUtc = asset.data.attributes.updated_at,
                            Attachments = asset.data.relationships.attachments.data.Select(d => d.id).ToArray()
                        }
                    };

                    AssetCrawlComplete?.Invoke(this, eventArgs);
                }
            }

            if (skus != null && skus.Any())
            {
                skus.ForEach(sku =>
                {
                    if (sku.Contains(","))
                    {
                        sku.Split(new char[] { ',' }).ToList().ForEach(AddToAssetIndex);
                    }
                    else
                    {
                        AddToAssetIndex(sku);
                    }
                });
            }
        }

    }
}
