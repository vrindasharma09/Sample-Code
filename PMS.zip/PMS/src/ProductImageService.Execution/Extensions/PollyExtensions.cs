﻿using System;
using System.Net.Http;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using Serilog;

namespace ProductImageService.Execution.Extensions
{
    public static class PollyExtensions
    {
        public static void AddImageDownloadHttpClientWithRetryPolicy(this IServiceCollection services)
        {
            // Add HTTP client and hook up a retry policy, defaulting to 5 retry attempts.

            services.AddHttpClient(Constants.ImageDownloadHttpClient)
                .AddTransientHttpErrorPolicy(builder => builder.WaitAndRetryAsync(5, AddJitter, OnRetry));

            void OnRetry(DelegateResult<HttpResponseMessage> outcome, TimeSpan time, int attempt, Context _)
                => Log.Warning("Retrying image download from original source. Attempts: {AttemptsCount}", attempt);
        }

        private static TimeSpan AddJitter(int retryAttempt)
        {
            var jitterer = new Random();
            return TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)) + TimeSpan.FromSeconds(jitterer.Next(0, 20));
        }
    }
}