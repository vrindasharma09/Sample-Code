﻿using System;
using System.Net.Http.Headers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ProductImageService.BrandFolderApi;
using Refit;
using Serilog;

namespace ProductImageService.Execution.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static void AddSerilog(this IServiceCollection services, IConfigurationRoot configuration)
        {
            var loggerConfiguration = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration)
                .Enrich.FromLogContext();

            string appInsightsIKey = Environment.GetEnvironmentVariable("APPINSIGHTS_INSTRUMENTATIONKEY", EnvironmentVariableTarget.Process);
            if (!string.IsNullOrWhiteSpace(appInsightsIKey))
            {
                loggerConfiguration
                    .WriteTo.ApplicationInsights(appInsightsIKey, TelemetryConverter.Events);
            }

            Log.Logger = loggerConfiguration
#if RELEASE
                .Enrich.WithProperty("Application", "Laerdal.ProductImageService.Functions")
                .MinimumLevel.Information()
                .MinimumLevel.Override("Microsoft", Serilog.Events.LogEventLevel.Warning)
                .MinimumLevel.Override("System", Serilog.Events.LogEventLevel.Warning)
#endif
                .CreateLogger();

            //services.AddLogging(loggingBuilder =>
            //    loggingBuilder.AddSerilog(Log.Logger, dispose: true));

            services.AddSingleton(Log.Logger);
        }

        public static void AddBrandFolderApi(this IServiceCollection services, IConfigurationRoot configuration)
        {
            services.AddRefitClient<IBrandFolderApi>()
                    .ConfigureHttpClient((provider, client) =>
                    {
                        Uri.TryCreate(configuration.GetSection("BrandFolderOptions:ApiBaseUrl").Value, UriKind.RelativeOrAbsolute, out var baseUrl);
                        client.BaseAddress = baseUrl;
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", configuration.GetSection("BrandFolderOptions:ApiKey").Value);
                    });
        }
    }
}