﻿using ImageMagick;
using ProductImageService.Execution.Models.ImageProcessing;
using System;

namespace ProductImageService.Execution.Extensions
{
    public static class ImageProcessingExtensions
    {
        public static Gravity Map(this CropGravity cg) =>
            Enum.TryParse<Gravity>(cg.ToString(), out var gravity) ? gravity : Gravity.Center;
    }
}
