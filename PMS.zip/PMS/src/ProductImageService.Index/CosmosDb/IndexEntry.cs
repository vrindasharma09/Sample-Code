﻿using System;
using System.Text.RegularExpressions;
using ProductImageService.Common;

namespace ProductImageService.Index.CosmosDb
{
    public class IndexEntry
    {
        public static IndexEntry CreateFromAsset(BamAssetDetails assetDetails)
        {
            assetDetails.ProductName = assetDetails.ProductName.ToUpper();
            return new IndexEntry {BamAssetDetails = assetDetails, Id = IdFromProductName(assetDetails.ProductName)};
        }

        public string Id { get; set; }

        public ImageType Type { get; set; }

        public BamAssetDetails BamAssetDetails { get; set; }

        public DateTime LastDownloadedUtc { get; set; }

        public enum ImageType
        {
            SkuImage
        }

        /// <summary>
        /// // disallowed character for cosmos db document id  '/', '\\', '?', '#' 
        /// //  https://docs.microsoft.com/en-us/dotnet/api/microsoft.azure.documents.resource.id?view=azure-dotnet
        /// </summary>
        private static string IdFromProductName(string productName) => Regex.Replace(productName.ToUpper(), @"[\?/\\#]", "_");
    }
}