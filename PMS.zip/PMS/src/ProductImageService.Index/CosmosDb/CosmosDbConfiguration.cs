﻿using System;

namespace ProductImageService.Index.CosmosDb
{
    public class CosmosDbConfiguration
    {
        public string EndpointUri { get; set; }
        public string PrimaryKey { get; set; }
        public string DatabaseId { get; set; }
        public string CollectionId { get; set; }


        public static CosmosDbConfiguration CreateFromEnvironment() 
        {
            return new CosmosDbConfiguration() {
                EndpointUri = Environment.GetEnvironmentVariable("CosmosDbConfiguration:EndpointUri", EnvironmentVariableTarget.Process),
                PrimaryKey = Environment.GetEnvironmentVariable("CosmosDbConfiguration:PrimaryKey", EnvironmentVariableTarget.Process),
                DatabaseId = Environment.GetEnvironmentVariable("CosmosDbConfiguration:DatabaseId", EnvironmentVariableTarget.Process),
                CollectionId = Environment.GetEnvironmentVariable("CosmosDbConfiguration:CollectionId", EnvironmentVariableTarget.Process),
            };
        }
    }
}