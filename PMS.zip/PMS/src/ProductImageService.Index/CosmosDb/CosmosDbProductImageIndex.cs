﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using ProductImageService.Common;

namespace ProductImageService.Index.CosmosDb
{
    public class CosmosDbProductImageIndex : IProductImageIndex
    {
        private readonly CosmosDbConfiguration _configuration;

        private readonly Lazy<Task<DocumentClient>> _documentClient;

        private Uri CollectionUri => UriFactory.CreateDocumentCollectionUri(_configuration.DatabaseId, _configuration.CollectionId);

        public CosmosDbProductImageIndex(CosmosDbConfiguration configuration)
        {
            _configuration = configuration;
            _documentClient = new Lazy<Task<DocumentClient>>(async () => await CreateClientAndSetup());
        }

        private async Task<DocumentClient> CreateClientAndSetup()
        {
            var client = new DocumentClient(new Uri(_configuration.EndpointUri), _configuration.PrimaryKey, ConnectionPolicy.Default, ConsistencyLevel.Eventual);
            await client.OpenAsync();
            await client.CreateDatabaseIfNotExistsAsync(new Database { Id = _configuration.DatabaseId });
            await client.CreateDocumentCollectionIfNotExistsAsync(
                UriFactory.CreateDatabaseUri(_configuration.DatabaseId),
                new DocumentCollection { Id = _configuration.CollectionId });

            return client;
        }

        public async Task AddOrUpdateAssetForEntry(BamAssetDetails assetDetails)
        {
            var client = await _documentClient.Value;

            CosmosDbImageServiceEntry cdbEntry = await GetFirstMatchingEntry(cdbe => cdbe.Id == CosmosDbImageServiceEntry.IdFromProductName(assetDetails.ProductName));

            if (cdbEntry == null)
            {
                cdbEntry = new CosmosDbImageServiceEntry(assetDetails);
            }
            else
            {
                cdbEntry.BamAssetDetails = assetDetails;
            }

            await client.UpsertDocumentAsync(CollectionUri, cdbEntry);
        }

        public async Task<IEnumerable<CosmosDbImageServiceEntry>> GetAllEntries() => (await QueryForEntries());

        public async Task<IEnumerable<CosmosDbImageServiceEntry>> GetEntriesModifiedSinceLastDownload()
        {
            return await QueryForEntries(entry => entry.LastDownloadedUtc < entry.BamAssetDetails.LastModifiedUtc);
        }

        public async Task RecordLastAssetDownload(string name, DateTime lastDownloadedTimeUtc)
        {
            CosmosDbImageServiceEntry cdbIndexEntry = await GetFirstMatchingEntry(cdbe => cdbe.BamAssetDetails.ProductName == name);
            if (cdbIndexEntry == null)
            {
                return;
            }

            cdbIndexEntry.LastDownloadedUtc = lastDownloadedTimeUtc;

            var client = await _documentClient.Value;
            await client.UpsertDocumentAsync(CollectionUri, cdbIndexEntry);
        }

        private async Task<CosmosDbImageServiceEntry> GetFirstMatchingEntry(Expression<Func<CosmosDbImageServiceEntry, bool>> whereFunc = null)
        {
            var entries = await QueryForEntries(whereFunc);
            return entries.FirstOrDefault();
        }

        private async Task<IEnumerable<CosmosDbImageServiceEntry>> QueryForEntries(Expression<Func<CosmosDbImageServiceEntry, bool>> whereFunc = null)
        {
            List<CosmosDbImageServiceEntry> entries = new List<CosmosDbImageServiceEntry>();

            var client = await _documentClient.Value;

            FeedOptions queryOptions = new FeedOptions { MaxItemCount = -1, ConsistencyLevel = ConsistencyLevel.Eventual };

            IQueryable<CosmosDbImageServiceEntry> query1 = client.CreateDocumentQuery<CosmosDbImageServiceEntry>(CollectionUri, queryOptions);

            if (whereFunc != null)
            {
                query1 = query1.Where(whereFunc);
            }

            using (var query = query1.AsDocumentQuery())
            {
                while (query.HasMoreResults)
                {
                    foreach (CosmosDbImageServiceEntry cdbIndexEntry in await query.ExecuteNextAsync<CosmosDbImageServiceEntry>())
                    {
                        entries.Add(cdbIndexEntry);
                    }
                }
            }

            return entries;
        }
    }
}