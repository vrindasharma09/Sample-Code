﻿namespace ProductImageService.BrandFolderApi
{
    public class Constants
    {
        public class CustomFieldKeys
        {
            public const string Sku = "SKU";
            public const string CustomFieldValues = "custom_field_values";
        }

        public static class CloudflareConstants
        {
            public const string DefaultImageSkuPattern = "/images/sku/{sku}.png";
        }
    }
}
