﻿namespace ProductImageService.BrandFolderApi
{
    public class BrandFolderOptions
    {
        public string ApiBaseUrl { get; set; }

        public string SectionIds { get; set; }

        public string ApiKey { get; set; }
    }
}
