﻿namespace ProductImageService.BrandFolderApi
{
    public class CloudflareOptions
    {
        public string Token { get; set; }
        public string ZoneId { get; set; }
        public string EcommerceBaseUrl { get; set; }
        public string ImageSkuPattern { get; set; }
    }
}
