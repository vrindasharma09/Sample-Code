﻿using ProductImageService.BrandFolderApi.Dtos;
using Refit;
using System.Threading.Tasks;

namespace ProductImageService.BrandFolderApi
{
    public interface IBrandFolderApi
    {
        [Get("/sections/{sectionId}/assets?page={page}&per={per}&fields=created_at,updated_at&include=attachments,custom_fields")]
        Task<Assets> GetAssetsAsync(string sectionId, int page = 1, int per = 3000);

        [Get("/assets/{assetId}?fields=created_at,updated_at&include=attachments,custom_fields")]
        Task<AssetDetail> GetAssetAsync(string assetId);

        [Get("/attachments/{attachmentId}")]
        Task<Attachment> GetAttachmentAsync(string attachmentId);
    }
}