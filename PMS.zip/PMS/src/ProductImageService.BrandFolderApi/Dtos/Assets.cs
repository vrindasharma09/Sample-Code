﻿using System.Collections.Generic;

namespace ProductImageService.BrandFolderApi.Dtos
{
    public class Assets
    {
        public List<Asset> data { get; set; }
        public List<AssetsIncluded> included { get; set; }
        public Metadata meta { get; set; }
    }

    public class AssetDetail
    {
        public Asset data { get; set; }
        public List<AssetsIncluded> included { get; set; }
    }

    public class AssetsIncluded
    {
        public string id { get; set; }
        public string type { get; set; }
        public AssetsIncludedAttributes attributes { get; set; }
    }

    public class AssetsIncludedAttributes: AttachmentAttributes
    {
        public string key { get; set; }
        public string value { get; set; }
    }
}
