﻿namespace ProductImageService.BrandFolderApi.Dtos
{
    public class Metadata
    {
        public int current_page { get; set; }
        public object next_page { get; set; }
        public object prev_page { get; set; }
        public int total_pages { get; set; }
        public int total_count { get; set; }
    }
}
