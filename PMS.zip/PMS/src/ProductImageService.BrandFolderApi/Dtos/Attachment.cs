﻿using System.Collections.Generic;

namespace ProductImageService.BrandFolderApi.Dtos
{
    public class Attachment
    {
        public AttachmentDetails data { get; set; }
    }

    public class Attachments
    {
        public List<AttachmentDetails> data { get; set; }
    }

    public class AttachmentDetails
    {
        public string id { get; set; }
        public string type { get; set; }
        public AttachmentAttributes attributes { get; set; }
    }

    public class AttachmentAttributes
    {
        public string filename { get; set; }
        public string mimetype { get; set; }
        public string url { get; set; }
        public int size { get; set; }
        public int width { get; set; }
        public int height { get; set; }
        public int position { get; set; }
    }
}
