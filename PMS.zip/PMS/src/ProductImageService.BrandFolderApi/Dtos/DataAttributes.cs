﻿namespace ProductImageService.BrandFolderApi.Dtos
{
    public class DataAttributes
    {
        public DataAttributeBase[] data { get; set; }
    }

    public class DataAttributeBase
    {
        public string id { get; set; }
        public string type { get; set; }
    }
}
