﻿using System;

namespace ProductImageService.BrandFolderApi.Dtos
{
    public class Asset
    {
        public string id { get; set; }
        public string type { get; set; }
        public AssetAttributes attributes { get; set; }
        public AssetRelationships relationships { get; set; }
    }

    public class AssetRelationships
    {
        public DataAttributes attachments { get; set; }
        public DataAttributes custom_field_values { get; set; }
    }

    public class AssetAttributes
    {
        public string name { get; set; }
        public object description { get; set; }
        public string thumbnail_url { get; set; }
        public bool approved { get; set; }
        public DateTime created_at { get; set; }
        public DateTime updated_at { get; set; }
    }
}
