﻿public class MergeSortA {
public static void MergeSort(int[] array)
{
    if (array.Length <= 1)
        return;

    int mid = array.Length / 2;
    int[] leftArray = new int[mid];
    int[] rightArray = new int[array.Length - mid];

    Array.Copy(array, 0, leftArray, 0, mid);
    Array.Copy(array, mid, rightArray, 0, array.Length - mid);

    MergeSort(leftArray);
    MergeSort(rightArray);
    Merge(leftArray, rightArray, array);
}

public static void Merge(int[] leftArray, int[] rightArray, int[] mergedArray)
{
    int leftIndex = 0;
    int rightIndex = 0;
    int mergedIndex = 0;

    while (leftIndex < leftArray.Length && rightIndex < rightArray.Length)
    {
        if (leftArray[leftIndex] <= rightArray[rightIndex])
        {
            mergedArray[mergedIndex] = leftArray[leftIndex];
            leftIndex++;
        }
        else
        {
            mergedArray[mergedIndex] = rightArray[rightIndex];
            rightIndex++;
        }

        mergedIndex++;
    }

    while (leftIndex < leftArray.Length)
    {
        mergedArray[mergedIndex] = leftArray[leftIndex];
        leftIndex++;
        mergedIndex++;
    }

    while (rightIndex < rightArray.Length)
    {
        mergedArray[mergedIndex] = rightArray[rightIndex];
        rightIndex++;
        mergedIndex++;
    }
}
}
