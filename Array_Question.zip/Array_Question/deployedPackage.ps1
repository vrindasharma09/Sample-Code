$apiUrl = "https://api.boomi.com/api/rest/v1/laerdalmedicalas-KDQI57/PackagedComponent"
            $headers = @{
                 "Content-Type"  = "application/json"
                 "Authorization" = "Basic dnJpbmRhLnNoYXJtYUBsYWVyZGFsLmNvbToyNjdFWkwhRWRhJGJMUGg="
      "Accept"= "application/json"
                 }


            
            $filePath = "C:/BoomiPackages.csv"
            
            # Check if the file already exists
            if (Test-Path -Path $filePath) {
                # Delete the old file
                Remove-Item -Path $filePath -Force
            }
      
            #Import and read the rows one by one
Import-CSV "C:\components.csv" | ForEach-Object { 
 
#Current row object
$CSVRecord = $_
 
#Read column values in the current row 
$Id = $CSVRecord.'ComponentId'
$Notes = $CSVRecord.'Notes'
 
      	$enclosedValue = $Id
            $xmlPayload = @"
      {
        "componentId": $enclosedValue
      }
      "@
      Write-Host $Id
          # Perform the API call for each item
          $response = Invoke-RestMethod -Uri $apiUrl -Headers $headers -Method POST -Body $xmlPayload
            
            # Process the response
            $response
#Display values
Write-Host "$Id - $Notes"
      Add-Content -Path $filePath -Value $response.packageId, $Notes

 
}

           