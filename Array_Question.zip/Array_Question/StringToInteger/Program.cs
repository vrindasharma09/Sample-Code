﻿using System.Text;

public class Solution
{
    public int MyAtoi(string a)
    {
        StringBuilder result = new StringBuilder();
        string s = a.Trim();
        for (int i = 0; i < s.Length; i++)
        {
            if (char.IsLetter(s[i]) || s[i] == '.') return 0;
            if (char.IsDigit(s[i]))
            {
                if (i > 1) return 0;
                if (i == 1) return MyFunc(i - 1, s);
                return MyFunc(i, s);
            }
        }
        return 0;
    }

    private int MyFunc(int index, string s)
    {
        StringBuilder res = new StringBuilder();
        if (s[index] == '-')
        {
            res.Append('-');
            index++;
        }
        else if (s[index] == '+') index++;

        for (int i = index; i < s.Length; i++)
        {
            if (!char.IsDigit(s[i]))
            {
                return CheckNumber(res.ToString());
            }
            res.Append(s[i]);
        }
        return CheckNumber(res.ToString());
    }

    private int CheckNumber(string numberString)
    {
        if (int.TryParse(numberString, out int number))
        {
            if (number > int.MaxValue)
            {
                return int.MaxValue;
            }
            else if (number < int.MinValue)
            {
                return int.MinValue;
            }
            else
            {
                return number;
            }
        }
        return (numberString[0] == '-') ? int.MinValue : int.MaxValue;
    }

    public static void Main(string[] args)
    {
        var ri = new Solution();
        Console.WriteLine(ri.MyAtoi("-1234Abc"));
        Console.ReadKey();
    }
}