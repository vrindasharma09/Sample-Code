﻿using System.Collections;

public class FindDuplicates
{
    public int[] GetDuplicates(int[] arr)
    {
        var result = new Dictionary<int,int>();
        int i = 0;
        while (i <= arr.Length)
        {
            if (result.ContainsKey(arr[i]))
            {
                result[arr[i]]++;
            }
            else
            {
                result[arr[i]] = 1;
            }
            i++; 
        }
        SortedSet<int> set = new SortedSet<int>();
        foreach(var item in result)
        {
            if(item.Value > 1)
            {
                set.Add(item.Key);
            }
        }

        return set.ToArray();
    }

    public static void Main(string[] args)
    {
        FindDuplicates ri = new FindDuplicates();
        var arr = new int[] { 1, 2, 2, 5, 5 };
        Console.WriteLine(string.Join(',', ri.GetDuplicates(arr)));
        Console.ReadKey();
    }
}
