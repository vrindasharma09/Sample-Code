﻿;-8
public class LongestHappyStringA
{
    public string LongestHappyString(int a, int b, int c)
    {
        StringBuilder sb = new StringBuilder();
        int total = a + b + c;
        int A =0, B = 0, C = 0;
        while (total-- > 0)
        {
            if( (a>=b && a>=c && A!=2) || (a>0 && (C==2 || B == 2))){
                sb.Append('a');
                A++;
                a--;
                B = 0;C = 0;
            }
            else if ((b >= a && b >= c && B != 2) || (b > 0 && (C == 2 || A == 2))){
                sb.Append('b');
                B++;
                b--;
                A = 0; C = 0;
            }
            else if ((c >= a && b <= c && C != 2) || (c > 0 && (B == 2 || A == 2)))
            {
                sb.Append('c');
                C++;
                c--;
                B = 0; A = 0;
            }
        }
        return sb.ToString();
    }

    public static void Main(string[] args)
    {
        var ri = new LongestHappyStringA();
        string arr = "youtube refresh";
        //Console.WriteLine("enter number");
        //int number = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(ri.LongestHappyString(1,1,7));
        Console.ReadKey();
    }
};.