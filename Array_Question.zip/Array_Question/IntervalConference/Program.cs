﻿public class IntervalConference
{
    int temp = 0;
    int convertNumber = 0;
    public int GetConferenceRooms(int[][] x)   {
        

        int i = 0;
        int count = 1;
        while(i < x.Length -1)
        {
            if (x[i][0] > x[i + 1][0])
            {
                var temp = x[i];
                x[i] = x[i + 1];
                x[i + 1] = temp;
                
                continue;
            }
            if (x[i][1] > x[i+1][0])
            {
                count++;
            }
           
            i++;
        }
        return count;
    }

    public static void Main(string[] args)
    {
        var ri = new IntervalConference();
        var arr = new int[][] { [0, 30], [5, 10], [15, 20]};
        Console.WriteLine(ri.GetConferenceRooms(arr));
        Console.ReadKey();
    }
}