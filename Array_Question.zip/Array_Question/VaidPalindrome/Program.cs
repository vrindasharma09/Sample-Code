﻿using System.Data;
using System.Text;

public class Solution
{
    public bool IsPalindrome(string s)
    {
        var sResult = new StringBuilder();
        
        for (int i = s.Length - 1; i >= 0; i--)
        {
            if (char.IsDigit(s[i]) || char.IsLetter(s[i]))
            {
                sResult.Append(s[i]);
            }
        }
        var str = sResult.ToString().ToLower();
        var k = str.Length - 1;
        for (int j = 0; j < str.Length; j++, k--)
        {
            if (str[k] != str[j])
                return false;
        }
        return true;
    }

    public static void Main(string[] args)
    {
        Solution s = new Solution();
        Console.WriteLine(s.IsPalindrome("A man, a plan, a canal: Panama"));
        Console.ReadKey();
    }
}