 $apiUrl = "https://api.boomi.com/api/rest/v1/laerdalmedicalas-KDQI57/PackagedComponent"
 $apiUrl2 = "https://api.boomi.com/api/rest/v1/laerdalmedicalas-KDQI57/Component/"
      $headers = @{
           "Content-Type"  = "application/json"
           "Authorization" = "Basic dnJpbmRhLnNoYXJtYUBsYWVyZGFsLmNvbToyNjdFWkwhRWRhJGJMUGg="
            "Accept"= "application/json"
           }
      $headers2 = @{

           "Authorization" = "Basic dnJpbmRhLnNoYXJtYUBsYWVyZGFsLmNvbToyNjdFWkwhRWRhJGJMUGg="           }
      $myVariable = @("c86bfad2-d0e8-4359-85f4-d13018c5cfc5")
        $filePath = "C:/Array_Question/BoomiPackages.txt"
            
            # Check if the file already exists
            if (Test-Path -Path $filePath) {
                # Delete the old file
                Remove-Item -Path $filePath -Force
            }

  

      
      foreach ($item in $myVariable) {
	$enclosedValue = '"'+$item+'"'
        $i =0
      $xmlPayload = @"

{
  "componentId": $enclosedValue
}
"@

    # Perform the API call for each item
    # $response = Invoke-RestMethod -Uri $apiUrl -Headers $headers -Method POST -Body $xmlPayload
      
      # Process the response
      # $response
    $apiUrl3 = $apiUrl2 + $item

    $response2 = Invoke-RestMethod -Uri $apiUrl3 -Headers $headers2 -Method GET
Write-Host $response2
      # Process the response
      if ($response2.StatusCode -eq 200) {
    # Access the raw content of the response
    $xmlContent = $response2.Content

    # Save the XML content to a file
    $filePath = "C:\file.xml"
    [System.IO.File]::WriteAllText($filePath, $xmlContent)

    Write-Host "XML content saved successfully to $filePath"
} else {
    Write-Host "Failed to retrieve the XML content. Status code: $($response.StatusCode)"
} 
}
