﻿public class Solution
{
    public int MaximalSquare(char[,] matrix)
    {
        int maxSquare = 0;
        for(int i = 0; i < matrix.GetLength(0); i++)
        {
            for(int j=0;i<matrix.GetLength(1); j++)
            {
                if (matrix[i,j] == '1')
                {
                    
        
                }
            }
        }
        return maxSquare;
    }
    public static void Main(string[] args)
    {
        var res = new Solution();
        char[,] inputMatrix = { { '1', '0', '1', '0', '0' }, { '1', '0', '1', '1', '1' }, { '1', '1', '1', '1', '1' }, { '1', '0', '0', '1', '0' } };
        Console.WriteLine(res.MaximalSquare(inputMatrix));
        }
}
