﻿public class Armstrong
{
    int temp = 0;
    int convertNumber = 0; 
    public bool IsArmstrongNumber(int x)
    {
        int convertNumber = 0;
        int temp = x;
        while (temp > 0)
        {
            convertNumber = convertNumber + Convert.ToInt16(Math.Pow(temp % 10, 3));
            temp /= 10;
        }
        return x == convertNumber;
    }

    public static void Main(string[] args)
    {
        Armstrong ri = new Armstrong();
        Console.WriteLine("enter number");
        int number = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(ri.IsArmstrongNumber(number) ? "yes" : "No");
        Console.ReadKey();
    }
}