﻿public class Solution
{

    public int[] TwoSum(int[] nums, int target)
    {
        var arr = new int[2];
        Dictionary<int, int> set = new Dictionary<int, int>();
        for (int i = 0; i < nums.Length; i++)
        {
            int rem = target - nums[i];
            if (set.ContainsKey(rem))
                arr = new int[] { set[rem], i };
            else if (!set.ContainsKey(nums[i]))
                set.Add(nums[i], i);

        }
        return arr;
    }


    public static void Main(string[] args)
    {
        var solution = new Solution();
        Console.WriteLine(string.Join(",", solution.TwoSum(new int[] { 3, 3 }, 6)));
        Console.ReadKey();
    }
}