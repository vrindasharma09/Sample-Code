﻿using System;
using System.Collections.Generic;

// you can also use other imports, for example:
// using System.Collections.Generic;

// you can write to stdout for debugging purposes, e.g.
// Console.WriteLine("this is a debug message");
namespace xyz
{
    class Node
    {
        public Node[] subtrees;
    };
    class Solution
    {
        static bool HasBalancedNode(Node root)
        {
            if (root == null)
                return false;

            return !IsBalanced(root);
        }

        static bool IsBalanced(Node node)
        {
            if (node.subtrees.Length == 0)
                return true;

            int subtreeSize = solution(node.subtrees[0]);

            foreach (var child in node.subtrees)
            {
                if (solution(child) != subtreeSize || !IsBalanced(child))
                    return false;
            }

            return true;
        }
        public static int solution(Node tree)
        {
            // Implement your solution here
            int size = 1;

            foreach (var child in tree.subtrees)
            {
                size += solution(child);
            }

            return size;
        }
        public static void Main(string[] args)
        {
        }
    }
}
