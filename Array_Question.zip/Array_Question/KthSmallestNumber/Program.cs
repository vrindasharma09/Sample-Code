﻿public class KthSmallestNumber
{
    int temp = 0;
    int convertNumber = 0;
    public int GetKthSmallestNumber(int[] x, int k )
    {
        Array.Sort(x);
        return k> 0 ?x[k-1] : x[0];
    }

    public static void Main(string[] args)
    {
        KthSmallestNumber ri = new KthSmallestNumber();
        int[] arr = new int[] { 6, 8, 3, 2, 8, 9 };
        //Console.WriteLine("enter number");
        //int number = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(ri.GetKthSmallestNumber(arr, 3));
        Console.ReadKey();
    }
}