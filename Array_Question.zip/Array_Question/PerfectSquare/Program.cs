﻿public class Solution
{
    public bool IsPerfectSquare(int num)
    {
        int n = 0;
        bool res = false;
        for (int i = 1; i <= (num + 1) / 2; i++)
        {
            if (i * i == num)
            {
                res = true;
            }
            else if (i * i >= num)
            {
                break;
            }
        }
            return res;
    }

    public static void Main(string[] args)
    {
        var sol = new Solution();
        Console.WriteLine(sol.IsPerfectSquare(16));
        Console.ReadKey();
    }
}
