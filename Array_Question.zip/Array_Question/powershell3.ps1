      $apiUrl = $(createPackageEndpoint)
      $headers = @{
          "Content-Type" = "application/json"
          "Authorization" = "Basic ZWFpc3VwcG9ydEBoZWxwLmxhZXJkYWwuY29tOjI2N0VaTCFFZGEkYkxQSw=="
          "Accept" = "application/json"
      }

      $filePath = "C:\Array_Question\BoomiPackages.csv"
      
      # Check if the file already exists
      if (Test-Path -Path $filePath) {
          # Delete the old file
          Remove-Item -Path $filePath -Force
      }
      
      # Import and read the rows one by one
      Import-CSV "c:\components.csv" | ForEach-Object {
          # Current row object
          $CSVRecord = $_
      
          # Read column values in the current row
          $Id = '"' +$CSVRecord.'ComponentId' + '"'
          $Notes = '"' +$CSVRecord.'Notes'+ '"'
          $xmlPayload = @"
          {
              "componentId": $Id,
              "notes" : $Notes
          }
          "@
          Write-Host $Id
      
          # Perform the API call for each item
          $response = Invoke-RestMethod -Uri $apiUrl -Headers $headers -Method POST -Body $xmlPayload
      
          # Process the response
          $response
          
          $XML = ConvertTo-Xml -As Stream -InputObject $response -Depth 3
	  Out-File -FilePath "C:\Array_Question\"+$response.packageId+".xml" -InputObject $XML 

          # Display values
          Write-Host "$Id - $Notes"
          $data= [PSCustomObject]@{
          PackageId = $response.packageId
          Notes = $CSVRecord.'Notes'
      }
      
      # Append the data to the CSV file
          $data | Export-Csv -Path $filePath -Append -NoTypeInformation
          #Add-Content -Path $filePath -Value $response.packageId, $Notes
      }
