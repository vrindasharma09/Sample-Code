﻿//using System.Collections;

//public class GetTemperature
//{
//    public int[] GetTemperatureDiff(int[] arr)
//    {
//        int i = 0;
//        var result = new List<int>();
//        int j = 0, count = 0;

//        while (i < arr.Length)
//        {
//            j = i + 1;
//            count = 0;
//            while (j < arr.Length)
//            {
//                if (arr[i] > arr[j])
//                {
//                    count++;
//                }
//                else if (arr[i] < arr[j])
//                {
//                    count++;
//                    result.Add(count);
//                    break;
//                }
//                j++;
//            }
//            if (result.Count < i + 1)
//            {
//                result.Add(0);
//            }
//            i++;
//        }
//        return result.ToArray();
//    }

//    public static void Main(string[] args)
//    {
//        GetTemperature ri = new GetTemperature();
//        var arr = new int[] { 30, 60, 90 };
//        Console.WriteLine(string.Join(',', ri.GetTemperatureDiff(arr)));
//        Console.ReadKey();
//    }
//}using System;
using System.Collections.Generic;

public class GetTemperature
{
    public int[] GetTemperatureDiff(int[] arr)
    {
        int n = arr.Length;
        int[] result = new int[n];
        Stack<int> stack = new Stack<int>();

        for (int i = 0; i < n; i++)
        {
            while (stack.Count > 0 && arr[i] > arr[stack.Peek()])
            {
                int prevIndex = stack.Pop();
                result[prevIndex] = i - prevIndex;
            }
            stack.Push(i);
        }

        return result;
    }
    public static void Main(string[] args)
    {
        GetTemperature ri = new GetTemperature();
        var arr = new int[] { 30, 60, 90 };
        Console.WriteLine(string.Join(',', ri.GetTemperatureDiff(arr)));
        Console.ReadKey();
    }
}