﻿public class Solution
{
    public IList<IList<int>> Generate(int numRows)
    {
        var triangle = new List<IList<int>>();

        int lastRow = 0;
        for (int i = 0; i < numRows; i++)
        {
            var row = new List<int>();
            row.Add(1);
            if (triangle.Count > 0)
            {
                lastRow = i - 1;
                for (int j = 1; j < i; j++)
                {
                    row.Add(triangle[lastRow][j - 1] + triangle[lastRow][j]);
                }
                row.Add(1);
            }
            triangle.Add(row);
        }
        return triangle;
    }
}