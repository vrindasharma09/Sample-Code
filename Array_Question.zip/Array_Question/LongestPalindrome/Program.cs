﻿using System;

class SymmetricGrid
{
    static int MinimumMoves(string[] grid)
    {
        int n = grid.Length; // Number of rows
        int m = grid[0].Length; // Number of columns
        int moves = 0;

        for (int i = 0; i < n / 2; i++)
        {
            for (int j = 0; j < m / 2; j++)
            {
                char topLeft = grid[i][j];
                char topRight = grid[i][m - 1 - j];
                char bottomLeft = grid[n - 1 - i][j];
                char bottomRight = grid[n - 1 - i][m - 1 - j];

                if (topLeft != bottomRight)
                    moves++;
                if (topRight != bottomLeft)
                    moves++;
            }
        }

        if (n % 2 != 0)
        {
            int rowMid = n / 2;
            for (int j = 0; j < m / 2; j++)
            {
                char left = grid[rowMid][j];
                char right = grid[rowMid][m - 1 - j];

                if (left != right)
                    moves++;
            }
        }

        if (m % 2 != 0)
        {
            int colMid = m / 2;
            for (int i = 0; i < n / 2; i++)
            {
                char top = grid[i][colMid];
                char bottom = grid[n - 1 - i][colMid];

                if (top != bottom)
                    moves++;
            }
        }

        return moves;
    }

    static void Main()
    {
        string[] grid1 = new string[] { "BBWWB", "WWWBW", "BWWWW" };
        int minimumMoves1 = MinimumMoves(grid1);
        Console.WriteLine("Minimum number of moves required for grid1: " + minimumMoves1);

        string[] grid2 = new string[] { "BWB", "WBB", "WBW" };
        int minimumMoves2 = MinimumMoves(grid2);
        Console.WriteLine("Minimum number of moves required for grid2: " + minimumMoves2);

        string[] grid3 = new string[] { "BBBB", "WWWW", "BBWB", "WWWW" };
        int minimumMoves3 = MinimumMoves(grid3);
        Console.WriteLine("Minimum number of moves required for grid3: " + minimumMoves3);
    }
}