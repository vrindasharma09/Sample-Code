﻿public class Solution
{
    public void GetFrequencyOfwords(string strs)
    {
        var result = strs.Split(" ");
        var set = new Dictionary<string, int>();
        foreach(var word in result)
        {
            if(set.ContainsKey(word))
            {
                set[word]++;
            }
            else
            {
                set[word] = 1;
            }
        }

        foreach (var item in set)
        {
            Console.WriteLine(item.Key + "-", item.Value);
        }
    }
    public static void Main(string[] args)
    {
        var ri = new Solution();
        ri.GetFrequencyOfwords("str str one two three str");
        Console.ReadKey();
    }
}