﻿
public class ListNode
{
    public int val;
    public ListNode next;
    public ListNode(int val = 0, ListNode next = null)
    {
        this.val = val;
        this.next = next;
    }
}

public class Solution
{
    private readonly ListNode Empty = new ListNode(0);

    public ListNode AddTwoNumbers(ListNode l1, ListNode l2, int leftOver = 0)
    {
        if (l1 is null && l2 is null && leftOver == 0)
            return null;

        l1 ??= Empty;
        l2 ??= Empty;

        int sum = l1.val + l2.val + leftOver;

        return new ListNode(sum % 10, AddTwoNumbers(l1.next, l2.next, sum / 10));
    }
}