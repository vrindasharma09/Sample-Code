﻿public class Abc
{
   
    public virtual void Display()
    {
        Console.WriteLine("Base");
    }
}

public class Xyz :Abc
{
    public  override void Display()
    {
        //Console.WriteLine("Method1 Start");
        //await (Task.Delay(1000));
        //Console.WriteLine("Method1 End");
        Console.WriteLine("Inherit");
    }
    public virtual void Method2()
    {
        Console.WriteLine("Abc");
    }

}

public class A
{
    public static void Main(string[] args)
    {
        Abc a = new Abc();
        Abc b = new Xyz();
        Xyz x = new Xyz();
        //Xyz y = new Abc();
        a.Display();
        b.Display();
        x.Display();
        Console.ReadKey();
       // y.Display();

    }
}