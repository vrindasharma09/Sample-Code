﻿public class BinaryToDecimal
{
    int temp = 0;
    int convertNumber = 0;
    public int Binary_To_Decimal(int x)
    {
        int convertNumber = 0;
        int i = 0;
        while(x > 0)
        {
            if (x % 10 != 0)
                convertNumber = convertNumber + Convert.ToInt16(Math.Pow(2, i));
            i++;
            x = x/ 10;
        }
        return convertNumber;
    }

    public static void Main(string[] args)
    {
        BinaryToDecimal ri = new BinaryToDecimal();
        Console.WriteLine("enter number");
        int number = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(ri.Binary_To_Decimal(number));
        Console.ReadKey();
    }
}