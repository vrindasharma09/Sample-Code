﻿using Azure.Storage.Blobs;
using System.IO;

public void UploadFileToBlob(string connectionString, string containerName, string blobName, string filePath)
{
    BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);
    BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(containerName);

    BlobClient blobClient = containerClient.GetBlobClient(blobName);

    using FileStream fileStream = File.OpenRead(filePath);
    blobClient.Upload(fileStream, true);
}