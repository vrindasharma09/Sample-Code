﻿
public class ReverseNumber2
{    public static void Main(string[] args)
    {
        Console.WriteLine("enter number");
        int n = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Number is Prime : " + ReverseNumber(n));
        Console.ReadKey();
    }

    public static int ReverseNumber(int n)
    {
        int convertNumber = 0;
        do
        {
            convertNumber = convertNumber * 10 + n % 10;
            n /= 10;

        } while(n > 0);        
        return convertNumber;
    }
}