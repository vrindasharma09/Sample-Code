﻿// See public class _007_ReverseInteger
using System.Text;

public class IndexReverse
{
    public string Reverse(string input, char k)
    {
        var index = input.IndexOf(k);
        int i = index;
        StringBuilder result = new StringBuilder();
        while(index >= 0)
        {
            result.Append(input[index--]);

        }
        result.Append(input.Substring(i+1));
        return result.ToString();
    }

    public static void Main(string[] args)
    {
        var ri = new IndexReverse();
        var input = "xyxzxe";
        char k = 'z';
        Console.WriteLine(ri.Reverse(input , k));
        Console.ReadKey();
    }
}
