﻿// See public class _007_ReverseInteger
public class ReverseInteger
{
    public int Reverse(int x)
    {
        int convertNumber = 0;
        int temp = x;
        while (temp > 0)
        {
            convertNumber = convertNumber * 10 + temp % 10;
            temp /= 10;
        }
        return convertNumber;
    }

    public static void Main(string[] args)
    {
        ReverseInteger ri = new ReverseInteger();
        Console.WriteLine("enter number");
        int number = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(ri.Reverse(number));
        Console.ReadKey();
    }
}
