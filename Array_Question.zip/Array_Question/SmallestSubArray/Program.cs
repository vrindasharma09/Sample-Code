﻿// See public class _007_ReverseInteger
using System.Security.AccessControl;

public class SmallestSubArray
{
    public (int,int) GetSmallestSubArray(int[] arr, int x)
    {
        int i = 0;
        int sum = 0;
        int count = 0;
        int right = 0;
        int left = 0;
        while (i <= arr.Length)
        {
            if (sum == x)
            {
                left = i-1;
                break;
            }
            else if (sum + arr[i] > x)
            {
                sum = sum - arr[count++];
                right = count;
            }
            sum += arr[i];
            i++;
        }
        return (right+1, left+1);
    }

    public static void Main(string[] args)
    {
        SmallestSubArray ri = new SmallestSubArray();
        var arr = new int[] { 1, 2, 3, 7, 5 };
        (int a,int b)= ri.GetSmallestSubArray(arr, 12);
        Console.WriteLine(a + ","+b);
        Console.ReadKey();
    }
}
