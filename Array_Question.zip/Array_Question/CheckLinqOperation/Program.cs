﻿using System;
using System.Linq;

public class CheckLinqOperations
{
    public static void Main(string[] args)
    {
        int[] arr = { 1, 2, 3, 4, 6, 5 };
        int result = arr.FirstOrDefault(x => x < 10);
        Console.ReadKey();
    }
}
