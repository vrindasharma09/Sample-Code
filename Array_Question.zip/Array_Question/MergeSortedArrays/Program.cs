﻿//// C# program to merge K sorted arrays of size n each. 
//using System;
//public class GFG
//{

//    // This function takes an array of arrays as an argument 
//    // and 
//    // All arrays are assumed to be sorted. It merges them 
//    // together and prints the readonly sorted output. 
//    public static void mergeKArrays(int[,] arr, int a,
//                                    int[] output)
//    {
//        int c = 0;
//        var result = new List<int>();
//        // traverse the matrix 
//        for (int i = 0; i < a; i++)
//        {
//            for (int j = 0; j < 4; j++)
//                result.Add(arr[i,j]);
//        }

//        // sort the array 
//        output = result.ToArray();
//        Array.Sort(output);
//        printArray(output, output.Length);

//    }

//    // A utility function to print array elements 
//    public static void printArray(int[] arr, int size)
//    {
//        for (int i = 0; i < size; i++)
//            Console.Write(arr[i] + " ");
//    }

//    // Driver's code 
//    public static void Main(String[] args)
//    {
//        int[,] arr = { { 2, 6, 12, 34 },
//                        { 1, 9, 20, 1000 },
//                        { 23, 34, 90, 2000 } };
//        int K = 4;
//        int N = 3;
//        int[] output = new int[N * K];

//        // Function call 
//        mergeKArrays(arr, N, output);
//        Console.WriteLine("Merged array is ");
//        printArray(output, N * K);
//    }
//}


using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
    public static void Main(string[] args)
    {
       int[,] arr = { { 2, 6, 12, 34 },
                      { 1, 9, 20, 1000 },
                      { 23, 34, 90, 2000 } };

        int[] mergedArray = MergeKSortedArrays(arr);
        Console.WriteLine(string.Join(", ", mergedArray));
        Console.ReadKey();
    }

    public static int[] MergeKSortedArrays(int[,] arr)
    {
        IEnumerable<int> merged = arr.Cast<int>();
        int[] sortedArray = merged.OrderBy(num => num).ToArray();
        return sortedArray;
    }
}

// This code is contributed by Rajput-Ji
