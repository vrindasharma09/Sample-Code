﻿public class Battleships
{
    public int GetBattleships(char[,] board)
    {
        int i = 0, count = 0, k = 0;
        int leftLength = board.GetLength(1);
        int rightLength = board.GetLength(0);
        for (i = 0; i < rightLength; i++)
        {
            k = 0;
            while (k < leftLength)
            {
                if (board[i, k] == 'X')
                {
                    if (i != 0 && k != 0)
                    {
                        if (board[i - 1, k] == '.' && board[i, k--] == '.')
                        {
                            count++;
                        }
                    }
                    else if (k == 0 && i==0)
                    {
                        if (board[i, k+1] == '.')
                        {
                            count++;
                        }
                    }
                    else
                    {
                        if (board[i, k-1] == '.')
                        {
                            count++;
                        }
                    }
                }
                k++;
            }
        }
        return count;
    }
        public static void Main(string[] args)
        {
            var ri = new Battleships();
            char[,] board = { { 'X', '.', 'X' }, { '.', '.', 'X' }, { '.', '.', 'X' } };
            Console.WriteLine(string.Join(',', ri.GetBattleships(board)));
            Console.ReadKey();
        }
    }
