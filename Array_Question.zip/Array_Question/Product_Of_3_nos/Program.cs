﻿public class Solution
{
    public int MaximumProduct(int[] nums)
    {

        Array.Sort(nums);

        return Math.Max(nums[nums.Length - 1] * nums[nums.Length - 2] *
                                                    nums[nums.Length - 3],
                            nums[nums.Length - 1] * nums[0] * nums[1]);
    }
    public static void Main(string[] args)
    {
        var solution = new Solution();
        Console.WriteLine(string.Join(",", solution.MaximumProduct(new int[] { -8,24, 3, 3 })));
        Console.ReadKey();
    }
}