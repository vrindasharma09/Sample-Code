﻿using System;
public class Palindrome
{
    int temp = 0;
    int convertNumber = 0;
    
    // Eg : 12321 , 12345
    //public bool IsPalindrome(int x)
    //{
    //    temp = x;
    //    while (temp > 0)
    //    {
    //        convertNumber = convertNumber * 10 + temp % 10;
    //        temp /= 10;
    //    }
    //    return x == convertNumber;
    //}

    //public static void Main(String[] args)
    //{
    //    Palindrome pd = new Palindrome();

    //    Console.WriteLine("Enter number");
    //    int number = Convert.ToInt32(Console.ReadLine());
    //    if (pd.IsPalindrome(number))
    //    {
    //        Console.WriteLine("Palindrome");
    //    }
    //    else
    //    {
    //        Console.WriteLine("Not Palindrome");
    //    }
    //}
   
    public static  void Main()
    {
        Console.WriteLine("Main");
        Method1();
        Console.WriteLine("Main End");

    }
}