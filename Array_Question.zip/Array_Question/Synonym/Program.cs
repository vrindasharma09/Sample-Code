﻿using System;
using System.Collections.Generic;

public class SynonymChecker
{
    private Dictionary<string, HashSet<string>> synonyms;

    public SynonymChecker(List<(string, string)> synonymPairs)
    {
        synonyms = new Dictionary<string, HashSet<string>>();

        foreach (var pair in synonymPairs)
        {
            if (!synonyms.ContainsKey(pair.Item1))
            {
                synonyms[pair.Item1] = new HashSet<string>();
            }
            if (!synonyms.ContainsKey(pair.Item2))
            {
                synonyms[pair.Item2] = new HashSet<string>();
            }

            synonyms[pair.Item1].Add(pair.Item2);
            synonyms[pair.Item2].Add(pair.Item1);
        }
    }

    public List<bool> CheckSynonyms(List<(string, string)> sentencePairs)
    {
        List<bool> result = new List<bool>();

        foreach (var pair in sentencePairs)
        {
            result.Add(AreSynonyms(pair.Item1, pair.Item2));
        }

        return result;
    }

    private bool AreSynonyms(string sentence1, string sentence2)
    {
        string[] words1 = sentence1.Split(' ');
        string[] words2 = sentence2.Split(' ');

        if (words1.Length != words2.Length)
        {
            return false;
        }

        for (int i = 0; i < words1.Length; i++)
        {
            if (words1[i] != words2[i] && !synonyms.ContainsKey(words1[i]) && !synonyms.ContainsKey(words2[i]))
            {
                return false;
            }

            if (words1[i] != words2[i] && (!synonyms.ContainsKey(words1[i]) || !synonyms[words1[i]].Contains(words2[i])))
            {
                return false;
            }
        }

        return true;
    }
}

public class Program
{
    public static void Main()
    {
        List<(string, string)> synonymPairs = new List<(string, string)>
        {
            ("great", "good"),
            ("great", "excellent"),
            ("good", "fine")
        };

        List<(string, string)> sentencePairs = new List<(string, string)>
        {
            ("Google is a good company", "Google is a great company"),
            ("My performance is bad", "My performance is poor")
        };

        SynonymChecker checker = new SynonymChecker(synonymPairs);
        List<bool> result = checker.CheckSynonyms(sentencePairs);

        foreach (bool isSynonym in result)
        {
            Console.WriteLine(isSynonym);
        }
    }
}