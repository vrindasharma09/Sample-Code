﻿public class ArrayQuestion
{
    public static void Main(string[] args)
    {
        Console.WriteLine("enter number");
        int n = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Number is Prime : "+ CheckPrime(n));
        Console.ReadKey();
    }

    public static bool CheckPrime(int n)
    {
        if(n == 0)
        {
            return false;
        }
        for(int i = 2;i<=n/2;i++)
        {
            if(n%i == 0)
            {
                return false;                
            }
        }
        return true;
    }
}
