﻿public class Solution
{
    public string LongestPalindrome(string input)
    {
        int start =0, end = 0;
        int i = 0;
        while(i < input.Length)
        {
            var even = GetLengthPalindrome(input, i, i + 1);
            var odd = GetLengthPalindrome(input,i, i);
            int maxLength = Math.Max(even, odd);
            if(maxLength > end - start)
            {
                end = i + (maxLength / 2);
                start = i - ((maxLength - 1) / 2);

            }
            i++;
        }
        return input.Substring(start, end + 1 - start);
       
    }

    public int GetLengthPalindrome(string input, int start, int end)
    {
        while (start >= 0 && end < input.Length && input[start] == input[end]) { start--; end++; }
        return end - start - 1;
    }
    public static void Main(string[] args)
    {
        var ri = new Solution();
        Console.WriteLine(ri.LongestPalindrome("babad"));
        Console.ReadKey();
    }
}