﻿public class Solution
{
    public int[] MoveZeroes(int[] nums)
    {
        int i = 0;
        int count =0;
        while (i < nums.Length)
        {
            if (nums[i] != 0)
            {
                nums[count++] = nums[i];
            }
            i++;
        }
        i = count;
        while (i < nums.Length)
            nums[i++] = 0;
        return nums;
    }
    public static void Main(string[] args)
    {
        Solution ri = new Solution();
        int[] arr = new int[] { 0, 1, 3, 0, 4, 12 };
        //Console.WriteLine("enter number");
        //int number = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(string.Join(',' , ri.MoveZeroes(arr)));
        Console.ReadKey();
    }
}