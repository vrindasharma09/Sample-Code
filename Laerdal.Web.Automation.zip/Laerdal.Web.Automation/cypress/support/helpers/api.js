const headers = {};
headers['Content-Type'] = 'application/json';
headers[Cypress.env().apiKeyName] = Cypress.env().apiKeyValue;

export const apiHeaders = headers;
