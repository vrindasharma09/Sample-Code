import marketsSettings from '../../fixtures/markets';
import marketsAccounts from '../../fixtures/accounts';

const includeMarkets = Cypress.env('markets');

export const defaultMarketLanguage = 'en';
export const accounts = marketsAccounts;
export const markets = Object.keys(marketsSettings)
  .filter(id => {
    // Executes tests only on markets specified in the markets environment variable.
    // This is intended for local use to speed up runs while developing.
    if (includeMarkets.length > 0 && !includeMarkets.find(m => m === id)) {
      return false;
    }

    return true;
  })
  .map(id => ({ id: id, ...marketsSettings[id] }));
