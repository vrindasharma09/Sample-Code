// https://on.cypress.io/configuration
// ***********************************************************

// Import common styles
import '@css/screen.css';

// Import commands
import './commands/component';