import {CosmosClient} from '@azure/cosmos';

const
  cosmosEndpoint = Cypress.env('cosmosEndpoint'),
  cosmosKey = Cypress.env('cosmosKey'),
  cosmosDatabase = Cypress.env('cosmosDatabase'),
  cosmosContainer = Cypress.env('cosmosContainer');

/**
 * Get order details.
 * @param orderNumber The order number.
 * @param customerNumber The customer number.
 */
Cypress.Commands.add('getOrder', (orderNumber, customerNumber) => {
  const cosmosClient = new CosmosClient({endpoint: cosmosEndpoint, key: cosmosKey});
  const container = cosmosClient.database(cosmosDatabase).container(cosmosContainer);

  return new Cypress.Promise(async (resolve, reject) => {
    const response = await container.item(orderNumber, customerNumber).read();

    if (response.statusCode !== 200) {
      reject(`Could not fetch order ${orderNumber}`);
    } else {
      resolve(response.resource);
    }
  });
});
