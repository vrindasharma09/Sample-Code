import { mount } from 'cypress/vue';
import Translate from 'vueplugins/translate';
import Toast from 'vue-toastification';
import { markets } from '../helpers/markets';
import { configureStore } from '@store';
import ProductImage from 'vuetemplates/components/ProductImage.vue';

const market = markets.find(m => m.id === 'no');

// Mount a component with Vuex store and other options
Cypress.Commands.add('mount', (component, options = {}) => {
  // Setup options object
  options.global = options.global || {};
  options.global.stubs = options.global.stubs || {};
  options.global.components = options.global.components || {};
  options.global.plugins = options.global.plugins || [];

  // Use store passed in from options, or initialize a new one
  const { store = configureStore(market.language), ...mountOptions } = options;

  options.global.plugins.push(
    [Translate]
  );

  options.global.plugins.push(
    [Toast, {
      position: 'top-center',
      transition: 'Vue-Toastification__bounce',
      timeout: 3000,
      pauseOnHover: false
    }]
  );

  // Add Vuex plugin
  options.global.plugins.push({
    install(app)  {
      app.config.globalProperties.$globalToast = {
        appError: () => {}
      };
      app.config.globalProperties.$global = { 
        showMiniCart: false,
        cartLoading: false,
        userLoading: true
      };
      app.config.globalProperties.$authToken = {};
      app.use(store);
    }
  });

  // Register global components
  options.global.components['ProductImage'] = ProductImage;

  return mount(component, mountOptions).as('vue');
});
