/**
 * Delete the cart for the current session.
 * @param language The market language.
 */
Cypress.Commands.add('deleteCart', (language) => {
  cy.request({
    method: 'DELETE',
    url: `${language}/api/shoppingCart`
  });

  cy.request(`${language}/api/shoppingCart`)
    .its('body.result.response.lineItems')
    .should('have.length', 0);
});