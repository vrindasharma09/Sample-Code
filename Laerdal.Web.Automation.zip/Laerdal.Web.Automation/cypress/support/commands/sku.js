import { defaultVariant, defaultPrice, defaultStock } from '../../fixtures/sku.json';
import { apiHeaders } from '../helpers/api';
import { defaultMarketLanguage } from '../helpers/markets';

/**
 * Ensures that a SKU exists.
 * @param skuVariant The baseline variant object.
 */
Cypress.Commands.add('initializeSku', (skuVariant) => {
  const mergedVariant = { ...defaultVariant, ...skuVariant };

  // Initialize on International.
  cy.createSku(mergedVariant, defaultMarketLanguage);
  cy.updateSku(
    { ...mergedVariant, availabilityStatus: 'Active' },
    defaultMarketLanguage
  );
});

/**
 * Ensures that a SKU exists.
 * @param skuVariant The baseline variant object.
 * @param market The market on which to setup the SKU.
 */
Cypress.Commands.add('initializeMarketSku', (skuVariant, market) => {
  const mergedVariant = { ...defaultVariant, ...skuVariant };

  // Update sku Markets
  cy.updateSkuMarkets({
    sku: mergedVariant.sku,
    markets: [{
      marketId: market.code,
      defaultWarehouse: market.defaultWarehouse,
      taxCode: 'B',
      availabilityStatus: 'Active'
    }]
  });
  cy.setSkuPrice({
    ...defaultPrice,
    sku: mergedVariant.sku,
    unitPrice: 100,
    marketId: market.code,
    currencyCode: market.currency
  });
  cy.setSkuStock({
    ...defaultStock,
    sku: mergedVariant.sku,
    warehouseCode: market.defaultWarehouse
  });
});

/**
 * Ensures that a SKU exists.
 * @param skuVariant The baseline variant object.
 * @param market The market on which to setup the SKU.
 */
Cypress.Commands.add('verifySkuPage', (skuVariant, market) => {
  // Ensure that the item pages are browsable with price and add to cart.
  cy.suppressCookieBanner();
  cy.visit(`${market.url}/item/${skuVariant.sku}`);
  cy.get('[data-testid=product-details]').find('[data-testid=tax-included-price]').should('exist');
  cy.get('[data-testid=product-details]').find('[data-testid=add-to-cart]').should('exist');
});

// #region Availability

/**
 * Creates a SKU. Note that this method will not fail if the item already exists.
 * @param skuVariant The SKU variant object.
 */
Cypress.Commands.add('createSku', (skuVariant, language) => {
  cy.request({
    method: 'POST',
    url: 'api/v1.0/variants',
    headers: { ...apiHeaders, 'Accept-Language': language },
    body: skuVariant
  });
});

/**
 * Returns a SKU by a given code.
 * Can be chained.
 * @param skuCode The SKU code.
 */
Cypress.Commands.add('getSku', (skuCode, language) => {
  return cy.request({
    method: 'GET',
    url: `api/v1.0/variants/${skuCode}`,
    headers: { ...apiHeaders, 'Accept-Language': language }
  }).its('body')
    .should(skuVariant => {
      expect(skuVariant.sku).to.eq(skuCode);
    });
});

/**
 * Updates a SKU by a given variant object.
 * Can be chained.
 * @param skuVariant The SKU variant object.
 * @param language The language for which to update the variant.
 */
Cypress.Commands.add('updateSku', (skuVariant, language) => {
  return cy.request({
    method: 'PUT',
    url: `api/v1.0/variants/${skuVariant.sku}`,
    headers: { ...apiHeaders, 'Accept-Language': language },
    body: skuVariant
  }).its('body')
    .should(skuVariant => {
      expect(skuVariant.sku).to.eq(skuVariant.sku);
    });
});

// #endregion

// #region Markets

/**
 * Returns the SKU markets by a given code.
 * Can be chained.
 * @param skuCode The SKU code.
 */
Cypress.Commands.add('getSkuMarkets', (skuCode) => {
  return cy.request({
    method: 'GET',
    url: `api/v1.0/variant-markets/${skuCode}`,
    headers: apiHeaders
  }).its('body')
    .should(skuMarkets => {
      expect(skuMarkets.sku).to.eq(skuCode);
    });
});

/**
 * Updates the SKU markets availability.
 * Can be chained.
 * @param skuMarkets The SKU markets object.
 */
Cypress.Commands.add('updateSkuMarkets', (skuMarkets) => {
  return cy.request({
    method: 'PUT',
    url: `api/v1.0/variant-markets/${skuMarkets.sku}`,
    headers: apiHeaders,
    body: skuMarkets
  }).its('body');
});

// #endregion

// #region Price

/**
 * Set the SKU price.
 * Can be chained.
 * @param skuPrice The SKU price object.
 */
Cypress.Commands.add('setSkuPrice', (skuPrice) => {
  return cy.request({
    method: 'POST',
    url: 'api/v1.0/prices',
    headers: apiHeaders,
    body: skuPrice
  }).its('body');
});

/**
 * Activates the SKU price.
 * @param skuCode The SKU code.
 * @param language The language for which to set the price.
 * @param active A boolean value to set for the price.
 */
Cypress.Commands.add('activateSkuPrice', (skuCode, language, active) => {
  cy.request({
    method: 'PUT',
    url: `api/v1.0/variants/${skuCode}/price`,
    headers: { ...apiHeaders, 'Accept-Language': language },
    body: {
      Sku: skuCode,
      Active: active
    }
  });
});

// #endregion

// #region Stock

/**
 * Sets the SKU stock.
 * Can be chained.
 * @param skuStock The SKU stock object.
 */
Cypress.Commands.add('setSkuStock', (skuStock) => {
  return cy.request({
    method: 'POST',
    url: 'api/v1.0/stock',
    headers: apiHeaders,
    body: skuStock
  }).its('body');
});

// #endregion
