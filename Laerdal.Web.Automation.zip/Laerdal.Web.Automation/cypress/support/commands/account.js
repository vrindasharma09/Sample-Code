const gigyaApiKey = Cypress.env('gigyaApiKey');

/**
 * Creates a user browsing session and ensures all cookies are present without
 * going through the UI.
 * @param language The market language for the API.
 * @param username The account username.
 * @param password The account password.
 */
Cypress.Commands.add('createUserSession', (language, username, password) => {
  cy.request({
    method: 'POST',
    url: 'https://accounts.eu1.gigya.com/accounts.login',
    body: {
      apiKey: gigyaApiKey,
      loginID: username,
      password: password
    },
    form: true
  }).its('body')
    .then(body => JSON.parse(body))
    .should(body => {
      expect(body.sessionInfo).to.exist;
    })
    .then(body => {
      cy.wrap(body).as('gigyaLogin');
      cy.setCookie(body.sessionInfo.cookieName, body.sessionInfo.cookieValue);
    });

  cy.get('@gigyaLogin').then(gigyaLogin => {
    cy.request({
      method: 'POST',
      url: 'https://accounts.eu1.gigya.com/accounts.notifyLogin',
      body: {
        apiKey: gigyaApiKey,
        siteUID: gigyaLogin.UID,
        UIDSig: gigyaLogin.UIDSignature,
        UIDTimestamp: gigyaLogin.signatureTimestamp
      },
      form: true
    }).its('body')
      .then(body => JSON.parse(body))
      .should(body => {
        expect(body.sessionInfo).to.exist;
        expect(body.id_token).to.exist;
      })
      .then(body => {
        cy.wrap(body).as('gigyaToken');
        cy.setCookie(body.sessionInfo.cookieName, body.sessionInfo.cookieValue);
      });
  });

  // Call the signin endpoint to ensure that the login is processed.
  cy.get('@gigyaToken').then(gigyaToken => {
    cy.request({
      method: 'POST',
      url: `${language}/api/signin`,
      headers: {
        'Authorization': `Bearer ${gigyaToken.id_token}`
      },
      body: {
        idToken: gigyaToken.id_token,
        redirectUri: '/'
      }
    });
  });

  // Make a test call to favorites to ensure we are now logged in.
  cy.request({
    method: 'GET',
    url: `${language}/api/favourite`
  }).its('body.result.response')
    .should('have.length.gte', 0);
});

/**
 * Clicks on the logout button in the profile menu.
 */
Cypress.Commands.add('logout', () => {
  cy.get('#profileMenu').click();
  cy.get('#profileWrapper [data-testid=profileComponentSignoutButton]').click();

  // Ensure we're one the market's homepage.
  cy.url().should('include', Cypress.config().baseUrl);
});