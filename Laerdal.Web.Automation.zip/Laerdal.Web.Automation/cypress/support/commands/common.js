/**
 * Get multiple aliases simultaneously.
 * @param names The names of the aliases to get.
 */
Cypress.Commands.add('getMany', (names) => {
  const values = [];

  for (const arg of names) {
    cy.get(arg).then((value) => values.push(value));
  }

  return cy.wrap(values);
});

/**
 * Detects OneTrust and clicks on the accept cookies button.
 */
Cypress.Commands.add('acceptCookieBanner', () => {
  cy.getCookies().then(cookies => {
    // Detect if OneTrust is installed on the page.
    const cookieOptanonConsent = cookies.find(cookie => cookie.name === 'OptanonConsent');
    // Detect if the cookie banner was previously closed.
    const cookieOptanonAlertBoxClosed = cookies.find(cookie => cookie.name === 'OptanonAlertBoxClosed');

    if (cookieOptanonConsent && !cookieOptanonAlertBoxClosed) {
      cy.get('#onetrust-accept-btn-handler').click();
    }
  });
});

/**
 * Installs the OneTrust alert box cookie so that the banner does not show.
 */
Cypress.Commands.add('suppressCookieBanner', () => {
  cy.setCookie('OptanonAlertBoxClosed', new Date().toISOString());
});

/**
 * Locates an iframe and interacts with the DOM.
 * Original source: https://www.cypress.io/blog/2020/02/12/working-with-iframes-in-cypress/
 */
Cypress.Commands.add('getIframe', (selector) => {
  // Get the iframe > document > body
  // and retry until the body element is not empty.
  return cy
    .get(selector)
    .its('0.contentDocument.body').should('not.be.empty')
    // Wraps the body DOM element to allow
    // chaining more Cypress commands, like .find(...).
    .then(cy.wrap);
});

/**
 * Add interceptors for cart requests.
 */
Cypress.Commands.add('interceptCart', () => {
  cy.intercept('PUT', '*/api/shoppingcart/*').as('addToCart');
  cy.intercept('PATCH', '*/api/shoppingcart/*').as('updateCart');
});

/**
 * Wait for the add to cart requests.
 */
Cypress.Commands.add('waitAddToCart', () => {
  cy.wait('@addToCart');
});

/**
 * Wait for the update cart requests.
 */
Cypress.Commands.add('waitUpdateCart', () => {
  cy.wait('@updateCart');
});

/**
 * Clicks on the cart icon and removes all items.
 */
Cypress.Commands.add('clearCart', () => {
  // Check if there are any items in cart
  cy.get('[data-testid=cart-item-count]')
    .invoke('text')
    .then((cartItems) => {
      if (parseInt(cartItems) > 0) {
        cy.get('[data-testid=header-cart]').click();
        cy.get('[data-testid=remove-from-cart]').each(removeButton => {
          cy.wrap(removeButton).click();
        });
      }
    });
});

/**
 * Add interceptors for checkout requests.
 */
Cypress.Commands.add('interceptCheckout', () => {
  cy.intercept('PUT', '*/api/checkout').as('checkout');
  cy.intercept('PUT', '*/api/checkout/order').as('order');
  cy.intercept('POST', '*/api/checkout/order-3ds2').as('order3ds');
});

/**
 * Wait for the checkout requests.
 */
Cypress.Commands.add('waitCheckout', () => {
  cy.wait('@checkout');
});

/**
 * Wait for the order requests.
 */
Cypress.Commands.add('waitOrder', () => {
  cy.wait('@order');
});

/**
 * Wait for the 3DS order requests.
 */
Cypress.Commands.add('waitOrder3ds', () => {
  cy.wait('@order3ds');
});
