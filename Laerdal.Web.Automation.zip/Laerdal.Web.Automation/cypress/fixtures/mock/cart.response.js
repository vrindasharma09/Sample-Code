export default {
  DefaultResponse: () => emptyResponse
};

const emptyResponse = {
  allowPartialShipment: false,
  disabledSingleShipment: false,
  notifications: [],
  lineItems: [],
  promotions: [],
  selectedPartialShipment: false,
  showQuoteButton: false,
  totals: {}
};