export default {
  DefaultResponse: () => emptyResponse
};

const emptyResponse = {
  billingAddress: {},
  shippingAddress: {},
  ctcCode: '',
  ctcCodeValid: false,
  canProceedWithInvalidCtc: false,
  ahaSecurityCode: '',
  deliveryMethods: [],
  displayLicenseDeliveryInfo: false,
  deliveryMethodId: '',
  emailLicenceRecipient: '',
  shipmentChoiceAvailable: false,
  singleShipmentDate: '',
  showExcludeTaxText: false,
  customerType: '',
  poNumber: '',
  invoiceNumber: '',
  hasElectronicInvoicing: false,
  electronicInvoiceNumber: '',
  vatNumber: '',
  hasClaimedTaxExempt: false,
  totals: {},
  notifications: [],
  currentStep: '',
  punchoutSessionId: ''
};