import { markets, accounts } from '../../support/helpers/markets';

const physicalSku = '152401'; // Manikin wipes.

const threeDSCardDetails = {
  // https://docs.adyen.com/development-resources/testing/test-card-numbers/#test-3d-secure-2-authentication
  number: '371449635398431',
  expDate: '0330',
  cvc: '7373',
  password: 'password'
};

const market = markets.find(m => m.id === 'no');
const account = accounts.find(a => a.username === 'online.business+no@laerdal.com');

describe('checkout', () => {

  /**
   * Verify 3DS credit card payments.
   */
  it('place 3ds credit card order', () => {
    cy.createUserSession(market.language, account.username, account.password);
    cy.deleteCart(market.language);
    cy.suppressCookieBanner();
    
    cy.visit(market.url);
    cy.interceptCart();

    // Add a physical item to cart.
    cy.visit(`${market.url}/item/${physicalSku}`);
    cy.get('[data-testid=product-details] [data-testid=add-to-cart]').click();
    cy.waitAddToCart();
    cy.get('[data-testid=mini-cart] [data-testid=view-cart]').click();

    cy.interceptCheckout();
    cy.get('[data-testid=checkout]').click();

    // Step 1: Address
    cy.get('[data-testid=billing-address] [data-testid=address-details]').should('exist');
    cy.get('[data-testid=shipping-address] [data-testid=address-details]').should('exist');
    cy.get('[data-testid=checkout-address] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 2: Delivery
    cy.get('[data-testid=checkout-delivery] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 3: Reference
    cy.get('[data-testid=checkout-reference] [data-testid=checkout-skip-step]').click();
    cy.waitCheckout();
    // Step 4: Select Credit Card
    cy.get('[data-testid=checkout-pay] [data-testid=creditOrDebitCard]').click();
    cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedCardNumberField] iframe').find('#encryptedCardNumber').type(threeDSCardDetails.number);
    cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedExpiryDateField] iframe').find('#encryptedExpiryDate').type(threeDSCardDetails.expDate);
    cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedSecurityCodeField] iframe').find('#encryptedSecurityCode').type(threeDSCardDetails.cvc);
    cy.get('[data-testid=checkout-pay] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 5: Summary
    cy.get('[data-testid=accept-terms]').click();
    cy.get('[data-testid=create-order]').click();
    cy.waitOrder();
    // Step 6: 3DS Verification
    cy.getIframe('iframe[name=threeDSIframe]').find('[type=password]').type(threeDSCardDetails.password);
    cy.getIframe('iframe[name=threeDSIframe]').find('#buttonSubmit').click();
    cy.waitOrder3ds();

    // Verify order confirmation.
    cy.url().should('include', `/${market.url}/checkout/confirmation`);
  });
});
