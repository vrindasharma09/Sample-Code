import {markets, accounts} from '../../support/helpers/markets';

const skus = [
  '152401', // Manikin wipes.
  '150-00001EXW', // Extended warranty.
  '206-50050', // SkillR (SimPadPlus) SW License.
  
  /**
   * The following package is based on 135-197-C-KIT.
   * 1x 135-01050 - Little Anne Combo 6-pack
   * 2x 197-02050 - AED Trainer 3-pack
   * 1x 197-10050 - AED Trainer Transport bag
   * 2x 152401 - Manikin wipes (pk a 1200) <==== This one is added extra as free items.
   * Price:
   *  kr 35 659,00, 25% VAT
   *  2 699,60 €, 21% VAT
   */
  'AUTOMATION-PACKAGE'
];

/**
 * The following coupon code gives 15% off on all 'Simulation and Training' items.
 */
const couponCode = 'AUTOMATION-PROMO';

const cardDetails = {
  number: '370000000000002',
  expDate: '0330',
  cvc: '7373'
};

const market = markets.find(m => m.id === 'no');
const account = accounts.find(a => a.username === 'online.business+no@laerdal.com');

describe('checkout', () => {

  /**
   * Scenarios:
   *  - Add physical, virtual and licensed items to cart.
   *  - Add package to cart.
   *  - Apply promo code.
   *  - Verify free shipping.
   *  - Verify electronic delivery message.
   *  - Place credit card order.
   *  - Verify the order placed in the database.
   */
  it('place credit card order with all types of items and a promo code', () => {
    cy.createUserSession(market.language, account.username, account.password);
    cy.deleteCart(market.language);
    cy.suppressCookieBanner();

    cy.visit(market.url);
    cy.interceptCart();

    // Loop all SKUs and add them to cart.
    skus.forEach(sku => {
      cy.visit(`${market.url}/item/${sku}`);
      cy.get('[data-testid=product-details] [data-testid=add-to-cart]').click();
      cy.waitAddToCart();
      cy.get('[data-testid=mini-cart] [data-testid=item-sku]').contains(sku);
      // Go to the cart page.
      cy.get('[data-testid=mini-cart] [data-testid=view-cart]').click();
    });
    
    // Type in the coupon code.
    cy.get('[data-testid=enter-coupon-code]').click();
    cy.get('[data-testid=coupon-code]').type(couponCode);
    cy.get('[data-testid=apply-coupon-code]').click();
    // Ensure the coupon code was applied to the cart.
    cy.get('[data-testid=cart-coupon-code]').contains(couponCode);

    cy.interceptCheckout();
    cy.get('[data-testid=checkout]').click();

    // Step 1: Address
    cy.get('[data-testid=billing-address] [data-testid=address-details]').should('exist');
    cy.get('[data-testid=shipping-address] [data-testid=address-details]').should('exist');
    cy.get('[data-testid=checkout-address] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 2: Delivery
    // Ensure we see a form for email delivery
    cy.get('[data-testid=checkout-delivery] [data-testid=electronic-delivery-form]').should('exist');
    cy.get('[data-testid=checkout-delivery] [data-testid=electronic-delivery-form] input').type(account.username);
    cy.get('[data-testid=checkout-delivery] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 3: Reference
    cy.get('[data-testid=checkout-reference] [data-testid=checkout-skip-step]').click();
    cy.waitCheckout();
    // Step 4: Select Credit Card
    cy.get('[data-testid=checkout-pay] [data-testid=creditOrDebitCard]').click();
    cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedCardNumberField] iframe').find('#encryptedCardNumber').type(cardDetails.number);
    cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedExpiryDateField] iframe').find('#encryptedExpiryDate').type(cardDetails.expDate);
    cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedSecurityCodeField] iframe').find('#encryptedSecurityCode').type(cardDetails.cvc);
    cy.get('[data-testid=checkout-pay] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 5: Summary
    cy.get('[data-testid=accept-terms]').click();
    cy.get('[data-testid=create-order]').click();
    cy.waitOrder();

    // Verify order confirmation.
    cy.url().should('include', `/${market.url}/checkout/confirmation`);

    // Verify the order that was stored in the database.
    cy.get('[data-testid=order-confirmation]').invoke('attr', 'data-order').as('order');
    cy.get('[data-testid=order-confirmation]').invoke('attr', 'data-customer').as('customer');
    cy.getMany(['@order', '@customer']).then(([orderNumber, customerNumber]) => cy.getOrder(orderNumber, customerNumber)
      .then(order => cy.log(order).then(() => order))
      .should(order => {
        expect(order.id).to.eq(orderNumber);
        expect(order.appliedPromos).to.have.length(1);
        expect(order.appliedPromos.find(p => p.coupon === couponCode)).to.exist;
      }));
  });
});