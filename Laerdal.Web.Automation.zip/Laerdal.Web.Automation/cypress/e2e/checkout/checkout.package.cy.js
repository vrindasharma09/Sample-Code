import {markets, accounts} from '../../support/helpers/markets';

/**
 * The following package is based on 135-197-C-KIT.
 * 1x 135-01050 - Little Anne Combo 6-pack
 * 2x 197-02050 - AED Trainer 3-pack
 * 1x 197-10050 - AED Trainer Transport bag
 * 2x 152401 - Manikin wipes (pk a 1200) <==== This one is added extra as free items.
 * Price:
 *  kr 35 659,00, 25% VAT
 *  2 699,60 €, 21% VAT
 */
const packageSku = 'AUTOMATION-PACKAGE';
const packageQuantity = 2;

const cardDetails = {
  number: '370000000000002',
  expDate: '0330',
  cvc: '7373'
};

const data = [
  {
    market: markets.find(m => m.id === 'no'),
    account: accounts.find(a => a.username === 'online.business+no@laerdal.com'),
    expectedOrder: {
      orderTotal: 92772.5,
      taxTotal: 18554.5,
      orderLines: [
        {
          product: '135-01050',
          listPrice: 18498,
          price: 17931.77,
          taxAmount: 8965.89,
          taxRate: 25,
          taxCode: 'B',
          quantityOrdered: 2,
          kit: packageSku
        },
        {
          product: '197-02050',
          listPrice: 8799,
          price: 8529.66,
          taxAmount: 8529.66,
          taxRate: 25,
          quantityOrdered: 4,
          taxCode: 'B',
          kit: packageSku
        },
        {
          product: '197-10050',
          listPrice: 689,
          price: 667.91,
          taxAmount: 333.95,
          taxRate: 25,
          quantityOrdered: 2,
          taxCode: 'B',
          kit: packageSku
        },
        {
          product: '152401',
          listPrice: 0,
          price: 0,
          taxAmount: 0,
          taxRate: 0,
          quantityOrdered: 4,
          taxCode: 'B',
          kit: packageSku
        }
      ],
      kits: [
        {
          kitSku: packageSku,
          netPrice: 35659,
          quantity: 2
        }
      ],
      shipping: {
        shippingCost: 2900
      }
    }
  },
  {
    market: markets.find(m => m.id === 'nl'),
    account: accounts.find(a => a.username === 'online.business+nl@laerdal.com'),
    expectedOrder: {
      orderTotal: 6533.03,
      taxTotal: 1133.83,
      orderLines: [
        {
          product: '135-01050',
          listPrice: 1599,
          price: 1359.15,
          taxAmount: 570.84,
          taxRate: 21,
          taxCode: 'B',
          quantityOrdered: 2,
          kit: packageSku
        },
        {
          product: '197-02050',
          listPrice: 759,
          price: 645.15,
          taxAmount: 541.93,
          taxRate: 21,
          quantityOrdered: 4,
          taxCode: 'B',
          kit: packageSku
        },
        {
          product: '197-10050',
          listPrice: 59,
          price: 50.15,
          taxAmount: 21.06,
          taxRate: 21,
          quantityOrdered: 2,
          taxCode: 'B',
          kit: packageSku
        },
        {
          product: '152401',
          listPrice: 0,
          price: 0,
          taxAmount: 0,
          taxRate: 0,
          quantityOrdered: 4,
          taxCode: 'B',
          kit: packageSku
        }
      ],
      kits: [
        {
          kitSku: packageSku,
          netPrice: 2699.6,
          quantity: 2
        }
      ],
      shipping: {
        shippingCost: 0
      }
    }
  }
];

describe('checkout', () => {

  data.forEach(({market, account, expectedOrder}) => {

    /**
     * IMPORTANT: We are making a separate test on packages for the Netherlands
     * as this market has specifics regarding tax calculation.
     * 
     * Scenarios:
     *  - Add package item to cart.
     *  - Place credit card order.
     *  - Verify the order placed in the database.
     */
    it(`place credit card order with a package item <${market.id}>`, () => {
      cy.createUserSession(market.language, account.username, account.password);
      cy.deleteCart(market.language);
      cy.suppressCookieBanner();

      cy.visit(market.url);
      cy.interceptCart();

      // Add a package item to cart.
      cy.visit(`${market.url}/item/${packageSku}`);
      cy.get('[data-testid=product-details] [data-testid=add-to-cart]').click();
      cy.waitAddToCart();
      cy.get('[data-testid=mini-cart] [data-testid=item-sku]').contains(packageSku);
      // Modify the mini cart quantity.
      cy.get('[data-testid=mini-cart] [data-testid=mini-cart-quantity]').first().clear();
      cy.get('[data-testid=mini-cart] [data-testid=mini-cart-quantity]').first().type(packageQuantity);
      cy.waitUpdateCart();
      cy.get('[data-testid=mini-cart] [data-testid=view-cart]').click();
      cy.get(`[data-testid=cart-line-item-${packageSku}] [data-testid=cart-quantity]`)
        .invoke('val')
        .then(parseFloat)
        .should('equal', packageQuantity);

      cy.interceptCheckout();
      cy.get('[data-testid=checkout]').click();

      // Step 1: Address
      cy.get('[data-testid=billing-address] [data-testid=address-details]').should('exist');
      cy.get('[data-testid=shipping-address] [data-testid=address-details]').should('exist');
      cy.get('[data-testid=checkout-address] [data-testid=checkout-next-step]').click();
      cy.waitCheckout();
      // Step 2: Delivery
      cy.get('[data-testid=checkout-delivery] [data-testid=checkout-next-step]').click();
      cy.waitCheckout();
      // Step 3: Reference
      cy.get('[data-testid=checkout-reference] [data-testid=checkout-skip-step]').click();
      cy.waitCheckout();
      // Step 4: Select Credit Card
      cy.get('[data-testid=checkout-pay] [data-testid=creditOrDebitCard]').click();
      cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedCardNumberField] iframe').find('#encryptedCardNumber').type(cardDetails.number);
      cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedExpiryDateField] iframe').find('#encryptedExpiryDate').type(cardDetails.expDate);
      cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedSecurityCodeField] iframe').find('#encryptedSecurityCode').type(cardDetails.cvc);
      cy.get('[data-testid=checkout-pay] [data-testid=checkout-next-step]').click();
      cy.waitCheckout();
      // Step 5: Summary
      cy.get('[data-testid=accept-terms]').click();
      cy.get('[data-testid=create-order]').click();
      cy.waitOrder();

      // Verify order confirmation.
      cy.url().should('include', `/${market.url}/checkout/confirmation`);

      // Verify the order that was stored in the database.
      cy.get('[data-testid=order-confirmation]').invoke('attr', 'data-order').as('order');
      cy.get('[data-testid=order-confirmation]').invoke('attr', 'data-customer').as('customer');
      cy.getMany(['@order', '@customer']).then(([orderNumber, customerNumber]) => cy.getOrder(orderNumber, customerNumber)
        .then(order => cy.log(order, expectedOrder).then(() => order))
        .should(order => {
          expect(order.id).to.eq(orderNumber);
          // Verify that package has been broken down correctly.
          expect(Cypress._.isMatch(order, expectedOrder)).to.be.true;
        }));
    });
  });
});