import {markets, accounts} from '../../support/helpers/markets';

/**
 * The following package is based on 135-197-C-KIT.
 * 1x 135-01050 - Little Anne Combo 6-pack
 * 2x 197-02050 - AED Trainer 3-pack
 * 1x 197-10050 - AED Trainer Transport bag
 * 2x 152401 - Manikin wipes (pk a 1200) <==== This one is added extra as free items.
 * Price:
 *  kr 35 659,00, 25% VAT
 *  2 699,60 €, 21% VAT
 */
const packageSku = 'AUTOMATION-PACKAGE';
const physicalSku = '152401'; // Manikin wipes.

const data = [
  {
    market: markets.find(m => m.id === 'no'),
    account: accounts.find(a => a.username === 'online.business+no@laerdal.com')
  },
  {
    market: markets.find(m => m.id === 'nl'),
    account: accounts.find(a => a.username === 'online.business+nl@laerdal.com')
  }
];

describe('checkout', () => {

  data.forEach(({market, account}) => {

    /**
     * IMPORTANT: We are making a separate test on packages for the Netherlands
     * as this market has specifics regarding tax calculation.
     *
     * Scenarios:
     *  - Add package item to cart.
     *  - Add a physical item to cart.
     *  - Place on account order.
     *  - Verify the order placed in the database.
     */
    it(`place on account order with a package and physical item <${market.id}>`, () => {
      cy.createUserSession(market.language, account.username, account.password);
      cy.deleteCart(market.language);
      cy.suppressCookieBanner();

      cy.visit(market.url);
      cy.interceptCart();

      // Add a package item to cart.
      cy.visit(`${market.url}/item/${packageSku}`);
      cy.get('[data-testid=product-details] [data-testid=add-to-cart]').click();
      cy.waitAddToCart();
      cy.get('[data-testid=mini-cart] [data-testid=item-sku]').contains(packageSku);

      // Add a physical item to cart.
      cy.visit(`${market.url}/item/${physicalSku}`);
      cy.get('[data-testid=product-details] [data-testid=add-to-cart]').click();
      cy.waitAddToCart();
      cy.get('[data-testid=mini-cart] [data-testid=item-sku]').contains(physicalSku);
      
      cy.get('[data-testid=mini-cart] [data-testid=view-cart]').click();

      cy.interceptCheckout();
      cy.get('[data-testid=checkout]').click();

      // Step 1: Address
      cy.get('[data-testid=billing-address] [data-testid=address-details]').should('exist');
      cy.get('[data-testid=shipping-address] [data-testid=address-details]').should('exist');
      cy.get('[data-testid=checkout-address] [data-testid=checkout-next-step]').click();
      cy.waitCheckout();
      // Step 2: Delivery
      cy.get('[data-testid=checkout-delivery] [data-testid=checkout-next-step]').click();
      cy.waitCheckout();
      // Step 3: Reference
      cy.get('[data-testid=checkout-reference] [data-testid=checkout-skip-step]').click();
      cy.waitCheckout();
      // Step 4: Select On Account
      cy.get('[data-testid=checkout-pay] [data-testid=onAccount]').click();
      cy.get('[data-testid=checkout-pay] [data-testid=checkout-next-step]').click();
      cy.waitCheckout();
      // Step 5: Summary
      cy.get('[data-testid=accept-terms]').click();
      cy.get('[data-testid=create-order]').click();
      cy.waitOrder();

      // Verify order confirmation.
      cy.url().should('include', `/${market.url}/checkout/confirmation`);

      // Verify the order that was stored in the database.
      cy.get('[data-testid=order-confirmation]').invoke('attr', 'data-order').as('order');
      cy.get('[data-testid=order-confirmation]').invoke('attr', 'data-customer').as('customer');
      cy.getMany(['@order', '@customer']).then(([orderNumber, customerNumber]) => cy.getOrder(orderNumber, customerNumber)
        .then(order => cy.log(order).then(() => order))
        .should(order => {
          expect(order.id).to.eq(orderNumber);
          expect(order.paymentTerms.paymentMethod).to.eq('ON ACCOUNT');
        }));
    });
  });
});