import {markets, accounts} from '../../support/helpers/markets';

/**
 * We are buying a relatively cheap item that will not trigger
 * the free shipping if buying only 1 item.
 * The free shipping threshold for Denmakr is 1,300 DKK.
 */
const physicalSku = '212-77455'; // WIFI dongle SimMan 3G.

const market = markets.find(m => m.id === 'dk');
const account = accounts.find(a => a.username === 'online.business+dk@laerdal.com');

describe('free shipping', () => {
  
  /**
   * Verify free shipping.
   * This test is intended to run in production so the test credit card will not be valid.
   */
  it('verify free shipping', () => {
    cy.createUserSession(market.language, account.username, account.password);
    cy.deleteCart(market.language);
    cy.suppressCookieBanner();

    cy.visit(market.url);

    cy.interceptCart();

    // Add a physical item to cart.
    cy.visit(`${market.url}/item/${physicalSku}`);
    cy.get('[data-testid=product-details] [data-testid=add-to-cart]').click();
    cy.waitAddToCart();
    cy.get('[data-testid=mini-cart] [data-testid=view-cart]').click();

    cy.interceptCheckout();
    cy.get('[data-testid=checkout]').click();

    // We need to advance to the delivery step and pick a shipping method in order
    // to see the shipping cost.
    // Step 1: Address
    cy.get('[data-testid=billing-address] [data-testid=address-details]').should('exist');
    cy.get('[data-testid=shipping-address] [data-testid=address-details]').should('exist');
    cy.get('[data-testid=checkout-address] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 2: Delivery
    cy.get('[data-testid=checkout-delivery] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    cy.get('[data-testid=back-to-cart]').click();

    // Ensure we are being charged for shipping.
    cy.get('[data-testid=shipping-total]')
      .invoke('text')
      .then(parseFloat)
      .should('be.gt', 0);

    // Increase the item quantity in order to get free shipping.
    // Note that since we started with a clear cart, there should be only
    // one cart line item.
    cy.get('[data-testid=cart-quantity]').clear();
    cy.get('[data-testid=cart-quantity]').type(10);
    cy.get('[data-testid=cart-quantity]').blur();
    cy.waitUpdateCart();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000); // Wait for the UI to update after the API call.

    // Ensure we now have free shipping.
    cy.get('[data-testid=shipping-total]')
      .invoke('text')
      .then(parseFloat)
      .should('equal', 0);
  });
});
