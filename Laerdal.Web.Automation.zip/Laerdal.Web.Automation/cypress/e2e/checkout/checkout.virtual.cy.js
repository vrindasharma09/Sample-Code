import { markets, accounts } from '../../support/helpers/markets';

const virtualSku = '150-00001EXW'; // Extended warranty.

const cardDetails = {
  number: '370000000000002',
  expDate: '0330',
  cvc: '7373'
};

const market = markets.find(m => m.id === 'no');
const account = accounts.find(a => a.username === 'online.business+no@laerdal.com');

describe('checkout', () => {

  /**
   * Scenarios:
   *  - Add virtual item to cart.
   *  - Verify electronic delivery message.
   *  - Place credit card order.
   *  - Verify the order placed in the database.
   */
  it('place credit card order with a virtual item', () => {
    cy.createUserSession(market.language, account.username, account.password);
    cy.deleteCart(market.language);
    cy.suppressCookieBanner();
    
    cy.visit(market.url);
    cy.interceptCart();

    // Add a virtual item to cart.
    cy.visit(`${market.url}/item/${virtualSku}`);
    cy.get('[data-testid=product-details] [data-testid=add-to-cart]').click();
    cy.waitAddToCart();
    cy.get('[data-testid=mini-cart] [data-testid=item-sku]').contains(virtualSku);
    cy.get('[data-testid=mini-cart] [data-testid=view-cart]').click();

    cy.interceptCheckout();
    cy.get('[data-testid=checkout]').click();

    // Step 1: Address
    cy.get('[data-testid=billing-address] [data-testid=address-details]').should('exist');
    cy.get('[data-testid=shipping-address] [data-testid=address-details]').should('exist');
    cy.get('[data-testid=checkout-address] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 2: Delivery
    // Ensure we see a message for electronic delivery.
    cy.get('[data-testid=checkout-delivery] [data-testid=electronic-delivery-message]').should('exist');
    cy.get('[data-testid=checkout-delivery] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 3: Reference
    cy.get('[data-testid=checkout-reference] [data-testid=checkout-skip-step]').click();
    cy.waitCheckout();
    // Step 4: Select Credit Card
    cy.get('[data-testid=checkout-pay] [data-testid=creditOrDebitCard]').click();
    cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedCardNumberField] iframe').find('#encryptedCardNumber').type(cardDetails.number);
    cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedExpiryDateField] iframe').find('#encryptedExpiryDate').type(cardDetails.expDate);
    cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedSecurityCodeField] iframe').find('#encryptedSecurityCode').type(cardDetails.cvc);
    cy.get('[data-testid=checkout-pay] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 5: Summary
    cy.get('[data-testid=accept-terms]').click();
    cy.get('[data-testid=create-order]').click();
    cy.waitOrder();

    // Verify order confirmation.
    cy.url().should('include', `/${market.url}/checkout/confirmation`);

    // Verify the order that was stored in the database.
    cy.get('[data-testid=order-confirmation]').invoke('attr', 'data-order').as('order');
    cy.get('[data-testid=order-confirmation]').invoke('attr', 'data-customer').as('customer');
    cy.getMany(['@order', '@customer']).then(([orderNumber, customerNumber]) => cy.getOrder(orderNumber, customerNumber)
      .then(order => cy.log(order).then(() => order))
      .should(order => {
        expect(order.id).to.eq(orderNumber);
      }));
  });
});
