import { markets, accounts } from '../../support/helpers/markets';

/**
 * We are buying a relatively cheap item that will not trigger
 * the free shipping if buying only 1 item.
 * The free shipping threshold for Denmakr is 1,300 DKK.
 */
const physicalSku = '212-77455'; // WIFI dongle SimMan 3G.

const cardDetails = {
  number: '370000000000002',
  expDate: '0330',
  cvc: '7373'
};

const market = markets.find(m => m.id === 'dk');
const account = accounts.find(a => a.username === 'online.business+dk@laerdal.com');

describe('free shipping', () => {

  /**
   * Scenarios:
   *  - Add physical item to cart.
   *  - Check shipping.
   *  - Increase item quantities.
   *  - Check shipping.
   *  - Enter purchase order number as it is required for Denmark E-Invoicing.
   *  - Place credit card order.
   *  - Verify the order placed in the database.
   */
  it('place credit card order with free shipping', () => {
    cy.createUserSession(market.language, account.username, account.password);
    cy.deleteCart(market.language);
    cy.suppressCookieBanner();
    
    cy.visit(market.url);

    cy.interceptCart();

    // Add a physical item to cart.
    cy.visit(`${market.url}/item/${physicalSku}`);
    cy.get('[data-testid=product-details] [data-testid=add-to-cart]').click();
    cy.waitAddToCart();
    cy.get('[data-testid=mini-cart] [data-testid=view-cart]').click();

    cy.interceptCheckout();
    cy.get('[data-testid=checkout]').click();

    // We need to advance to the delivery step and pick a shipping method in order
    // to see the shipping cost.
    // Step 1: Address
    cy.get('[data-testid=billing-address] [data-testid=address-details]').should('exist');
    cy.get('[data-testid=shipping-address] [data-testid=address-details]').should('exist');
    cy.get('[data-testid=checkout-address] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 2: Delivery
    cy.get('[data-testid=checkout-delivery] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    cy.get('[data-testid=back-to-cart]').click();

    // Ensure we are being charged for shipping.
    cy.get('[data-testid=shipping-total]')
      .invoke('text')
      .then(parseFloat)
      .should('be.gt', 0);

    // Increase the item quantity in order to get free shipping.
    // Note that since we started with a clear cart, there should be only
    // one cart line item.
    cy.get('[data-testid=cart-quantity]').clear();
    cy.get('[data-testid=cart-quantity]').type(10);
    cy.get('[data-testid=cart-quantity]').blur();
    cy.waitUpdateCart();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000); // Wait for the UI to update after the API call.

    // Ensure we now have free shipping.
    cy.get('[data-testid=shipping-total]')
      .invoke('text')
      .then(parseFloat)
      .should('equal', 0);

    cy.interceptCheckout();
    cy.get('[data-testid=checkout]').click();

    // Step 1: Address
    cy.get('[data-testid=billing-address] [data-testid=address-details]').should('exist');
    cy.get('[data-testid=shipping-address] [data-testid=address-details]').should('exist');
    cy.get('[data-testid=checkout-address] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 2: Delivery
    // Ensure we see a free shipping option.
    cy.get('[data-testid=checkout-delivery] div[name=deliveryMethod] label')
      .first()
      .invoke('text')
      .then(parseFloat)
      .should('equal', 0);
    cy.get('[data-testid=checkout-delivery] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 3: Reference
    cy.get('[data-testid=checkout-reference] [data-testid=dynamic-field][data-formkey=poNumber]').type('PO123456');
    cy.get('[data-testid=checkout-reference] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 4: Select Credit Card
    cy.get('[data-testid=checkout-pay] [data-testid=creditOrDebitCard]').click();
    cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedCardNumberField] iframe').find('#encryptedCardNumber').type(cardDetails.number);
    cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedExpiryDateField] iframe').find('#encryptedExpiryDate').type(cardDetails.expDate);
    cy.getIframe('[data-testid=checkout-pay] [data-hosted-id=hostedSecurityCodeField] iframe').find('#encryptedSecurityCode').type(cardDetails.cvc);
    cy.get('[data-testid=checkout-pay] [data-testid=checkout-next-step]').click();
    cy.waitCheckout();
    // Step 5: Summary
    // Ensure we now have free shipping.
    cy.get('[data-testid=shipping-total]')
      .invoke('text')
      .then(parseFloat)
      .should('equal', 0);
    cy.get('[data-testid=accept-terms]').click();
    cy.get('[data-testid=create-order]').click();
    cy.waitOrder();

    // Verify order confirmation.
    cy.url().should('include', `/${market.url}/checkout/confirmation`);

    // Verify the order that was stored in the database.
    cy.get('[data-testid=order-confirmation]').invoke('attr', 'data-order').as('order');
    cy.get('[data-testid=order-confirmation]').invoke('attr', 'data-customer').as('customer');
    cy.getMany(['@order', '@customer']).then(([orderNumber, customerNumber]) => cy.getOrder(orderNumber, customerNumber)
      .then(order => cy.log(order).then(() => order))
      .should(order => {
        expect(order.poNumber).to.eq('PO123456');
        expect(order.shipping.shippingCost).to.eq(0);
        expect(order.appliedPromos).to.have.length(1);
        expect(order.appliedPromos[0].title.toLowerCase()).to.contain('free shipping');
      }));
  });
});
