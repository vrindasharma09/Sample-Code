import {markets} from '../support/helpers/markets';

const market = markets.find(m => m.id === 'no');

describe('customer support', () => {

  beforeEach(() => {
    cy.suppressCookieBanner();
  });

  it('contact support', () => {
    cy.visit(`${market.url}/support/customer-service`);

    // Select contact support and submit a query.
    cy.get('[data-testid=form-selection]').select('12907');
    cy.get('[data-form="General Customer Support"]').within(() => {
      cy.get('[data-form-field=firstName]').type('FirstName');
      cy.get('[data-form-field=lastName]').type('LastName');
      cy.get('[data-form-field=emailAddress]').type('testmail@support.com');
      cy.get('[data-form-field=busPhone]').type('9876543210');
      cy.get('[data-form-field=Organisation]').type('company');
      cy.get('[data-form-field=yourQuestion]').type('Automation test query');
      cy.get('[data-form-field=contactMethod][value=Email]').click({force: true});
      cy.get('[data-testid=form-submit]').click();
      cy.get('[data-testid=form-status].Form__Success__Message').should('be.visible');
    });
  });
});
