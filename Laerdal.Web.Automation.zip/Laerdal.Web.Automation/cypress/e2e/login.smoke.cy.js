import { markets, accounts } from '../support/helpers/markets';

describe('login', () => {

  beforeEach(() => {
    cy.suppressCookieBanner();
  });

  markets.forEach(market => {
    if (!market.commerce) {
      // Skip markets that don't have login enabled.
      return;
    }

    const marketAccounts = accounts.filter(a => a.market === market.id);
    if (marketAccounts.length === 0) {
      // Skip markets that don't have a defined account.
      it.skip(`should navigate to Laerdal Connect after login <${market.id}>`);
      return;
    }

    const account = accounts[0];

    it(`navigate to Laerdal Connect after login <${market.id}>`, () => {
      cy.log(`testing account ${account.username}`);
      cy.visit(market.url);

      // Ensure the header buttons exist.
      cy.get('[data-testid=header-search]').should('exist');
      cy.get('[data-testid=header-favorites]').should('not.exist');
      cy.get('[data-testid=header-cart]').should('exist');

      cy.createUserSession(market.language, account.username, account.password);
      cy.visit(market.url);

      // Ensure the header buttons exist after login.
      cy.get('[data-testid=header-search]').should('exist');
      cy.get('[data-testid=header-favorites]').should('exist');
      cy.get('[data-testid=header-cart]').should('exist');
    });
  });
});
