import {markets} from '../support/helpers/markets';

const market = markets.find(m => m.id === 'no');

describe('filtering', () => {
  beforeEach(() => {
    cy.suppressCookieBanner();
  });

  it('filter by single', () => {
    cy.visit(`${market.url}/products/simulation-training/resuscitation-training/`);

    // click the filter button
    cy.get('[data-testid=filtering-resuscitation-training]').click();

    // dropdown should be visible
    cy.get('[data-testid=filtering-dropdown]').should('have.class', 'is-open');
    cy.get('[data-testid=filtering-selectlist]').should('be.visible');

    // chip is not visible
    cy.get('[data-testid=filtering-chip]').should('not.be.visible');

    // select a filter
    cy.get('[data-testid=filtering-checkbox-item]').first().click();

    // dropdown should still be visible
    cy.get('[data-testid=filtering-dropdown]').should('have.class', 'is-open');
    cy.get('[data-testid=filtering-selectlist]').should('be.visible');

    // checkbox was checked
    cy.get('[data-testid=filtering-checkbox-item] input').first().should('be.checked');

    // loading new values
    cy.get('[data-testid=product-listing-loading]').should('have.class', 'is-active');

    // click outside the dropdown
    cy.get('[data-testid=filtering-click-outside]').click();

    // dropdown should not be visible anymore
    cy.get('[data-testid=filtering-dropdown]').should('not.have.class', 'is-open');
    cy.get('[data-testid=filtering-selectlist]').should('not.be.visible');

    // chip is visible
    cy.get('[data-testid=filtering-chip]').should('be.visible');

    // click clos button on the chip
    cy.get('[data-testid=close-chip]').click();

    // chip is not visible
    cy.get('[data-testid=filtering-chip]').should('not.be.visible');


  });
});