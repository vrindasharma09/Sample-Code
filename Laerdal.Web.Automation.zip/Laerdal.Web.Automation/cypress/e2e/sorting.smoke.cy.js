import { markets } from '../support/helpers/markets';

const market = markets.find(m => m.id === 'no');

describe('sorting', () => {

  beforeEach(() => {
    cy.suppressCookieBanner();
  });

  it('sort products', () => {
    cy.visit(`${market.url}/products/simulation-training/resuscitation-training/`);

    // click the sorting button
    cy.get('[data-testid=sorting-product-listing]').click();

    // dropdown should be visible
    cy.get('[data-testid=sorting-dropdown]').should('have.class', 'is-open');
    cy.get('[data-testid=sorting-selectlist]').should('be.visible');

    // select a sort option
    cy.get('[data-testid=sorting-selectlist] li:nth-child(2)').click();

    // dropdown should not be visible anymore
    cy.get('[data-testid=sorting-dropdown]').should('not.have.class', 'is-open');
    cy.get('[data-testid=sorting-selectlist]').should('not.be.visible');

    // loading new values
    cy.get('[data-testid=product-listing-loading]').should('have.class', 'is-active');

    // click the sorting button
    cy.get('[data-testid=sorting-product-listing]').click();

    // click outside the dropdown
    cy.get('[data-testid=sorting-click-outside]').click();

    // dropdown should not be visible anymore
    cy.get('[data-testid=sorting-dropdown]').should('not.have.class', 'is-open');
    cy.get('[data-testid=sorting-selectlist]').should('not.be.visible');

  });

  it('check that selected value changes after sort', () => {
    cy.visit(`${market.url}/products/simulation-training/resuscitation-training/`);

    // copy the button text on the sorting element
    cy.get('[data-testid=sorting-product-listing]').invoke('text')
      .then((previousValue) => {
        //click the sorting button
        cy.get('[data-testid=sorting-product-listing]').click();

        //click on the second item on the dropdown list
        cy.get('[data-testid=sorting-selectlist] li:nth-child(2)').click();

        // verify that the button text is different from the original button text
        cy.get('[data-testid=sorting-product-listing]').invoke('text').should('not.eq', previousValue);
      });
  });

});