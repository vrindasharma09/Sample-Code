describe('laerdal global health', () => {
  it('visit lgh', () => {
    cy.visit(Cypress.env('laerdalGlobalHealthUrl'));
  });
});
