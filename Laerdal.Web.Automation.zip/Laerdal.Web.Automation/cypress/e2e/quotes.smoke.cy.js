import { markets, accounts } from '../support/helpers/markets';

const market = markets.find(m => m.id === 'be-nl');
const account = accounts.find(a => a.username === 'online.business+be-nl@laerdal.com');

describe('quotes', () => {

  beforeEach(() => {
    cy.suppressCookieBanner();
  });

  it('see quotes page', () => {
    cy.log(`testing account ${account.username}`);
    cy.createUserSession(market.language, account.username, account.password);
    cy.visit(market.url);

    cy.get('#profileMenu').click();
    cy.get('#profileWrapper #profileMenuQuotes').click();

    cy.url().should('include', `/${market.url}/account/quotes`);
  });
});
