﻿import {apiHeaders} from '../../support/helpers/api';

describe('product info', () => {

  it('get product info and translations from Optimizely', () => {

    const expectedProductInfo = [{
      sku: '300-00750',
      found: true,
      displayName: 'Blod konsentrat ,118 ml'
    }];

    cy.request({
      method: 'POST',
      url: 'api/v1.0/product-info',
      headers: {...apiHeaders},
      body: {
        skus: [
          '300-00750' // Fake blood.
        ],
        countryCode: 'no'
      }
    }).its('body')
      .should(productInfo => expect(Cypress._.isMatch(productInfo, expectedProductInfo)).to.be.true);
  });

  it('get product info and translations from Enable', () => {

    const expectedProductInfo = [{
      sku: '300-00750',
      found: true,
      displayName: '擬似血液(95mL)'
    }];

    cy.request({
      method: 'POST',
      url: 'api/v1.0/product-info',
      headers: {...apiHeaders},
      body: {
        skus: [
          '300-00750' // Fake blood.
        ],
        countryCode: 'jp'
      }
    }).its('body')
      .should(productInfo => expect(Cypress._.isMatch(productInfo, expectedProductInfo)).to.be.true);
  });
});