import { defaultMarketLanguage, markets } from '../../support/helpers/markets';
import { apiHeaders } from '../../support/helpers/api';

const market = markets.find(m => m.id === 'no');
const sku = 'AUTOMATION-AVAILABILITY';

const skuVariant = {
  sku: sku,
  name: 'Automation Availability',
  displayName: 'Automation Sku for Availability',
  description: 'A generated SKU for testing availability.',
  productLine: 'QCPR'
};

describe('availability', () => {
  
  before(() => {
    cy.initializeSku(skuVariant);
  });

  beforeEach(() => {
    cy.initializeMarketSku(skuVariant, market);
    cy.verifySkuPage(skuVariant, market);
  });

  /**
   * This test covers the flow when an item becomes inactive.
   * The expectation is that all market settings will then transfer to
   * being inactive. This way support can later come back and decide
   * if the item should be active of any of the markets.
   */
  it('make active market settings as inactive', () => {

    // Transfer the item to being inactive.
    cy.updateSku(
      { ...skuVariant, availabilityStatus: 'Inactive' },
      defaultMarketLanguage
    );

    // Ensure we are getting the same response on the get operation.
    cy.getSku(sku, defaultMarketLanguage).its('availabilityStatus').should('eq', 'Inactive');
    cy.getSku(sku, defaultMarketLanguage).its('productLine').should('eq', 'QCPR');

    // Update sku market to inactive.
    cy.updateSkuMarkets({
      sku: sku,
      markets: [{
        marketId: market.code,
        defaultWarehouse: market.defaultWarehouse,
        taxCode: 'B',
        availabilityStatus: 'Inactive'
      }]
    });

    // Ensure that market settings have converted to inactive.
    cy.getSkuMarkets(sku).should(skuMarkets => {
      // Verify the updated availability.
      const availability = skuMarkets.markets.find(m => m.marketId === market.code);
      expect(availability.availabilityStatus).to.eq('Inactive');
    });

    // TODO: OB-5211
    // We're experiencing a slowdown in publishing changes
    // from the data exchange API for prices and availability.
    // Commenting the following code as it is not updating the
    // page visibility immediately.
    /* // Ensure that the item pages return 404.
    cy.request({
      method: 'GET',
      url: `${market.url}/item/${sku}`,
      failOnStatusCode: false
    }).its('status')
      .should('eq', 404); */
  });

  /**
   * This test covers the flow when an item becomes obsolete.
   * The expectation is that all market settings will then transfer to
   * being obsolete. This way support can later come back and decide
   * if the item should be active of any of the markets.
   * OB-4111
   */
  it('make inactive market settings obsolete', () => {

    // Transfer the item to being obsolete.
    cy.updateSku(
      { ...skuVariant, availabilityStatus: 'Obsolete' },
      defaultMarketLanguage
    );

    // Ensure we are getting the same response on the get operation.
    cy.getSku(sku, defaultMarketLanguage).its('availabilityStatus').should('eq', 'Obsolete');

    // Update sku market to obsolete.
    cy.updateSkuMarkets({
      sku: sku,
      markets: [{
        marketId: market.code,
        defaultWarehouse: market.defaultWarehouse,
        taxCode: 'B',
        availabilityStatus: 'Obsolete'
      }]
    });

    // Ensure that all market settings have converted to obsolete.
    cy.getSkuMarkets(sku).should(skuMarkets => {
      // Verify the updated availability.
      const availability = skuMarkets.markets.find(m => m.marketId === market.code);
      expect(availability.availabilityStatus).to.eq('Obsolete');
    });

    // TODO: OB-5211
    // We're experiencing a slowdown in publishing changes
    // from the data exchange API for prices and availability.
    // Commenting the following code as it is not updating the
    // page visibility immediately.
    /* // Ensure that the item pages return 404.
    cy.request({
      method: 'GET',
      url: `${market.url}/item/${sku}`,
      failOnStatusCode: false
    }).its('status')
      .should('eq', 404); */
  });

  it('return bad request if status is not valid', () => {

    // Update the item with invalid status
    cy.request({
      method: 'PUT',
      url: `api/v1.0/variants/${skuVariant.sku}`,
      headers: { ...apiHeaders, 'Accept-Language': defaultMarketLanguage },
      body: { ...skuVariant, availabilityStatus: 'IActive' },
      failOnStatusCode : false
    }).its('status')
      .should('eq', 400);
  });
});
