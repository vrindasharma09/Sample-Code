import { markets } from '../../support/helpers/markets';

const market = markets.find(m => m.id === 'no');
const sku = 'AUTOMATION-PRICE';
const skuVariant = {
  sku: sku,
  name: 'Automation Price',
  displayName: 'Automation Sku for Price',
  description: 'A generated SKU for testing prices.'
};

describe('price', () => {

  before(() => {
    cy.initializeSku(skuVariant) ;
  });

  beforeEach(() => {
    cy.initializeMarketSku(skuVariant, market);
    cy.activateSkuPrice(sku, market.language, true);
    cy.suppressCookieBanner();
    // TODO: OB-5211
    // We're experiencing a slowdown in publishing changes
    // from the data exchange API for prices and availability.
    // Commenting the following code.
    // cy.verifySkuPage(skuVariant, market);
  });

  /**
   * Disable the item price and ensure it cannot be added to cart.
   * OB-3123
   */
  it('should disable price', () => {
    cy.activateSkuPrice(sku, market.language, false);

    // Ensure that the item pages are browsable, but not showing add to cart.
    cy.visit(`${market.url}/item/${sku}`);
    cy.get('[data-testid=product-details]').find('[data-testid=tax-included-price]').should('not.exist');
    cy.get('[data-testid=product-details]').find('[data-testid=add-to-cart]').should('not.exist');
  });
});
