import { markets } from '../support/helpers/markets';

const market = markets.find(m => m.id === 'no');

describe('compare', () => {

  beforeEach(() => {
    cy.suppressCookieBanner();
  });

  it('compare products', () => {
    cy.visit(`${market.url}/products/simulation-training/emergency-care-trauma/`);

    cy.get('[data-testid=compare-simman-essential]').click();
    cy.url().should('include', `${market.url}/products/simulation-training/emergency-care-trauma/simman-essential/compare`);

    // The compare button should be disabled if no other products are selected.
    cy.get('[data-testid=execute-compare]').should('be.disabled');

    // Select a second compare product and ensure that the compare button is activated.
    cy.get('[data-testid=product-category-card] label[for=simman]').click();
    cy.get('[data-testid=execute-compare]').should('be.enabled');

    // Select a third compare product and ensure that we can't select any other compare products.
    cy.get('[data-testid=product-category-card] label[for=simman-vascular]').click();
    cy.get('[data-testid=execute-compare]').should('be.enabled');

    // We've reached the max number of items to compare, the checkboxes on other
    // items should be disabled.
    cy.get('[data-testid=product-category-card] label[for=simman-als] #simman-als').should('be.disabled');

    // Execute the compare.
    cy.get('[data-testid=execute-compare]').click();
    cy.url().should('match', new RegExp(`${market.url}/products/simulation-training/emergency-care-trauma/simman-essential/Compare?.*compareCodes=simman`));
    cy.url().should('match', new RegExp(`${market.url}/products/simulation-training/emergency-care-trauma/simman-essential/Compare?.*compareCodes=simman-vascular`));

    // OB-5209: Ensure each product is listed only once.
    cy.get('[data-testid=product-category-card] [data-testid=title-simman-essential]').should('have.length', 1);
    cy.get('[data-testid=product-category-card] [data-testid=title-simman]').should('have.length', 1);
    cy.get('[data-testid=product-category-card] [data-testid=title-simman-vascular]').should('have.length', 1);

    // Change the selection and ensure the same items are selected.
    cy.get('[data-testid=change-compare]').click();
    cy.get('[data-testid=product-category-card] label[for=simman] #simman').should('be.checked');
    cy.get('[data-testid=product-category-card] label[for=simman-vascular] #simman-vascular').should('be.checked');
  });
});
