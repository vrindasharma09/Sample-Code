import AddToCart from 'vuetemplates/cart/AddToCart.vue';
import { createStore } from 'vuex';
import cart from '@store/modules/cart';

describe('AddToCart', () => {
  it('should render slot content and emit appropriate events', () => {
    const store = createStore({
      modules: {
        cart
      }
    });

    const btnSelector = '[data-testid="btn-add-to-cart"]';
    const btnSpinnerSelector = '[data-testid="btn-spinner"]';
    const btnIconSelector = '[data-testid="btn-icon"]';
    const btnTextSelector = '[data-testid="btn-text"]';
    cy.spy(store, 'dispatch').as('dispatch');

    // mount the component by itself in the browser
    cy.mount(AddToCart, {
      global: {
        plugins: [store]
      },
      slots: {
        default: `<button data-testid="btn-add-to-cart" type="submit" class="e-button e-button--ctablue" @click.prevent="addToCart" :disabled="loading" :class="{ 'e-button--loading': loading}">
                    <span data-testid="btn-spinner" class="e-button__spinner"></span>
                    <span data-testid="btn-icon" class="c-variant-tile__cart-icon--new"></span>
                    <span data-testid="btn-text" class="c-variant-tile__btn-text">Add To Cart</span>
                  </button>`,
      },
      propsData: {
        sku: '198-80150',
        name: 'Shocklink Training pads multi',
        category: 'skills-proficiency/defibrillation-cardiology/shocklink',
        list: 'Test List',
        position: 1,
        sPosition: '1',
        price: 10,
        discount: 2,
        categories: ['skills-proficiency', 'defibrillation-cardiology', 'shocklink'],
        currency: 'NOK',
        sourceAddToCart: true
      }
    });

    // assert button with content and text is present
    cy.get(btnSelector).should('be.visible');
    cy.get(btnSpinnerSelector).should('not.be.visible');
    cy.get(btnIconSelector).should('be.visible');
    cy.get(btnTextSelector).should('have.text', 'Add To Cart');
    
    cy.intercept('**/api/shoppingcart/*', {
      result: {
        response: {
          lineItems: [
            {
              data: {
                id: -1,
                productDetailsModel: {
                },
                quantity: 1
              },
              quantity: 1,
              sku: '198-80150'
            }
          ]
        }
      }
    }).as('addItem');

    cy.intercept('**/api/Recommendation/basketWidget/*', {
      result: {
        response: []
      }
    }).as('trackAddedItem');
    
    cy.get(btnSelector).click();

    cy.wait('@addItem').its('request').should('have.property', 'headers');
    cy.wait('@trackAddedItem').its('request').should('have.property', 'headers');

    cy.get('@vue').then(({wrapper}) => {
      expect(wrapper.exists()).to.be.true;
    });

  });
});