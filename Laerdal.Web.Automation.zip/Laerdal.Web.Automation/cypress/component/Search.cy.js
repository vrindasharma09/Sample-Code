import Search from 'vuetemplates/new-search/NewSearchPage.vue';
import { createStore } from 'vuex';
import searchNew from '@store/modules/searchNew';

describe('When a user performs a search', () => {
  const store = createStore({
    modules: {
      searchNew,
    },
  });

  const productCategoriesApi = '**/api/catalogsearch/productcategories*';
  const productsAndPackagesApi = '**/api/catalogsearch/productsandpackages*';
  const partsApi = '**/api/catalogsearch/parts*';
  const contentApi = '**/api/contentsearch/content*';
  const downloadsApi = '**/api/contentsearch/downloads*';
  const inventoryApi = '**/api/availability/product?code=*';

  const tabsNames = ['Category', 'MainProducts', 'PartsAndAccessories', 'Content', 'Support'];

  beforeEach(() => {
    cy.intercept('POST', productCategoriesApi, { fixture: 'search-productcategory.json' }).as('fetchProductCategory');
    cy.intercept('POST', productsAndPackagesApi, { fixture: 'search-products.json' }).as('fetchProducts');
    cy.intercept('POST', partsApi, { fixture: 'search-parts.json' }).as('fetchParts');
    cy.intercept('POST', contentApi, { fixture: 'search-content.json' }).as('fetchContent');
    cy.intercept('POST', downloadsApi, { fixture: 'search-downloads.json' }).as('fetchDownload');
    cy.intercept('GET', inventoryApi, { fixture: 'search-availability.json' }).as('fetchInventory');
    cy.intercept('**/api/Recommendation/searchWidget', {
      result: {
        response: []
      }
    }).as('trackSearch');

    cy.mount(Search, {
      global: {
        plugins: [store],
      },
      propsData: {
        tabs: [
          {
            'name': 'Produktkategori',
            'enumName': 'Category',
            'type': 0,
            'sortOptions': [
              {
                'disabled': false,
                'group': null,
                'selected': true,
                'text': 'Most relevant',
                'value': '0'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Produktnavn (A-Å)',
                'value': '1'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Produktnavn (Å-A)',
                'value': '2'
              }
            ],
            'itemsPerPage': 12,
            'apiEndpoint': '/nb-NO/api/catalogsearch/productcategories',
            'apiResponseVariable': 'productCategories',
            'isActive': true
          },
          {
            'name': 'Produkter',
            'enumName': 'MainProducts',
            'type': 5,
            'sortOptions': [
              {
                'disabled': false,
                'group': null,
                'selected': true,
                'text': 'Mest populære',
                'value': '0'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Produktnavn (A-Å)',
                'value': '1'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Produktnavn (Å – A)',
                'value': '2'
              }
            ],
            'itemsPerPage': 12,
            'apiEndpoint': '/nb-NO/api/catalogsearch/productsandpackages',
            'apiResponseVariable': 'products',
            'isActive': false
          },
          {
            'name': 'Deler & tilbehør',
            'enumName': 'PartsAndAccessories',
            'type': 4,
            'sortOptions': [
              {
                'disabled': false,
                'group': null,
                'selected': true,
                'text': 'Mest populære',
                'value': '0'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Produktnavn (A-Å)',
                'value': '1'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Produktnavn (Å – A)',
                'value': '2'
              }
            ],
            'itemsPerPage': 12,
            'apiEndpoint': '/nb-NO/api/catalogsearch/parts',
            'apiResponseVariable': 'products',
            'isActive': false
          },
          {
            'name': 'Innhold',
            'enumName': 'Content',
            'type': 1,
            'sortOptions': [
              {
                'disabled': false,
                'group': null,
                'selected': true,
                'text': 'Standard',
                'value': '0'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Nyeste',
                'value': '1'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Eldste',
                'value': '2'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Produktnavn (A-Å)',
                'value': '3'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Produktnavn (Å – A)',
                'value': '4'
              }
            ],
            'itemsPerPage': 50,
            'apiEndpoint': '/nb-NO/api/contentsearch/content',
            'apiResponseVariable': 'contentItems',
            'isActive': false
          },
          {
            'name': 'Support',
            'enumName': 'Support',
            'type': 2,
            'sortOptions': [
              {
                'disabled': false,
                'group': null,
                'selected': true,
                'text': 'Standard',
                'value': '0'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Nyeste',
                'value': '1'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Eldste',
                'value': '2'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Produktnavn (A-Å)',
                'value': '3'
              },
              {
                'disabled': false,
                'group': null,
                'selected': false,
                'text': 'Produktnavn (Å – A)',
                'value': '4'
              }
            ],
            'itemsPerPage': 50,
            'apiEndpoint': '/nb-NO/api/contentsearch/downloads',
            'apiResponseVariable': 'downloadItems',
            'isActive': false
          }
        ],
        initialTab: 0,
        initialSelectedFilters: [],
        initialSearchValue: '',
      },
    });

    cy.wait('@fetchProductCategory');
  });

  it('perform search', () => {
    cy.get('[id="searchBarInput"]').type('anni');

    cy.get('[id="searchBarInput"]').should('have.value', 'anni');
    cy.get('[data-testid="search-results"]').should('exist');
    cy.get('[data-testid="load-more-button"]').should('exist');
    cy.get('@fetchProductCategory').then((interception) => {
      const responseBody = interception.response.body;
      expect(responseBody.result.response.totalHits).to.equal(14);
    });
  });

  it('clear search field', () => {
    cy.get('[id="searchBarInput"]').type('anni');
    cy.wait('@fetchProductCategory');

    cy.get('[data-testid="clear-search-input"]').click();

    cy.get('[id="searchBarInput"]').should('have.value', '');
  });

  it('search with no result', () => {
    cy.intercept('POST', productCategoriesApi, {
      result: {
        response: {
          itemsPerPage: 12,
          page: 0,
          productCategories: [],
          facetsGroups: {},
          sortBy: 0,
          totalHits: 0,
        }
      }
    }).as('fetchProductCategoryEmptyResults');

    cy.get('[id="searchBarInput"]').type('xckjrs');
    cy.wait('@fetchProductCategoryEmptyResults');

    cy.get('.c-search--load-more').should('not.exist');
    cy.get('[data-testid="filter-menu-desktop"]').should('not.exist');
    cy.get('[data-testid="search-result-item"]').should('not.exist');
  });

  it('check sort', () => {
    cy.get('[data-testid="sort-dropdown-button"]').should('be.visible');
    cy.get('[id="Produktnavn (A-Å)"').should('not.be.visible');
  });

  it('change sort value', () => {
    cy.fixture('search-productcategory.json').then((fixture) => {
      fixture.result.response.sortBy = '1';
      cy.intercept('POST', productCategoriesApi, fixture).as('fetchProductCategoryWithSortModifier');
    });

    cy.get('[data-testid="sort-dropdown-button"]').click();
    cy.get('[id="Produktnavn (A-Å)"').click();

    cy.wait('@fetchProductCategoryWithSortModifier');
    cy.get('@fetchProductCategoryWithSortModifier').then((interception) => {
      const responseBody = interception.response.body;
      expect(responseBody.result.response.sortBy).to.equal('1');
    });
  });

  it('filter should be visible', () => {
    cy.get('[data-testid="search-filter-button"]').should('be.visible');
  });


  it('Click through tabs', () => {
    tabsNames.forEach((tab) => {
      cy.get(`[data-testid="${tab}"]`).click();
      cy.get('[data-testid="search-results"]').should('exist');
    });
  });
});
