import CheckoutLineItem from 'vuetemplates/checkout/CheckoutLineItem.vue';
import { createStore } from 'vuex';
import checkout from '@store/modules/checkout';

describe('CheckoutLineItem', () => {
  const store = createStore({
    modules: {
      checkout
    }
  });

  const itemSkuSelector = '.c-variant-tile__sku';
  const titleSelector = '.c-variant-tile__title';
  const imageSelector = '.c-variant-tile__thumb';
  const quantitySelector = '.c-line-items__qty';
  const priceSelector = '.c-line-items__price';
  const totalPriceSelector = '.c-line-items__total-price';

  beforeEach(() => {
    cy.mount(CheckoutLineItem, {
      global: {
        plugins: [store]
      },
      propsData: {
        lineItem: {
          sku: '171-01260',
          title: 'Resusci Anne QCPR Full Body - Rechargeable',
          thumbnailImageUrl: '/images/sku/171-01260.png',
          productUrl: '/no/item/171-01260/',
          price: '20 095,00 kr',
          salePrice: '20 095,00 kr',
          discountPrice: '20 095,00 kr',
          lineTotal: '20 095,00 kr',
          quantity: 1,
          isGift: false
        },
        lazyLoadImages: false,
        showExcludeTaxText: false
      }
    });
  });

  it('displays product info', () => {
    cy.get(itemSkuSelector).should('contain', '171-01260');
    cy.get(titleSelector).should('contain', 'Resusci Anne QCPR Full Body - Rechargeable');
    cy.get(quantitySelector).should('contain', 1);
    cy.get(imageSelector).should('have.attr', 'src').should('include', '/images/sku/171-01260.png');
    cy.get(priceSelector).should('contain', '20 095,00 kr');
    cy.get(totalPriceSelector).should('contain', '20 095,00 kr');
  });
});