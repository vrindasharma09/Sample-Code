import MiniCartLineItem from 'vuetemplates/cart/MiniCartLineItem.vue';
import { createStore } from 'vuex';
import cart from '@store/modules/cart';

describe('MiniCartLineItem', () => {
  const store = createStore({
    modules: {
      cart
    }
  });

  const itemSkuSelector = '[data-testid="item-sku"]';
  const quantitySelector = '[data-testid="mini-cart-quantity"]';
  const titleSelector = '.c-variant-tile__title';

  beforeEach(() => {
    cy.mount(MiniCartLineItem, {
      global: {
        plugins: [store]
      },
      propsData: {
        data: {
          id: -1,
          productDetailsModel: {
            title: 'Resusci Anne QCPR Full Body - Rechargeable',
            sku: '171-01260',
            description: 'High-performance CPR training for professional first responders',
            productUrl: '/no/item/171-01260/',
            thumbnailUrl: '/images/sku/171-01260.png?lang=no',
            analytics: {}
          },
          quantity: 1,
          isAvailable: false,
          currencySymbol: 'kr',
          minQuantity:0,
          stockLevel: 0,
          shipments: [],
          latestShipmentDate: '31/10/2023',
          placedPrice: 'kr 19 510,00',
          listPrice: 'kr 19 510,00',
          lineTotalDefault: 'kr 19 510,00',
          lineTotalDiscounted: 'kr 19 510,00',
          isGift: false,
          isVirtual: false,
          isQuoted: false,
          endUser: '',
          showExcludeTaxText: true
        },
        quantity: 1,
        sku: '171-01260'
      }
    });
  });

  it('displays product info', () => {
    cy.get(itemSkuSelector).should('contain', '171-01260');
    cy.get(quantitySelector).should('be.visible');
    cy.get(titleSelector).should('contain', 'Resusci Anne QCPR Full Body - Rechargeable');

  });

  it('updates quantity', () => {
    cy.intercept('**/api/shoppingcart/*', {
      result: {
        response: {
          lineItems: [
            {
              data: {
                id: -1,
                productDetailsModel: {
                },
                quantity: 3
              },
              quantity: 3,
              sku: '171-01260'
            }
          ]
        }
      }
    }).as('updateItem');

    cy.get(quantitySelector).clear();
    cy.get(quantitySelector).type('3');
    cy.wait('@updateItem').its('request').should('have.property', 'headers');

  });

  it('removes line item', () => {
    cy.get('@vue').then(({wrapper}) => {
      expect(wrapper.exists()).to.be.true;
      wrapper.vm.removeLineItem = cy.stub().as('removeLineItem');

      // Click to Remove button
      cy.get('button').contains('Remove').click();
      cy.get('@removeLineItem').should('have.been.calledOnce');
    });
  });
});