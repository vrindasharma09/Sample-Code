import { createStore } from 'vuex';
import checkout from '@store/modules/checkout';
import api from '@store/utils/api';
import checkoutResponse from '../../fixtures/mock/checkout.response';

describe('checkout store', () => {
  const store = createStore({
    modules: {
      checkout  
    }
  });

  beforeEach(() => {
    cy.spy(store, 'dispatch').as('dispatch');
    // Mock API calls
    cy.stub(api, 'get').resolves({cartData: checkoutResponse.DefaultResponse});
  });

  it('gets checkout data', () => {
    store.dispatch('checkout/getCheckoutState', {authToken: 'token123'});
    cy.get('@dispatch').should('have.been.calledWith', 'checkout/getCheckoutState');
  });

  it('refreshes checkout data', () => {
    store.dispatch('checkout/refreshCheckoutState', {authToken: 'token123'});
    cy.get('@dispatch').should('have.been.calledWith', 'checkout/refreshCheckoutState');
  });

  it('place an order', () => {
    store.dispatch('checkout/placeOrder', {authToken: 'token123'});
    cy.get('@dispatch').should('have.been.calledWith', 'checkout/placeOrder');
  });

  it('place an 3ds2 order', () => {
    store.dispatch('checkout/placeOrder3ds2', {authToken: 'token123'});
    cy.get('@dispatch').should('have.been.calledWith', 'checkout/placeOrder3ds2');
  });

  it('updates payment data', () => {
    store.dispatch('checkout/updatePaymentData', {authToken: 'token123'});
    cy.get('@dispatch').should('have.been.calledWith', 'checkout/updatePaymentData');
  });

  it('updates payment methods', () => {
    store.dispatch('checkout/updatePaymentMethods', {authToken: 'token123'});
    cy.get('@dispatch').should('have.been.calledWith', 'checkout/updatePaymentMethods');
  });

  it('updates selected payment option', () => {
    store.dispatch('checkout/updateSelectedPaymentOption', {authToken: 'token123'});
    cy.get('@dispatch').should('have.been.calledWith', 'checkout/updateSelectedPaymentOption');
  });
});