import { createStore } from 'vuex';
import cart from '@store/modules/cart';
import api from '@store/utils/api';
import cartResponse from '../../fixtures/mock/cart.response';

describe('cart store', () => {
  const store = createStore({
    modules: {
      cart  
    }
  });

  beforeEach(() => {
    cy.spy(store, 'dispatch').as('dispatch');
    // Mock API calls
    cy.stub(api, 'get').resolves({cartData: cartResponse.DefaultResponse});
    // cy.stub(this, '$authToken').value('token123');
  });

  it('loads cart data', () => {
    store.dispatch('cart/loadCart', {authToken: 'token123'});
    cy.get('@dispatch').should('have.been.calledWith', 'cart/loadCart');
  });

  it('removes item from cart', () => {
    store.dispatch('cart/removeItem', {id: 1});
    cy.get('@dispatch').should('have.been.calledWith', 'cart/removeItem');
  });

  it('adds item to cart', () => {
    store.dispatch('cart/addItem', {id: 1});
    cy.get('@dispatch').should('have.been.calledWith', 'cart/addItem');
  });

  it('adds multiple items to cart', () => {
    store.dispatch('cart/addItems', [{id: 1}, {id: 2}]);
    cy.get('@dispatch').should('have.been.calledWith', 'cart/addItems');
  });

  it('updates item from cart', () => {
    store.dispatch('cart/updateItem', [{id: 1}]);
    cy.get('@dispatch').should('have.been.calledWith', 'cart/updateItem');
  });

  it('updates multiple items from cart', () => {
    store.dispatch('cart/updateItems', [{id: 1}, {id: 2}]);
    cy.get('@dispatch').should('have.been.calledWith', 'cart/updateItems');
  });

  it('deletes cart data', () => {
    store.dispatch('cart/deleteCart', [{id: 1}]);
    cy.get('@dispatch').should('have.been.calledWith', 'cart/deleteCart');
  });

  it('adds promotion to cart', () => {
    store.dispatch('cart/addPromotion', {id: 1});
    cy.get('@dispatch').should('have.been.calledWith', 'cart/addPromotion');
  });

  it('removes promotion from cart', () => {
    store.dispatch('cart/removePromotion', {id: 1});
    cy.get('@dispatch').should('have.been.calledWith', 'cart/removePromotion');
  });

  it('checks due date', () => {
    store.dispatch('cart/checkDueDates', {id: 1});
    cy.get('@dispatch').should('have.been.calledWith', 'cart/checkDueDates');
  });

  it('loads end users data', () => {
    store.dispatch('cart/getEndUsers', {id: 1});
    cy.get('@dispatch').should('have.been.calledWith', 'cart/getEndUsers');
  });

  it('assigns end users data', () => {
    store.dispatch('cart/assignEndUsers', {id: 1});
    cy.get('@dispatch').should('have.been.calledWith', 'cart/assignEndUsers');
  });

  it('loads cart settings data', () => {
    store.dispatch('cart/cartSettings', {id: 1});
    cy.get('@dispatch').should('have.been.calledWith', 'cart/cartSettings');
  });

  it('sets session checkout mode', () => {
    store.dispatch('cart/setSessionCheckoutMode', {});
    cy.get('@dispatch').should('have.been.calledWith', 'cart/setSessionCheckoutMode');
  });

});