const {defineConfig} = require('cypress');
const webpackCypressConfig = require('./webpack.config');

module.exports = defineConfig({
  projectId: '7g1vdp',
  reporter: 'junit',
  reporterOptions: {
    mochaFile: 'results/junit-components-[hash].xml',
    toConsole: false,
  },
  e2e: {
    baseUrl: 'https://laerdal.local',
    env: {
      // Provide a list of market ids to execute the tests only for those markets.
      // Use cypress.env.json to list local variables without committing the file.
      markets: [],

      gigyaApiKey: '3_7HEP1k5UR-h3hD7S5XbKjTsYTg3Vw5WPxCjmYYk9Bxa2SJRZWNTAr26hs5WjyCQc',

      apiKeyName: 'Ocp-Apim-Subscription-Key',
      apiKeyValue: 'valid-key',

      cosmosEndpoint: 'https://localhost:8081',
      cosmosKey: 'C2y6yDjf5/R+ob0N8A7Cgv30VRDJIWEHLM+4QDU5DE2nQ9nDuVTqobD4b8mGGyPMbIZnqyMsEcaGQy67XIw/Jw==',
      cosmosDatabase: 'laerdal-ecommerce',
      cosmosContainer: 'erp-cache',

      laerdalGlobalHealthUrl: 'https://lgh.laerdal.local',
    },

    // Disable Chrome's security to allow us to
    // interact with elements inside iframes.
    chromeWebSecurity: false
  },

  // We disable video as it requires more resources on the build servers.
  // Note that we will still have the test replay feature active.
  video: false,

  // We are aware we have performance issues with the site.
  // Increase the default timeouts to 5s so that the tests can finish successfully.
  defaultCommandTimeout: 5 * 1000,
  requestTimeout: 5 * 1000,

  // We would like to have a desktop viewport.
  // This will interfere with the profile menu.
  viewportWidth: 1200,
  viewportHeight: 768,

  component: {
    devServer: {
      framework: 'vue',
      bundler: 'webpack',
      webpackConfig: (baseConfig) => {
        // Extend the base config with our own.
        return {
          ...baseConfig,
          ...webpackCypressConfig
        };
      }
    },
    env: {
      markets: []
    }
  }
});
