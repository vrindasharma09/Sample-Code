# Laerdal.com Automation Tests

## Getting Started
Install dependencies with `npm ci`.

Start Cypress with `npx cypress open`.

## Guidelines

### Organizing Tests
> [!IMPORTANT]
> Split specs into regular tests and smoke tests to make it easier to run them in the CI builds.\
> Keep spec runs under a minute so that they can be executed on the GitHub build runners.

### Smoke Tests
Separate smoke tests (intended for Production) form the other tests by
appending `smoke` in the filenames.

Example: `checkout.smoke.cy.js`

This way we can use wild card patterns to match all smoke tests and run them, like `cypress/**/*.smoke.cy.js`.

### Markets
Write your tests with the various markets in mind. The market configurations can be found in `fixtures/markets.json`.

Use the exported variable `markets` from `support/helpers/markets.js`. This will provide you with an array of all markets that should be tested - it is important to know that the array will be filtered if you specify exact markets that the test should for. See section **Running for a specific market**.

Use the markets to dynamically generate specs.

```js
import { markets } from 'support/helpers/markets';

describe('feature', () => {
  markets.forEach(market => {
    it(`should do something <${market.id}>`, () => {
      // Test.  
    });
  });
});
```

### Running for a specific market
To run automation tests locally for 1-2 markets instead of the whole suite or markets, add the desired markets in `cypress.env.json`.

**Do not commit this file.**

```json
{
  "markets": [ "no", "us" ]
}
```

## Cypress Docs
[Opening the App](https://docs.cypress.io/guides/getting-started/opening-the-app)

[Cypress API](https://docs.cypress.io/api/table-of-contents)
