const path = require('path');
const { VueLoaderPlugin } = require('vue-loader');

module.exports = {
  // cypress specific webpack configuration
  // will be merged with the default webpack config
  resolve: {
    alias: {
      vue: path.resolve('./node_modules/vue'),
      vueplugins: path.resolve('../Laerdal.Web/frontend/_client/scripts/src/vueplugins'),
      '@': path.resolve('../Laerdal.Web/frontend/_client/scripts/src'),
      vuetemplates: path.resolve('../Laerdal.Web/frontend/_client/scripts/src/vuetemplates'),
      '@store': path.resolve('../Laerdal.Web/frontend/_client/scripts/src/store'),
      'modules': path.resolve('../Laerdal.Web/frontend/_client/scripts/src/modules'),
      '@css': path.resolve('../Laerdal.Web/wwwroot/assets/css')
    }
  },
  module: {
    rules: [
      {
        test: /\.vue$/,
        loader: 'vue-loader'
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader'],
      },
      {
        test: /\.svg$/,
        use: 'file-loader',
      },
    
    ]
  },
  plugins: [new VueLoaderPlugin()]
};