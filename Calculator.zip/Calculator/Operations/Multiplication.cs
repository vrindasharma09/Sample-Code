﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CalculatorNS
{
    public class Multiplication : Calculator
    {
        public Multiplication()
        {
            if (!countOperation.ContainsKey("Multiplication"))
            {
                countOperation.Add("Multiplication", 0);
            }
        }
        public override string Calculate(string[] numbers)
        {
            double mul = 1;
            foreach(var number in numbers)
            {
                mul = mul * Convert.ToDouble(number);
            }
            countOperation["Multiplication"]++;
            return Convert.ToString(mul); 
        }
    }
}
