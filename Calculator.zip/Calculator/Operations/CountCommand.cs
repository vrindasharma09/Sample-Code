﻿using Calculator.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace CalculatorNS
{
    public class CountCommand : Calculator
    {
        public override string Calculate(string[] operation)
        {
            var command = (CommandEnum)Enum.Parse(typeof(CommandEnum), operation[0].ToLower());
            var countOpt = 0;
            if (countOperation.ContainsKey(EnumHelper.GetEnumDescription(command)))
                countOpt= countOperation[EnumHelper.GetEnumDescription(command)];
            return Convert.ToString(countOpt);
        }
    }
}
