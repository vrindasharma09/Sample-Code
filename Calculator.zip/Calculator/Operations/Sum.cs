﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CalculatorNS
{
    public class Sum : Calculator
    {
        public Sum()
        {
            if (!countOperation.ContainsKey("Sum"))
            {
                countOperation.Add("Sum", 0);
            }
        }
        public override string Calculate(string[] numbers)
        {
            double sum = 0;
            foreach (var number in numbers)
            {
                sum = sum + Convert.ToDouble(number);
            }
            countOperation["Sum"]++;
            return Convert.ToString(sum);
        }
    }
}
