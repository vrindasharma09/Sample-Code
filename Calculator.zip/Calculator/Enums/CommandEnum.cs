﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Calculator.Enums
{
    public enum CommandEnum
    {
        [Description("Sum")]
        add ,
        [Description("Sum")]
        addittion ,
        [Description("Sum")]
        sum ,
        [Description("Multiplication")]
        mul,
        [Description("Multiplication")]
        multiply,
        [Description("Multiplication")]
        multiplication,
        [Description("CountCommand")]
        count
    }
    public static class EnumHelper
    {
        public static string GetEnumDescription(Enum value)
        {
            var fi = value.GetType().GetField(value.ToString());

            var attributes = fi.GetCustomAttributes(typeof(DescriptionAttribute), false) as DescriptionAttribute[];

            if (attributes != null && attributes.Any())
            {
                return attributes.First().Description;
            }

            return value.ToString();
        }
    }
}
