﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CalculatorNS
{
    public class CalculateOperation
    {
        private Calculator _calc;
        public  CalculateOperation(Calculator calc)
        {
            _calc = calc;
        }
        public string CalculateOpt(string[] inputNumbers)
        {
           return _calc.Calculate(inputNumbers);
        }
    }
}
