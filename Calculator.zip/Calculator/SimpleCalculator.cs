﻿using Calculator.Enums;
using System;
using System.Linq;

namespace CalculatorNS
{
   
    public class SimpleCalculator
    {
        public static string DoOperation(string operation, string[] inputNumbers)
        {
            try
            {
                
                var command = (CommandEnum)Enum.Parse(typeof(CommandEnum), operation.ToLower());
                var result = CalculatorInstance.Create(EnumHelper.GetEnumDescription(command));
                var _co = new CalculateOperation(result);
                return _co.CalculateOpt(inputNumbers);
            }
            catch (Exception ex)
            {
                return "Please correct command: " + ex.Message;
            }       
        }
        
        static void Main(string[] args)
        {
            string userInput;
            char isContinue = 'Y';
            do
            {
                Console.WriteLine("Enter Command");
                userInput = Console.ReadLine();
                var operation = userInput.Split(" ");
                if (operation.Length != 2)
                {
                    Console.WriteLine("Please enter valid input in format Add 1,2,3");
                    Console.WriteLine("Do u want to continue. Press 'N' for no and any other key for Yes?");
                    isContinue = Console.ReadKey().KeyChar;
                    Console.WriteLine("\n");
                    if (char.ToUpper(isContinue) == 'N')
                    {
                        break;
                    }
                    else
                        continue;
                }
                var inputNumbers = operation[1].Split(",");
                var result = DoOperation(operation[0], inputNumbers);
                Console.WriteLine("Output: " + result+ "\nDo u want to continue. Press 'N' for no and any other key for Yes?");                
                isContinue = Console.ReadKey().KeyChar;
                Console.WriteLine("\n");
            } while (char.ToUpper(isContinue) != 'N');
            Console.WriteLine("Thank you!!");
        }
    }
}
