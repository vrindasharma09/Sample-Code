﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CalculatorNS
{
    public abstract class Calculator
    {
        public static Dictionary<string, int> countOperation = new Dictionary<string, int>();
        public abstract string Calculate(string[] numbers);
    }
}
