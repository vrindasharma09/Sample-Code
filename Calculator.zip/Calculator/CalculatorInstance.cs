﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CalculatorNS
{
    public static class CalculatorInstance
    {
        public static Calculator Create(string operation)
        {
            var instanceType = Type.GetType(typeof(Calculator).Namespace + "." + operation, throwOnError: false);
            return (Calculator)Activator.CreateInstance(instanceType);
        }
    }
}
